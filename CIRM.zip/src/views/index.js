import {
  Breadcrumbs,
  Cards,
  Carousels,
  Collapses,
  Dropdowns,
  Forms,
  Jumbotrons,
  ListGroups,
  Navbars,
  Navs,
  Paginations,
  Popovers,
  ProgressBar,
  Switches,
  Tables,
  Tabs,
  Tooltips,
} from './Base';

import { ButtonDropdowns, ButtonGroups, Buttons, BrandButtons } from './Buttons';
import Charts from './Charts';
import Marketing from './Marketing';
import Dashboard from './Dashboard';
import { CoreUIIcons, Flags, FontAwesome, SimpleLineIcons } from './Icons';
import { Alerts, Badges, Modals } from './Notifications';
import { Login, Page404, Page500, Register,Daftarbank,Detailpinjaman,Informasitambahan, } from './Pages';
import { Colors, Typography } from './Theme';
import { Emarketingdetail, Emarketinglist } from './Emarketing';
import Widgets from './Widgets';
import { Bankofficerdetail} from './Bank'

export {
  Emarketingdetail,
  Emarketinglist,
  Badges,
  Bankofficerdetail,
  Daftarbank,
  Informasitambahan,
  Detailpinjaman,
  Typography,
  Colors,
  Marketing,
  CoreUIIcons,
  Page404,
  Page500,
  Register,
  Login,
  Modals,
  Alerts,
  Flags,
  SimpleLineIcons,
  FontAwesome,
  ButtonDropdowns,
  ButtonGroups,
  BrandButtons,
  Buttons,
  Tooltips,
  Tabs,
  Tables,
  Charts,
  Dashboard,
  Widgets,
  Jumbotrons,
  Switches,
  ProgressBar,
  Popovers,
  Navs,
  Navbars,
  ListGroups,
  Forms,
  Dropdowns,
  Collapses,
  Carousels,
  Cards,
  Breadcrumbs,
  Paginations,
};

