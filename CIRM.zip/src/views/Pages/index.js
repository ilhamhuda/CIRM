import Login from './Login';
import Page404 from './Page404';
import Page500 from './Page500';
import Register from './Register';
import Daftarbank from './Daftar_bank';
import Detail_pinjaman from './Detail_pinjaman';
import Informasi_tambahan from './Informasi_tambahan';

export {
  Login, Page404, Page500, Register, Daftarbank, Detail_pinjaman, Informasi_tambahan
};