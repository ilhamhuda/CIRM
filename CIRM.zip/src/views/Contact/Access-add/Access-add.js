import React, { Component } from 'react';
import { Badge, Button, Card, CardBody, CardFooter, InputGroup,Input,FormGroup, InputGroupAddon,CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link,useParams } from 'react-router-dom';
import axios from 'axios';

class Collapses extends Component {

  constructor(props) {
    super(props);
   
    this.state = {
      userid:null,
      id_contact:null,
      access:[],
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm/contact_access/'
    };
  }



  access(listing) {
    return(
      <Card key={listing.id}>
      <CardHeader>
        <Row style={{margin:10}}>
        
        <Col  >
    <strong>{listing.name}</strong>
        <br></br>
        
         <small>{listing.office}</small>
         <br></br>
    
         </Col>
         <div className="card-header-actions">
         <Link>
         {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
         <Button onClick={() => this.submit(listing.id)} style={{color:'white', backgroundColor:'#35d44f',}} className="px-2"><i className="fa fa-plus-square"></i> </Button>
           
               </Link>   </div>
        </Row>
      
      </CardHeader>
    
    </Card>
    )
  }

  reload() {
    const urlmy = `${this.state.API_URL}unlisted_by_contact/`+ this.state.id_contact;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ access: data })
   
     })
  }

  componentWillMount() {
    const { id_user,id } = this.props.location
    console.log('ini data access : ', id_user, id)
    const urlmy = `${this.state.API_URL}unlisted_by_contact/`+ id;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ access: data, id_user:id_user, id_contact:id })
   
     })
   
     
  }

 

  submit(advisor) {
    
    var bodyFormData = new FormData();
    bodyFormData.set('id_advisor', advisor);
    bodyFormData.set('id_contact', this.state.id_contact);

 
    console.log('data cok', this.state)
    const url = `${this.state.API_URL}insert`;
    axios.post(url,bodyFormData, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        this.reload()

     })
  }
  
  backTo() {
    
     this.props.history.push({
          pathname: '/akses',
          id: this.state.id_contact 
        })
  }
  render() {
    return (
      <div className="animated fadeIn">
         <br></br>
         <Row>
     
          <Col xs="12" sm="6">
        
            <Card>
              <CardHeader>
                 <Button color="transparant"  onClick={() => this.backTo()}  className="mr-1"><i className="fa fa-chevron-left"></i> </Button>
    
                <strong>Add Access</strong>
                <small> </small>
              
              </CardHeader>
             </Card>
         </Col>
         </Row>

        <Row>
         
          <Col xl="6">
          <FormGroup row>
                    <Col md="12">
                      <InputGroup>
                     
                        <Input type="text" id="input1-group2" name="input1-group2" placeholder="" />
                        <InputGroupAddon addonType="prepend">
                          <Button type="button" color="primary"><i className="fa fa-search"></i> Search</Button>
                        </InputGroupAddon>
                      </InputGroup>
                    </Col>
                  </FormGroup>
           
            {this.state.access.map((item)=>this.access(item))}
         
          </Col>
        </Row>
      </div>
    );
  }
}

export default Collapses;
