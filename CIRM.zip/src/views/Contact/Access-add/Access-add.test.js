import React from 'react';
import ReactDOM from 'react-dom';
import Accessadd from './Access-add';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Accessadd />, div);
  ReactDOM.unmountComponentAtNode(div);
});
