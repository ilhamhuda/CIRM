import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form, Modal, ModalBody, ModalFooter, ModalHeader,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';
import axios from 'axios';
class Forms extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300,
      id_contact: 1,
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      notif_delete: false,
      id_requirement: 1,
      kategori:[],
      amount: 0,
      purpose: 'Tidak Ada',
      amount1:0,
      amount2: 0,
      amount3: 0,
      title1: 'Tidak Ada',
      title2: 'Tidak Ada',
      title3:'Tidak Ada'
    };
    this.toggleDanger = this.toggleDanger.bind(this)
  }
  toggleDanger() {
    this.setState({
      notif_delete: !this.state.notif_delete,
    });
  }
  backTo() {
    
     this.props.history.push({
          pathname: '/contact-detail',
          id: this.state.id_contact 
        })
  }
  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }
  delete() {
    const url = `${this.state.API_URL}/contact_requirement/delete/` + this.state.id_requirement ;
    axios.post(url,{}, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        
     this.setState({
      notif_delete: !this.state.notif_delete,
    });

     })

 
  }
  
  submit() {
    
    var bodyFormData = new FormData();
    bodyFormData.set('amount', this.state.amount);
    bodyFormData.set('purpose', this.state.purpose);
    bodyFormData.set('id_product[0]', this.state.title1);
    bodyFormData.set('amount_product[0]', this.state.amount1);
    bodyFormData.set('id_product[1]', this.state.title2);
    bodyFormData.set('amount_product[1]', this.state.amount2);
    bodyFormData.set('id_product[2]', this.state.title3);
    bodyFormData.set('amount_product[2]', this.state.amount3);

    const url = `${this.state.API_URL}/contact_requirement/update/` + this.state.id_requirement ;
    axios.post(url,bodyFormData, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        this.props.history.push({
          pathname: '/contact-detail',
          id: this.state.id_contact 
        })
     })
    
  }
  componentWillMount() {
    const { id,contact } = this.props.location
    console.log('ini data kiriman : ', id)
    const urlid = `${this.state.API_URL}/contact_requirement/detail/`+ id
    axios.get(urlid, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ contact: data, 
      amount: data.amount,
      amount1: data.product[0].amount,
      amount2: data.product[1].amount,
      amount3: data.product[2].amount,
      purpose: data.purpose,
      title1: data.product[0].product_title,
      title2: data.product[1].product_title,
      title3: data.product[2].product_title,
      id_requirement: data.id,
      id_contact: contact
      })
      
     })

     
    const url = `${this.state.API_URL}/bank/product_lists` ;
    axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ kategori: data })
      console.log('data API : ',this.state.kategori)
     })
  }
  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="8"></Col>
        <Row>
          <Col xs="12" sm="8">
            <Card>
              <CardHeader>

         <Button color="transparant"  onClick={() => this.backTo()}  className="mr-1"><i className="fa fa-chevron-left"></i> </Button>
    
         
                <strong>Loan Requirement</strong>
                <small> </small>
                <div className="card-header-actions">
         

         <Button color="danger"  onClick={this.toggleDanger} className="mr-1"><i className="fa fa-trash"></i> Hapus</Button>
    
         
                  </div>
                     <Modal isOpen={this.state.notif_delete} toggle={this.toggleDanger}
                  className={'modal-danger ' + this.props.className}>
             <ModalHeader toggle={this.toggleDanger}>Hapus Requirement</ModalHeader>
             <ModalBody>
               Apakah kamu yakin ingin menghapus Requirement?
             </ModalBody>
             <ModalFooter>
               <Button color="danger" onClick={() => this.delete()}>Hapus</Button>{' '}
               <Button color="secondary" onClick={this.toggleDanger}>Batal</Button>
             </ModalFooter>
           </Modal>
              </CardHeader>
              <CardBody>
              <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Total Mount</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.amount} onChange={(event)=> this.setState({amount: event.target.value})} type="number" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Loan Purpose</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.purpose} onChange={(event)=> this.setState({purpose: event.target.value})} type="text" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
              
                
                <Row>
                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Loan Type 1</strong>
                    </Col>
                    <Col xs="12" md="9">
                      {/* <Input value={this.state.title1} onChange={(event)=> this.setState({title1: event.target.value})} type="input" id="text-input" name="text-input" bsSize="sm">
                       
                      </Input> */}
                      
                      <Input value={this.state.title1} onChange={(event)=> this.setState({title1: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                       {this.state.kategori.map(kategori => (
                          
                              <option value={kategori.id} >{kategori.title}</option>
                            ))}
                     
                    </Input> 
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
              
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Loan Amount 1</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.amount1} onChange={(event)=> this.setState({amount1: event.target.value})} type="number" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>

                   
                <Row>
                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Loan Type 2</strong>
                    </Col>
                    <Col xs="12" md="9">
                      {/* <Input value={this.state.title2} onChange={(event)=> this.setState({title2: event.target.value})} type="input" id="text-input" name="text-input" bsSize="sm">
                      
                      </Input> */}
                      
                      <Input value={this.state.title2} onChange={(event)=> this.setState({title2: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                       {this.state.kategori.map(kategori => (
                          
                              <option value={kategori.id} >{kategori.title}</option>
                            ))}
                     
                    </Input> 
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
              
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Loan Amount 2</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.amount2} onChange={(event)=> this.setState({amount2: event.target.value})} type="number" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
            


               
                <Row>
                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Loan Type 3</strong>
                    </Col>
                    <Col xs="12" md="9">
                      {/* <Input value={this.state.title3} onChange={(event)=> this.setState({title3: event.target.value})} type="input" id="text-input" name="text-input" bsSize="sm">
                     >
                      </Input> */}
                      
                      <Input value={this.state.title3} onChange={(event)=> this.setState({title3: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                       {this.state.kategori.map(kategori => (
                          
                              <option value={kategori.id} >{kategori.title}</option>
                            ))}
                     
                    </Input> 
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
              
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Loan Amount 3</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.amount3} onChange={(event)=> this.setState({amount3: event.target.value})} type="number" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
            
            

        
               
              </CardBody>
              <CardFooter>
                <Button onClick={() => this.submit()}  size="sm" color="primary"> <strong>Update</strong></Button>
                <Button size="sm" color="transparant"> <strong></strong></Button>
              </CardFooter>
            </Card>
          </Col>

      
      
        </Row>
      </div>
    );
  }
}

export default Forms;
