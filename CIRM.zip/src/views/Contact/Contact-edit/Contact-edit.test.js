import React from 'react';
import ReactDOM from 'react-dom';
import ContactEdit from './Contact-edit';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<ContactEdit />, div);
  ReactDOM.unmountComponentAtNode(div);
});
