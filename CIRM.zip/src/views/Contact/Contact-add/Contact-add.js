import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import {
  Badge,
  Button,
  Select,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';
import axios from 'axios';
class App extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300,
      kategori:[],
      selectedValue: '5',
      userid:1,
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      name: 'sujatmiko',
      company: 'CV BPI',
      position: 'manajer',
      address: 'bandung',
      phone: '089601777308',
      email: 'sujatmiko@gmail.com',
    };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }
  
  onChange = e => {
    const { value } = e.target;
    this.setState({
      selectedValue: value
    });

 
  };
  
  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }
  
  
  submit() {
    
    var bodyFormData = new FormData();
    bodyFormData.set('id_user', this.state.userid);
    bodyFormData.set('phone', this.state.phone);
    bodyFormData.set('name', this.state.name);
    bodyFormData.set('email', this.state.email);
    bodyFormData.set('company', this.state.company);
    bodyFormData.set('position', this.state.position);
    bodyFormData.set('address', this.state.address);
    bodyFormData.set('id_contact_category', this.state.selectedValue);
 
    console.log('data cok', this.state)
    const url = `${this.state.API_URL}/contact/insert`;
    axios.post(url,bodyFormData, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        this.props.history.push({
          pathname: '/contact',
        })

     })
  }
  componentWillMount() {
    const url = `${this.state.API_URL}/contact_category_master/lists_by_user/` + this.state.userid;
    axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ kategori: data })
      console.log('data API : ',this.state.kategori)
     })

   

  }
  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="6"></Col>
        <Row>
          <Col  xs="12" sm="6" >
            <Card>
              <CardHeader>
                <strong>Add Contact</strong>
                <small> </small>
              </CardHeader>
              <CardBody>
              <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Nama Lengkap</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input  onChange={(event)=> this.setState({name: event.target.value})} type="text" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Jabatan</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={(event)=> this.setState({position: event.target.value})} type="text" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Perusahaan</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={(event)=> this.setState({company: event.target.value})} type="text" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Kategori</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={(event)=> this.setState({selectedValue: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.kategori.map(kategori => (
                            
                                <option  value={kategori.id} >{kategori.name}</option>
                              ))}
                       
                      </Input> 
                      {/* <Input onChange={this.handleChange} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.kategori.map(kategori => (
                            
                                <option value={kategori.package} data-id={kategori.id} ref={kategori.name} key={kategori.id}  >{kategori.name}</option>
                              ))}
                       
                      </Input>  */}
                      {/*  <Select
                      value={this.state.kategori}
                      onChange={this.handleChange}
                      /> */}

                      {/* <input
                                type="text"
                                className="search-box"
                                placeholder="Search for..."
                                onChange={this.onChange}
                              />
                              {this.state.kategori.map(kategori => (
                                <ul key={kategori.name}>
                                  <li>{kategori.name}</li>
                                </ul>
                              ))} */}

                      
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Email</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input  onChange={(event)=> this.setState({email: event.target.value})} type="email" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
                   
                    <strong>Phone</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={(event)=> this.setState({phone: event.target.value})} type="number" id="text-input" name="text-input" placeholder="" />
                       </Col>
                  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
                   
                    <strong>Alamat</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={(event)=> this.setState({address: event.target.value})} type="text" id="text-input" name="text-input" placeholder="" />
                       </Col>
                  </FormGroup>
                  </Col>
                </Row>
        
               
              </CardBody>
              <CardFooter>
                
                <Button onClick={() => this.submit()} size="sm" color="primary"> <strong>Submit</strong></Button>
            
                <Button size="sm" color="transparant"> <strong></strong></Button>
              </CardFooter>
            </Card>
          </Col>

      
      
        </Row>
      </div>
    );
  }
}

export default App;
