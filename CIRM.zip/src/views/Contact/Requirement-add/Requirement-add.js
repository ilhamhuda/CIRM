import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Select,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form, Modal, ModalBody, ModalFooter, ModalHeader,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';
import axios from 'axios';
class Forms extends Component {
  constructor(props) {
    super(props);

    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300,
      id_contact: 1,
      kategori:[],
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      notif_delete: false,
      id_requirement: 1,
      amount: 0,
      purpose: '',
      amount1:0,
      amount2: 0,
      amount3: 0,
      title1: 1,
      title2: 1,
      title3:1
    };
  
  }

  
  componentWillMount() {
    const { id } = this.props.location
    this.setState({ id_contact: id})

    const url = `${this.state.API_URL}/bank/product_lists` ;
    axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ kategori: data })
      console.log('data API : ',this.state.kategori)
     })
    
  }
  backTo() {
    
     this.props.history.push({
          pathname: '/contact-detail',
          id: this.state.id_contact 
        })
  }
  submit() {

    
    var bodyFormData = new FormData();
    bodyFormData.set('amount', this.state.amount);
    bodyFormData.set('purpose', this.state.purpose);
    bodyFormData.set('id_contact', this.state.id_contact);
    bodyFormData.set('id_product[0]', this.state.title1);
    bodyFormData.set('amount_product[0]', this.state.amount1);
    bodyFormData.set('id_product[1]', this.state.title2);
    bodyFormData.set('amount_product[1]', this.state.amount2);
    bodyFormData.set('id_product[2]', this.state.title3);
    bodyFormData.set('amount_product[2]', this.state.amount3);


    const url = `${this.state.API_URL}/contact_requirement/insert` ;
    axios.post(url,bodyFormData, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        this.props.history.push({
          pathname: '/contact-detail',
          id: this.state.id_contact 
        })

     })
    }
    
     render() {
      return (
        <div className="animated fadeIn">
           <Button size="sm" color="transparant"> <strong></strong></Button>
                 
          <Col xs="12" sm="8"></Col>
          <Row>
            <Col xs="12" sm="8">
              <Card>
                <CardHeader>
                 <Button color="transparant"  onClick={() => this.backTo()}  className="mr-1"><i className="fa fa-chevron-left"></i> </Button>
    
                  <strong>Loan Requirement</strong>
                  <small> </small>
         
                </CardHeader>
                <CardBody>
                <Row>
                    <Col xs="12">
                    <FormGroup row>
                      <Col md="3">
                 
                        <strong>Total Mount</strong>
                    
                      </Col>
                      <Col xs="12" md="9">
                        <Input value={this.state.amount} onChange={(event)=> this.setState({amount: event.target.value})} type="number" id="text-input" name="text-input" placeholder="" />
                           </Col>
                    </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col xs="12">
                    <FormGroup row>
                      <Col md="3">
                 
                        <strong>Loan Purpose</strong>
                    
                      </Col>
                      <Col xs="12" md="9">
                        <Input value={this.state.purpose} onChange={(event)=> this.setState({purpose: event.target.value})} type="text" id="text-input" name="text-input" placeholder="" />
                           </Col>
                    </FormGroup>
                    </Col>
                  </Row>
                
                  
                  <Row>
                    <Col xs="12">
             
                      <FormGroup row>
                      <Col md="3">
                      <strong>Loan Type 1</strong>
                      </Col>
                      <Col xs="12" md="9">
                        {/* <Input value={this.state.title1} onChange={(event)=> this.setState({title1: event.target.value})} type="input" id="text-input" name="text-input" bsSize="sm">
                         
                        </Input> */}
                        <Input value={this.state.title1} onChange={(event)=> this.setState({title1: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                       {this.state.kategori.map(kategori => (
                          
                              <option  value={kategori.id} >{kategori.title}</option>
                            ))}
                     
                    </Input> 
                      </Col>
                    </FormGroup>
                    </Col>
                  </Row>
                
                  <Row>
                    <Col xs="12">
                    <FormGroup row>
                      <Col md="3">
                 
                        <strong>Loan Amount 1</strong>
                    
                      </Col>
                      <Col xs="12" md="9">
                        <Input value={this.state.amount1} onChange={(event)=> this.setState({amount1: event.target.value})} type="number" id="text-input" name="text-input" placeholder="" />
                           </Col>
                    </FormGroup>
                    </Col>
                  </Row>
  
                     
                  <Row>
                    <Col xs="12">
             
                      <FormGroup row>
                      <Col md="3">
                      <strong>Loan Type 2</strong>
                      </Col>
                      <Col xs="12" md="9">
                        {/* <Input value={this.state.title2} onChange={(event)=> this.setState({title2: event.target.value})} type="input" id="text-input" name="text-input" bsSize="sm">
                        
                        </Input> */}

                        <Input value={this.state.title2} onChange={(event)=> this.setState({title2: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                       {this.state.kategori.map(kategori => (
                          
                              <option value={kategori.id} >{kategori.title}</option>
                            ))}
                     
                    </Input> 
                      </Col>
                    </FormGroup>
                    </Col>
                  </Row>
                
                  <Row>
                    <Col xs="12">
                    <FormGroup row>
                      <Col md="3">
                 
                        <strong>Loan Amount 2</strong>
                    
                      </Col>
                      <Col xs="12" md="9">
                        <Input value={this.state.amount2} onChange={(event)=> this.setState({amount2: event.target.value})} type="number" id="text-input" name="text-input" placeholder="" />
                           </Col>
                    </FormGroup>
                    </Col>
                  </Row>
              
  
  
                 
                  <Row>
                    <Col xs="12">
             
                      <FormGroup row>
                      <Col md="3">
                      <strong>Loan Type 3</strong>
                      </Col>
                      <Col xs="12" md="9">
                        {/* <Input value={this.state.title3} onChange={(event)=> this.setState({title3: event.target.value})} type="input" id="text-input" name="text-input" bsSize="sm">
                       >
                        </Input> */}
                        <Input value={this.state.title3} onChange={(event)=> this.setState({title3: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                       {this.state.kategori.map(kategori => (
                          
                              <option  value={kategori.id} >{kategori.title}</option>
                            ))}
                     
                    </Input> 
                      </Col>
                    </FormGroup>
                    </Col>
                  </Row>
                
                  <Row>
                    <Col xs="12">
                    <FormGroup row>
                      <Col md="3">
                 
                        <strong>Loan Amount 3</strong>
                    
                      </Col>
                      <Col xs="12" md="9">
                        <Input value={this.state.amount3} onChange={(event)=> this.setState({amount3: event.target.value})} type="number" id="text-input" name="text-input" placeholder="" />
                           </Col>
                    </FormGroup>
                    </Col>
                  </Row>
              
              
  
          
                 
                </CardBody>
                <CardFooter>
                  <Button onClick={() => this.submit()}  size="sm" color="primary"> <strong>Submit</strong></Button>
                  <Button size="sm" color="transparant"> <strong></strong></Button>
                </CardFooter>
              </Card>
            </Col>
  
        
        
          </Row>
        </div>
      );
    }
  }
  
  export default Forms;