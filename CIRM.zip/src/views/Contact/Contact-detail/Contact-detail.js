import React, {Component} from 'react';
import {Badge,Card, ButtonDropdown,
  ButtonGroup,
  ButtonToolbar,Dropdown,
  DropdownItem,
  DropdownMenu,CardHeader, Modal, ModalBody, ModalFooter, ModalHeader,
  DropdownToggle, CardBody, Col, Button,Nav, NavItem, NavLink, Row, TabContent, TabPane} from 'reactstrap';
import classnames from 'classnames';
import { Link } from 'react-router-dom';
import axios from 'axios';

class App extends Component {

  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      activeTab: new Array(4).fill('1'),
      contact:[],
      note: [],
      requirement: [],
      application: [],
      notif_delete: false,
      contact_id: null,
      id_user: null,
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm'
    };
    this.toggleDanger = this.toggleDanger.bind(this);
  }
  toggleDanger() {
    this.setState({
      notif_delete: !this.state.notif_delete
    });
  }
  

  

  componentWillMount() {
    const { id,id_user } = this.props.location
    console.log('ini data kiriman : ', id)
    this.state.contact   = localStorage.getItem("userID");
    const url = `${this.state.API_URL}/contact/detail/`+ this.state.contact
    axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ contact: data, contact_id:id, id_user:id_user })
      console.log('data kontak', this.state.contact_id, id )
 
     })

  
     const urlnote = `${this.state.API_URL}/contact_note/lists_by_contact/`+ id
    axios.get(urlnote, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ note: data })
 
     })


     const urlrequire = `${this.state.API_URL}/contact_requirement/lists_by_contact/`+ id
    axios.get(urlrequire, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ requirement: data })
   
     })


     const urlapp = `${this.state.API_URL}/application/lists_by_contact/`+ id
    axios.get(urlapp, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ application: data })
   
     })

  }

  submit_editcontact() {
    this.props.history.push({
      pathname: '/edit-contact',
      id: this.state.contact_id 
    })
    }
    submit_access() {
    this.props.history.push({
      pathname: '/akses',
      id: this.state.contact_id,
      id_user: this.state.id_user 
    })
    }
  
    submit_detailnote(id) {
    this.props.history.push({
      pathname: '/note',
      id: id, 
      contact: this.state.contact_id
    })
    }
  
    submit_addnote(id) {
      this.props.history.push({
        pathname: '/note-add',
        id: this.state.contact_id 
      })
      }
  
    submit_detailrequirement(id) {
      this.props.history.push({
        pathname: '/requirement-detail',
        id: id,
        contact: this.state.contact_id
      })
      }
  
      submit_addrequirement(id) {
        this.props.history.push({
          pathname: '/requirement-add',
          id: this.state.contact_id 
        })
        }
  
  delete() {
    const url = `${this.state.API_URL}/contact/delete/` + this.state.contact_id ;
    axios.post(url,{}, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        
     this.setState({
      notif_delete: !this.state.notif_delete,
    });

      this.props.history.push({
      pathname: '/contact',
    })

     })

 
  }

 

  note(listing) {
    return (
     
      <Row>
       
        <Col >
          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
              <strong> {listing.title}</strong>
              <br></br>
             <small>{listing.note}</small>
               <br></br>
               <small> <strong>  <i className="fa fa-calendar"></i> &nbsp;
                    {listing.created_date}</strong></small>
               </Col>
              <div className="card-header-actions">
          
                      <Button onClick={() => this.submit_detailnote(listing.id)} color="primary" className="px-1">View Detail</Button>
                      </div>
              </Row>
            
            </CardHeader>
          
          </Card>
       
        </Col>
      </Row>
   
    )
   }
   loan(listing) {
    return (
     
      <Row>
       
        <Col >
          <Card>
            <CardHeader>
            <Row style={{marginRight:10}}>
         
         <Col  >
        <strong> Status Pinjaman</strong>
         <br></br>
          <small>{listing.loan_step}</small>
          <br></br>
          <small>Periode : {listing.periodeYear}</small>
          <br></br>
          <small> <strong>  <i className="fa fa-calendar"></i> &nbsp;
               {listing.create_time}</strong></small>
          </Col>
         <div className="card-header-actions">
         <Link to="/detail-pinjaman">
                 <Button color="primary" className="px-1">View Detail</Button>
                    </Link>   </div>
         </Row>
            </CardHeader>
          
          </Card>
       
        </Col>
      </Row>
   
    )
   }
   cpa() {
    return (
     
      <Row>
       
        <Col >
          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong>Detail CPA</strong>
              <br></br>
           </Col>
              <div className="card-header-actions">
              <Link to="/detail-pekerjaan">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>   </div>
              </Row>
            
            </CardHeader>
          
          </Card>
       
        </Col>
      </Row>
   
    )
   }

   requirement(listing) {
    return (
     
      <Row>
       
        <Col>
          <Card>
            <CardHeader>
           
              <Row style={{marginRight:10}}>
         
              <Col  >
               <strong>Tujuan Pinjaman</strong>
               <br></br>
             <small> {listing.purpose}</small>
              <br></br>
             <small>Total Pinjaman : Rp. {listing.amount},-</small>
               <br></br>
               <small> <strong>  <i className="fa fa-calendar"></i> &nbsp;
                    {listing.created_date}</strong></small>
               </Col>
              <div className="card-header-actions">
      
                      <Button onClick={() => this.submit_detailrequirement(listing.id)} color="primary" className="px-1">View Detail</Button>
                        </div>
              </Row>
            </CardHeader>
          
          </Card>
       
        </Col>
      </Row>
   
    )
   }
  toggle(tabPane, tab) {
    const newArray = this.state.activeTab.slice()
    newArray[tabPane] = tab
    this.setState({
      activeTab: newArray,
    });
  }

  tabPane() {
    return (
      <>
        <TabPane tabId="1">
        <div
        style={{
          display: "flex",
       
        }}
      >
       
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button onClick={() => this.submit_addnote()} style={{margin:10}}  color="primary" >  <i className="fa fa-plus-square"></i> Tambah</Button>
                   
                  
                       </div>
                       {this.state.note.map((item)=>this.note(item))}
        </TabPane>
        <TabPane tabId="2">
        <div
        style={{
          display: "flex",
        
        }}
      >
    
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button onClick={() => this.submit_addrequirement()}  style={{margin:10}}  color="primary" >  <i className="fa fa-plus-square"></i> Tambah</Button>
                   
                     
                       </div>
                       {this.state.requirement.map((item)=>this.requirement(item))}
        </TabPane>
  
        <TabPane tabId="4">
        <div
        style={{
          display: "flex",
        
        }}
      >
        <Link to="/application-add" >
                <Button style={{margin:10}}  color="primary" >  <i className="fa fa-plus-square"></i> Tambah</Button>
                   
                       </Link>
                       </div>
        {this.state.application.map((item)=>this.loan(item))}
       </TabPane>
      </>
    );
  }

  render() {
    return (
      <div className="animated fadeIn" style={{marginLeft:-35, marginRight:-35}}>
        <br></br>
        <br></br>
        <Col>
        <Col xs="12" md="6" className="mb-4">
            <Card className="text-white bg-info">
              <CardBody className="pb-0">
                <ButtonGroup className="float-right">
                <Button active block style={{width:10}} color="transparant" aria-pressed="true"></Button>
              
                <Button onClick={() => this.submit_access()}  active block style={{width:70,marginRight:10}} color="primary" aria-pressed="true">Akses</Button>
               
                     <Button color="danger"  onClick={this.toggleDanger} className="mr-1"><i className="fa fa-trash"></i> </Button>
          
                
                </ButtonGroup>
                <Modal isOpen={this.state.notif_delete} toggle={this.toggleDanger}
                       className={'modal-danger ' + this.props.className}>
                  <ModalHeader toggle={this.toggleDanger}>Hapus Contact</ModalHeader>
                  <ModalBody>
                    Apakah kamu yakin ingin menghapus Contact?
                  </ModalBody>
                  <ModalFooter>
                    <Button color="danger" onClick={() => this.delete()}>Hapus</Button>{' '}
                    <Button color="secondary" onClick={this.toggleDanger}>Batal</Button>
                  </ModalFooter>
                </Modal>
            <div className="text-value">{this.state.contact.name}</div>
                <i className="fa fa-user"></i>  <small> {this.state.contact.position}</small>
                 <br></br>
                 <i className="fa fa-vcard"></i> <small> {this.state.contact.category}</small>
                 <br></br>
                 <i className="fa fa-university"></i> <small> {this.state.contact.company}</small>
                 <br></br>
                 <i className="fa fa-envelope-o"></i> <small> {this.state.contact.email}</small>
                 <br></br>
                 <i className="fa fa-phone"></i> <small> {this.state.contact.phone}</small>
                 <br></br>
           <br></br>
           

           <Row>
        
       
           <Button onClick={() => this.submit_editcontact()} active block style={{width:40,marginRight:10,marginLeft:10}} color="primary" aria-pressed="true"><i className="fa fa-pencil"></i> </Button>
          
           </Row>
         
        
           <br></br>
              </CardBody>
            
            </Card>
          </Col>
          <Col xs="12" md="6" className="mb-4">
            <Nav tabs>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '1'}
                  onClick={() => { this.toggle(0, '1'); }}
                >
                  <strong>Note</strong>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '2'}
                  onClick={() => { this.toggle(0, '2'); }}
                >
                    <strong>Requirement</strong>
                </NavLink>
              </NavItem>

              {/* <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '3'}
                  onClick={() => { this.toggle(0, '3'); }}
                >
                    <strong>CPA</strong>
                </NavLink>
              </NavItem> */}
         
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '4'}
                  onClick={() => { this.toggle(0, '4'); }}
                >
                    <strong>Application</strong>
                </NavLink>
              </NavItem>

            </Nav>
            <TabContent activeTab={this.state.activeTab[0]}>
              {this.tabPane()}
            </TabContent>
          </Col>
        
          </Col>
        <br></br>

     

      </div>
    );
  }
}

export default App;
