import React from 'react';
import ReactDOM from 'react-dom';
import Contactdetail from './Contact-detail';
import {mount} from 'enzyme/build';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Contactdetail />, div);
  ReactDOM.unmountComponentAtNode(div);
});
it('toggle click without crashing', () => {
  const wrapper = mount(<Contactdetail />);
  for (let i=0; i<2; i++) {
    let Nav = wrapper.find('a.dropdown-toggle').at(i);
    Nav.simulate('click');
    expect(wrapper.state().dropdownOpen[i]).toEqual(true);
  }
  wrapper.unmount()
});
