import Contactdetail from './Contact-detail/Contact-detail';
import Contactlist from './Contact-list/Contact-list';
import Contactadd from './Contact-add/Contact-add';
import Contactedit from './Contact-edit/Contact-edit';


export {
  Contactdetail, Contactlist,Contactadd, Contactedit
}
