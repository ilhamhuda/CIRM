import React from 'react';
import ReactDOM from 'react-dom';
import Noteadd from './Note-add';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Noteadd />, div);
  ReactDOM.unmountComponentAtNode(div);
});
