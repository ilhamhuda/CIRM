import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';
import axios from 'axios';
class Forms extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300,
      id_contact: 1,
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      note: null,
      title: null,
    };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }


  
  submit() {
    
    var bodyFormData = new FormData();
    bodyFormData.set('id_contact', this.state.id_contact);
    bodyFormData.set('title', this.state.title);
    bodyFormData.set('note', this.state.note);

    const url = `${this.state.API_URL}/contact_note/insert`;
    axios.post(url,bodyFormData, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        this.props.history.push({
          pathname: '/contact-detail',
          id: this.state.id_contact 
        })
        

     })
  }
   backTo() {
    
     this.props.history.push({
          pathname: '/contact-detail',
          id: this.state.id_contact 
        })
  }
  componentWillMount() {
    const { id } = this.props.location
    this.setState({ id_contact: id})
    
  }
  backTo() {
    
     this.props.history.push({
          pathname: '/contact-detail',
          id: this.state.id_contact 
        })
  }
  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="6"></Col>
        <Row>
          <Col xs="12" sm="6">
            <Card>
              <CardHeader>
                   <Button color="transparant"  onClick={() => this.backTo()}  className="mr-1"><i className="fa fa-chevron-left"></i> </Button>
    
                <strong>Detail Note</strong>
                <small> </small>
              </CardHeader>
              <CardBody>
              <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Title Note</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={(event)=> this.setState({title: event.target.value})} type="text" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
               
                
              
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong></strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={(event)=> this.setState({note: event.target.value})} type="textarea" name="textarea-input" id="textarea-input" rows="9" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
              
       
        
               
              </CardBody>
              <CardFooter>
                <Button onClick={() => this.submit()} size="sm" color="primary"> <strong>Submit</strong></Button>
                <Button size="sm" color="transparant"> <strong></strong></Button>
              </CardFooter>
            </Card>
          </Col>

      
      
        </Row>
      </div>
    );
  }
}

export default Forms;
