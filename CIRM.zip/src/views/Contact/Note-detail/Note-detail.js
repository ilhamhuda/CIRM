import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup
  , Modal, ModalBody, ModalFooter, ModalHeader,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';
import axios from 'axios';
class Forms extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300,
      id_contact: 1,
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      note: null,
      id_note: 10,
      notif_delete: false,
      title: null,
    };
    this.toggleDanger = this.toggleDanger.bind(this);
  }
  toggleDanger() {
    this.setState({
      notif_delete: !this.state.notif_delete,
    });
  }
  
  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }

  delete() {
    const url = `${this.state.API_URL}/contact_note/delete/` + this.state.id_note ;
    axios.post(url,{}, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        
     this.setState({
      notif_delete: !this.state.notif_delete,
    });

    this.props.history.push({
      pathname: '/contact-detail',
      id: this.state.id_contact 
    })

     })

 
  }
  
  submit() {
    
    var bodyFormData = new FormData();
    bodyFormData.set('title', this.state.title);
    bodyFormData.set('note', this.state.note);

    const url = `${this.state.API_URL}/contact_note/update/` + this.state.id_note ;
    axios.post(url,bodyFormData, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        this.props.history.push({
          pathname: '/contact-detail',
          id: this.state.id_contact 
        })

     })
    
  }
  componentWillMount() {
    const { id,contact } = this.props.location
    console.log('ini data kiriman : ', id)
    
    const urlid = `${this.state.API_URL}/contact_note/detail/`+ id
    axios.get(urlid, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ contact: data, 
      note: data.note,
      title: data.title,
      id_note: data.id,
      id_contact: contact


      })
      
     })


   

  }
  backTo() {
    
     this.props.history.push({
          pathname: '/contact-detail',
          id: this.state.id_contact 
        })
  }
  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="8"></Col>
        <Row>
          <Col xs="12" sm="8">
            <Card>
              <CardHeader>
               <Button color="transparant"  onClick={() => this.backTo()}  className="mr-1"><i className="fa fa-chevron-left"></i> </Button>
    
                <strong>Detail Note</strong>
                <small> </small>
                <div className="card-header-actions">
         

              <Button color="danger"  onClick={this.toggleDanger} className="mr-1"><i className="fa fa-trash"></i> Hapus</Button>
         
              
                       </div>
                          <Modal isOpen={this.state.notif_delete} toggle={this.toggleDanger}
                       className={'modal-danger ' + this.props.className}>
                  <ModalHeader toggle={this.toggleDanger}>Hapus Note</ModalHeader>
                  <ModalBody>
                    Apakah kamu yakin ingin menghapus Note?
                  </ModalBody>
                  <ModalFooter>
                    <Button color="danger" onClick={() => this.delete()}>Hapus</Button>{' '}
                    <Button color="secondary" onClick={this.toggleDanger}>Batal</Button>
                  </ModalFooter>
                </Modal>
              </CardHeader>
              <CardBody>
              <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Title Note</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.title} onChange={(event)=> this.setState({title: event.target.value})} type="text" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
               
                
              
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong></strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.note} onChange={(event)=> this.setState({note: event.target.value})} type="textarea" name="textarea-input" id="textarea-input" rows="9" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
              
       
        
               
              </CardBody>
              <CardFooter>
                <Button onClick={() => this.submit()} size="sm" color="primary"> <strong>Update</strong></Button>
                <Button size="sm" color="transparant"> <strong></strong></Button>
              </CardFooter>
            </Card>
          </Col>

      
      
        </Row>
      </div>
    );
  }
}

export default Forms;
