import React from 'react';
import ReactDOM from 'react-dom';
import Contactlist from './Contact-list';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Contactlist />, div);
  ReactDOM.unmountComponentAtNode(div);
});
