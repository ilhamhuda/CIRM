import React, { Component } from 'react';
import { Badge, Button, Card, CardBody, CardFooter, InputGroup,Input,FormGroup, InputGroupAddon,CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
class Collapses extends Component {

  constructor(props) {
    super(props);
   
    this.state = {
      userid:null,
      id_contact:null,
      id_user: null,
      access:[],
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm/contact_access/'
    };
  }



  access(listing) {
    return(
      <Card key={listing.id}>
      <CardHeader>
        <Row style={{margin:10}}>
        
        <Col  >
    <strong>{listing.name}</strong>
        <br></br>
        
         <small>{listing.office}</small>
         <br></br>
    
         </Col>
         <div className="card-header-actions">
         <Link>
         {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
         <Button onClick={() => this.submit(listing.id)} style={{color:'white', backgroundColor:'#ff4e45',}} className="px-2"><i className="fa fa-trash"></i>  </Button>
           
               </Link>   </div>
        </Row>
      
      </CardHeader>
    
    </Card>
    )
  }

  reload() {
    const urlmy = `${this.state.API_URL}lists_by_contact/`+ this.state.id_contact;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ access: data })
   
     })
  }
  addaccess() {
    this.props.history.push({
      pathname: '/add-akses',
      id: this.state.id_contact,
      id_user: this.state.id_user 
    })
  }

  
  componentWillMount() {
    const { id,id_user } = this.props.location
    console.log('ini data kiriman : ', id)
    const urlmy = `${this.state.API_URL}lists_by_contact/`+ id;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ access: data, id_contact: id, id_user: id_user })
   
     })
   
     
  }

  submit(advisor) {
    
    var bodyFormData = new FormData();
    bodyFormData.set('id_advisor', advisor);
 
    console.log('data cok', this.state)
    const url = `${this.state.API_URL}delete/` + this.state.id_contact;
    axios.post(url,bodyFormData, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        this.reload()

     })
  }
  
  backTo() {
    
     this.props.history.push({
          pathname: '/contact-detail',
          id: this.state.id_contact 
        })
  }
  render() {
    return (
      <div className="animated fadeIn">
         <br></br>
         <Row>
     
          <Col xs="12" sm="6">
        
            <Card>
              <CardHeader>
           
               
               {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
               {/* <Button onClick={() => this.addaccess()}  style={{color:'white', backgroundColor:'#35d44f',}} className="px-2"><i className="fa fa-back"></i> </Button>
                  */}
               <Button color="transparant"  onClick={() => this.backTo()}  className="mr-1"><i className="fa fa-chevron-left"></i> </Button>
    
                <strong>Lists Access</strong>
                <small> </small>
                <div className="card-header-actions">
               
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button onClick={() => this.addaccess()}  style={{color:'white', backgroundColor:'#35d44f',}} className="px-2"><i className="fa fa-plus-square"></i> Tambah</Button>
                   
                           </div>
              </CardHeader>
             </Card>
         </Col>
         </Row>

        <Row>
         
          <Col xl="6">
          <FormGroup row>
                    <Col md="12">
                      <InputGroup>
                     
                        <Input type="text" id="input1-group2" name="input1-group2" placeholder="" />
                        <InputGroupAddon addonType="prepend">
                          <Button type="button" color="primary"><i className="fa fa-search"></i> Search</Button>
                        </InputGroupAddon>
                      </InputGroup>
                    </Col>
                  </FormGroup>
           
            {this.state.access.map((item)=>this.access(item))}
         
          </Col>
        </Row>
      </div>
    );
  }
}

export default Collapses;
