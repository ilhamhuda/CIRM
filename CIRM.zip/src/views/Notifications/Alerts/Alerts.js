import React, {Component} from 'react';
import {Badge,Card, ButtonDropdown,
  ButtonGroup,
  ButtonToolbar,Dropdown,
  DropdownItem,
  DropdownMenu,CardHeader,
  DropdownToggle, CardBody,FormGroup, Col, Button,Nav,InputGroup,InputGroupAddon,Input, NavItem, NavLink, Row, TabContent, TabPane} from 'reactstrap';
import classnames from 'classnames';
import { Link } from 'react-router-dom';

class Tabs extends Component {

  constructor(props) {
    super(props);

    this.state = {
     };
  }


  render() {
    return (
      <div className="animated fadeIn">

        <br></br>
        <Row>
          <Col xs="12" sm="6">
            
            <Card>
              <CardHeader>
                <strong>Detail Bank</strong>
                <small> </small>
                <div className="card-header-actions">
                 <Link to="/product-bank">
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button color="primary" style={{color:'white',}} className="px-2"><i className="fa fa-bank"></i> Produk</Button>
                   
                       </Link>
                </div>
              </CardHeader>
             </Card>
         </Col>
         </Row>
        <Row>
        <Col xs="12" md="6" className="mb-4">
            <Card className="text-white bg-info">
              <CardBody className="pb-0">
                <ButtonGroup className="float-right">
                <Button active block style={{width:10}} color="transparant" aria-pressed="true"></Button>
               <Link to="/product-bank">
                    </Link>   
           
                </ButtonGroup>
                <Row>
                <img 
                      src="https://www.bankmandiri.co.id/o/mandiri-corporate-theme/images/icon/bmri-chat-logo-256x256.jpeg"
                      alt="Avatar"
                      style={{borderRadius: '50%', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                      margin:5,
                  }}
                      />
                <strong style={{marginTop:10,marginLeft:10,}} className="text-value">Mandiri</strong>
       

                </Row>
                     <i className="fa fa-phone"></i> &nbsp;<small> +62212511946</small>
                <br></br>
                 <i className="fa fa-tv"></i> &nbsp;<small>http://www.mandiri.co.id</small>
                 <br></br>
                 <i className="fa fa-university"></i>&nbsp; <small > Jl. Jendral Sudirman no.kav1 RT1/RW3,Jakarta Pusat</small>
               
          
         
           

           <Row>
    
           &emsp;
          
           
           </Row>
         
       
              </CardBody>
            
            </Card>
          </Col>
        
        
          </Row>
         
      
        <Col xl="6">
          <FormGroup row>
                    <Col md="12">
                      <InputGroup>
                     
                        <Input type="text" id="input1-group2" name="input1-group2" placeholder="" />
                        <InputGroupAddon addonType="prepend">
                          <Button type="button" color="primary"><i className="fa fa-search"></i> Search</Button>
                        </InputGroupAddon>
                      </InputGroup>
                    </Col>
                  </FormGroup>
         
          </Col>
        <Col xl="6">
        <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong> Jakarta Pusat</strong>
              <br></br>
             </Col>
              <div className="card-header-actions">
              <Link to="/daftar-cabang">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>   </div>
              </Row>
            
            </CardHeader>
          
          </Card>

          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong>Jakarta Barat</strong>
              <br></br>
             </Col>
              <div className="card-header-actions">
              <Link to="/daftar-cabang">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>   </div>
              </Row>
            
            </CardHeader>
          
          </Card>


          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong>Jakarta Utara</strong>
              <br></br>
             </Col>
              <div className="card-header-actions">
              <Link to="/daftar-cabang">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>   </div>
              </Row>
            
            </CardHeader>
          
          </Card>

          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong>Jakarta Timur</strong>
              <br></br>
             </Col>
              <div className="card-header-actions">
              <Link to="/daftar-cabang">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>   </div>
              </Row>
            
            </CardHeader>
          
          </Card>

          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong>Jakarta Selatan</strong>
              <br></br>
             </Col>
              <div className="card-header-actions">
              <Link to="/daftar-cabang">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>   </div>
              </Row>
            
            </CardHeader>
          
          </Card>


          </Col>
      </div>
    );
  }
}

export default Tabs;
