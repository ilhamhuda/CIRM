import React, { Component } from 'react';
import { Badge,FormGroup,Input,Label, Button, Card, CardBody, CardFooter, CardHeader, Col, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import axios from 'axios';

class Badges extends Component {
   constructor(props) {
    super(props);


    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300,
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      title: '',
      Detail: '',
    };
  }

  componentWillMount() {
    const { id } = this.props.location
    console.log('ini data kiriman : ', id)
    const url = `${this.state.API_URL}/bank/product_detail/` + id;
    axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ Detail: data })
      console.log('data API : ',this.state.Detail)
     })

 


   

  }
  render() {
    return (
      <div className="animated fadeIn">
        <br></br>
        <Row>
          <Col xs="12" md="6">

          <h1> {this.state.Detail.title}</h1>


<div>{ ReactHtmlParser(this.state.Detail.content) }</div>
          </Col>
         
        </Row>

        <Row>
         
         <Col xl="6">
           <Card>
             <CardHeader>
               <Row style={{marginRight:10}}>
               
               <Col  >
              <strong>Mandiri</strong>
               <br></br>
              <small></small>

                </Col>
               <div className="card-header-actions">
               <Link to="/product-bank">
                     <Button color="primary" className="px-1">View Detail</Button>
                        </Link>   </div>
               </Row>
             
             </CardHeader>
           
           </Card>
        
           <Card>
             <CardHeader>
               <Row style={{marginRight:10}}>
           
               <Col  >
              <strong> Maybank</strong>
               <br></br>
                  
                <small></small>
          
                </Col>
               <div className="card-header-actions">
               <Link to="/product-bank">
                     <Button color="primary" className="px-1">View Detail</Button>
                        </Link>   </div>
               </Row>
             
             </CardHeader>
           
           </Card>
         </Col>
       </Row>
      </div>
    );
  }
}

export default Badges;
