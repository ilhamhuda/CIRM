import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';

class Forms extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300
    };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }

  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="6"></Col>
        <Row>
  
             

          <Col xs="12" md="6" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Detail Pinjaman</strong>
                <small> </small>
                <div className="card-header-actions">
                 <Link to="/application-add">
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button style={{color:'white', backgroundColor:'#35d44f',}} className="px-2"><i className="fa fa-pencil"></i> Edit</Button>
                   
                       </Link>
                </div>

              </CardHeader>
              <CardBody>
             
              <strong>Status Pinjaman</strong>
              <br></br>
              <small>Di Proses Advisor </small>
              <br></br>
           
              <small>__________________________________________________</small>
            
               
                <Row>
                  <Col xs="12">
                  <FormGroup row>
               
                    <Col md="9">
                      <FormGroup >
                      <i className="fa fa-user"></i> 
                  &nbsp; <Label check className="form-check-label" htmlFor="radio1"><strong>Nama Nasabah</strong></Label>
                   <br></br>
                   <small> Fajar Iswandi </small>
                  
                      </FormGroup>
                      <FormGroup >
                      <i className="fa fa-book"></i> 
                      &nbsp;<Label check className="form-check-label" htmlFor="radio2"><strong>Jenis Pinjaman</strong></Label>
                 <br></br>
                 <small> KPR (Kredit Kepemilikan Rumah)</small>
                     
                      </FormGroup>
                      <FormGroup >
                      <i className="fa fa-dollar"></i> 
                      &nbsp; <Label check className="form-check-label" htmlFor="radio3"><strong>Jumlah Pinjaman</strong></Label>
                 <br></br>
                 <small> 10.000.000</small>
              
                      </FormGroup>
                    
                      <FormGroup >
                      <i className="fa fa-calendar"></i> 
                      &nbsp; <Label check className="form-check-label" htmlFor="radio3"><strong>Tanggal Pengajuan</strong></Label>
                 <br></br>
                 <small> 19 Februari 2020 </small>
                   
                      </FormGroup>
                     <FormGroup >
                      <i className="fa fa-user"></i> 
                      &nbsp; <Label check className="form-check-label" htmlFor="radio3"><strong>Loan Advisor</strong></Label>
                   <br></br>
                   <small> Meiko Sari</small>
                      </FormGroup>
                     
                      <FormGroup >
                      <i className="fa fa-bank"></i> 
                      &nbsp; <Label check className="form-check-label" htmlFor="radio3"><strong>Bank</strong></Label>
                     <br></br>
                      <small> Maybank</small>
                      </FormGroup>
                     

                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
       
              </CardBody>
              <CardFooter>
                {/* <Button size="sm" color="success"> Upload</Button>
                <Button type="reset" size="sm" color="transparant"></Button>
               */}
              </CardFooter>
            </Card>
          </Col>



         
        </Row>
      </div>
    );
  }
}

export default Forms;
