import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';

class Forms extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300
    };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }

  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="6"></Col>
        <Row>
          <Col xs="12" md="6" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Data Bank Terpilih</strong>
                <small> </small>
              </CardHeader>
              <CardBody>

                <Card>
                <CardBody>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Bank</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input type="text" id="text-input" name="text-input" disabled placeholder="Mandiri" />
                         </Col>
                  </FormGroup>
                  </Col>

                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Wilayah</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input type="text" id="text-input" name="text-input" disabled placeholder="Jakarta Timur" />
                         </Col>
                  </FormGroup>
                  </Col>

                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Cabang</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input type="text" id="text-input" name="text-input" disabled placeholder="Cibubur" />
                         </Col>
                  </FormGroup>
                  </Col>
                 
                </Row>
              </CardBody>
                </Card>
            
           
                <Card>
                <CardBody>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Bank</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input type="text" id="text-input" name="text-input" disabled placeholder="Maybank" />
                         </Col>
                  </FormGroup>
                  </Col>

                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Wilayah</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input type="text" id="text-input" name="text-input" disabled placeholder="Kota Bandung" />
                         </Col>
                  </FormGroup>
                  </Col>

                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Cabang</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input type="text" id="text-input" name="text-input" disabled placeholder="Buah Batu" />
                         </Col>
                  </FormGroup>
                  </Col>
                 
                </Row>
              </CardBody>
                </Card>
            
              </CardBody>
              <CardFooter>
              <Link to="/upload-document">
                 <Button  size="sm" color="secondary"><strong>Sebelumnya</strong> </Button>
            
                       </Link>
   <div className="card-header-actions">

                      
                 <Link to="/detail-pinjaman">
                 <Button  size="sm" color="primary"><strong>Submit</strong> </Button>
            
                       </Link>
                </div>
              
              </CardFooter>
            </Card>
          </Col>

      
      
        </Row>
      </div>
    );
  }
}

export default Forms;
