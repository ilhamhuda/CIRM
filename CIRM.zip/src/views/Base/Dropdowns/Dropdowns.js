import React, { Component } from 'react';
import { Badge, Button, Card, CardBody, CardFooter, InputGroup,Input,FormGroup, InputGroupAddon,CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';

class Collapses extends Component {

  constructor(props) {
    super(props);
    this.onEntering = this.onEntering.bind(this);
    this.onEntered = this.onEntered.bind(this);
    this.onExiting = this.onExiting.bind(this);
    this.onExited = this.onExited.bind(this);
    this.toggle = this.toggle.bind(this);
    this.toggleAccordion = this.toggleAccordion.bind(this);
    this.toggleCustom = this.toggleCustom.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: false,
      accordion: [true, false, false],
      custom: [true, false],
      status: 'Closed',
      fadeIn: true,
      timeout: 300,
    };
  }

  onEntering() {
    this.setState({ status: 'Opening...' });
  }

  onEntered() {
    this.setState({ status: 'Opened' });
  }

  onExiting() {
    this.setState({ status: 'Closing...' });
  }

  onExited() {
    this.setState({ status: 'Closed' });
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleAccordion(tab) {

    const prevState = this.state.accordion;
    const state = prevState.map((x, index) => tab === index ? !x : false);

    this.setState({
      accordion: state,
    });
  }

  toggleCustom(tab) {

    const prevState = this.state.custom;
    const state = prevState.map((x, index) => tab === index ? !x : false);

    this.setState({
      custom: state,
    });
  }

  toggleFade() {
    this.setState({ fadeIn: !this.state.fadeIn });
  }

  render() {
    return (
      <div className="animated fadeIn">
         <br></br>
         <Row>
     
          <Col xs="12" sm="6">
        
            <Card>
              <CardHeader>
                <strong>Akses Kontak</strong>
                <small> </small>
                <div className="card-header-actions">
                <Link to="/add-akses">
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button style={{color:'white', backgroundColor:'#35d44f',}} className="px-2"><i className="fa fa-plus-square"></i> Tambah</Button>
                   
                       </Link>       </div>
              </CardHeader>
             </Card>
         </Col>
         </Row>

        <Row>
         
          <Col xl="6">
          <FormGroup row>
                    <Col md="12">
                      <InputGroup>
                     
                        <Input type="text" id="input1-group2" name="input1-group2" placeholder="" />
                        <InputGroupAddon addonType="prepend">
                          <Button type="button" color="primary"><i className="fa fa-search"></i> Search</Button>
                        </InputGroupAddon>
                      </InputGroup>
                    </Col>
                  </FormGroup>
            <Card>
              <CardHeader>
                <Row style={{margin:10}}>
                
                <Col  >
               <strong>Khairil Tasnim</strong>
                <br></br>
                 <small>Loan Advisor</small>
                 <br></br>
                 <small>Loan Market Alam Sutra</small>
                 </Col>
                 <div className="card-header-actions">
                 <Link >
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button style={{color:'white', backgroundColor:'#bd0a04',}} className="px-2"><i className="fa fa-trash"></i> Hapus </Button>
                   
                       </Link>   </div>
                </Row>
              
              </CardHeader>
            
            </Card>
         
            <Card>
              <CardHeader>
                <Row style={{margin:10}}>
            
                <Col  >
               <strong> Budi Marpaung</strong>
                <br></br>
                 <small>Loan Advisor</small>
                 <br></br>
                 <small>Loan Market Ciputat</small>
                 </Col>
                <div className="card-header-actions">
                <Link >
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button style={{color:'white', backgroundColor:'#bd0a04',}} className="px-2"><i className="fa fa-trash"></i> Hapus </Button>
                   
                       </Link>     </div>
                </Row>
              
              </CardHeader>
            
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Collapses;
