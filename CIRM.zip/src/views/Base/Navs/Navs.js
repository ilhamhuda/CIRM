import React, {Component} from 'react';
import {Badge,Card, ButtonDropdown,
  ButtonGroup,
  ButtonToolbar,Dropdown,
  DropdownItem,
  DropdownMenu,CardHeader,
  DropdownToggle, CardBody, Col, Button,Nav, NavItem, NavLink, Row, TabContent, TabPane} from 'reactstrap';
import classnames from 'classnames';
import { Link } from 'react-router-dom';

class Tabs extends Component {

  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      activeTab: new Array(4).fill('1'),
    };
  }

  note() {
    return (
     
      <Row>
       
        <Col >
          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong> Title Note</strong>
              <br></br>
               <small>Note</small>
               <br></br>
               <small> <strong>  <i className="fa fa-calendar"></i> &nbsp;
                    9 Februari 2020</strong></small>
               </Col>
              <div className="card-header-actions">
              <Link to="/note">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>  </div>
              </Row>
            
            </CardHeader>
          
          </Card>
       
        </Col>
      </Row>
   
    )
   }
   loan() {
    return (
     
      <Row>
       
        <Col >
          <Card>
            <CardHeader>
            <Row style={{marginRight:10}}>
         
         <Col  >
        <strong> Status Pinjaman</strong>
         <br></br>
          <small>Di Proses Loan Advisor</small>
          <br></br>
          <small> <strong>  <i className="fa fa-calendar"></i> &nbsp;
               9 Februari 2020</strong></small>
          </Col>
         <div className="card-header-actions">
         <Link to="/detail-pinjaman">
                 <Button color="primary" className="px-1">View Detail</Button>
                    </Link>   </div>
         </Row>
            </CardHeader>
          
          </Card>
       
        </Col>
      </Row>
   
    )
   }
   cpa() {
    return (
     
      <Row>
       
        <Col >
          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong>Detail CPA</strong>
              <br></br>
           </Col>
              <div className="card-header-actions">
              <Link to="/detail-pekerjaan">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>   </div>
              </Row>
            
            </CardHeader>
          
          </Card>
       
        </Col>
      </Row>
   
    )
   }

   requirement() {
    return (
     
      <Row>
       
        <Col>
          <Card>
            <CardHeader>
           
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong> Tujuan Peminjaman</strong>
              <br></br>
               <small>Rp. 10.000.000</small>
               <br></br>
               <small> <strong>  <i className="fa fa-calendar"></i> &nbsp;
                    9 Februari 2020</strong></small>
               </Col>
              <div className="card-header-actions">
              <Link to="/detail-pinjaman">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>   </div>
              </Row>
            </CardHeader>
          
          </Card>
       
        </Col>
      </Row>
   
    )
   }
  toggle(tabPane, tab) {
    const newArray = this.state.activeTab.slice()
    newArray[tabPane] = tab
    this.setState({
      activeTab: newArray,
    });
  }

  tabPane() {
    return (
      <>
        <TabPane tabId="1">
        <div
        style={{
          display: "flex",
       
        }}
      >
        <Link to="/note" >
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button style={{margin:10}}  color="primary" >  <i className="fa fa-plus-square"></i> Tambah</Button>
                   
                       </Link>
                       </div>
          {this.note()}
        </TabPane>
        <TabPane tabId="2">
        <div
        style={{
          display: "flex",
        
        }}
      >
        <Link to="/loan" >
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button style={{margin:10}}  color="primary" >  <i className="fa fa-plus-square"></i> Tambah</Button>
                   
                       </Link>
                       </div>
        {this.requirement()}
        </TabPane>
        <TabPane tabId="3">
        {this.cpa()}
        </TabPane>
        <TabPane tabId="4">
        {this.loan()}
       </TabPane>
      </>
    );
  }

  render() {
    return (
      <div className="animated fadeIn" style={{marginLeft:-35, marginRight:-35}}>
        <br></br>
        <br></br>
        <Col>
        <Col xs="12" md="6" className="mb-4">
            <Card className="text-white bg-info">
              <CardBody className="pb-0">
                <ButtonGroup className="float-right">
                <Button active block style={{width:10}} color="transparant" aria-pressed="true"></Button>
               <Link to="/akses">
                <Button active block style={{width:70,marginRight:10}} color="primary" aria-pressed="true">Akses</Button>
                     </Link>   
                <Button active block style={{width:40}} color="primary" aria-pressed="true"><i className="fa fa-trash"></i> </Button>
          
                </ButtonGroup>
              
                <div className="text-value">Budi Marpaung</div>
                <i className="fa fa-user"></i>  <small> Project Manager</small>
                 <br></br>
                 <i className="fa fa-vcard"></i> <small> In CPA Proccess</small>
                 <br></br>
                 <i className="fa fa-university"></i> <small> Loan Market Alam Sutera</small>
                 <br></br>
                 <i className="fa fa-envelope-o"></i> <small> budimarpaung@gmail.com</small>
                 <br></br>
                 <i className="fa fa-phone"></i> <small> 089601777308</small>
                 <br></br>
           <br></br>
           

           <Row>
        
         <Link to="/edit-contact">
           <Button active block style={{width:40,marginRight:10,marginLeft:10}} color="primary" aria-pressed="true"><i className="fa fa-pencil"></i> </Button>
               
                 </Link>  
           </Row>
         
        
           <br></br>
              </CardBody>
            
            </Card>
          </Col>
          <Col xs="12" md="6" className="mb-4">
            <Nav tabs>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '1'}
                  onClick={() => { this.toggle(0, '1'); }}
                >
                  <strong>Note</strong>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '2'}
                  onClick={() => { this.toggle(0, '2'); }}
                >
                    <strong>Requirement</strong>
                </NavLink>
              </NavItem>

              {/* <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '3'}
                  onClick={() => { this.toggle(0, '3'); }}
                >
                    <strong>CPA</strong>
                </NavLink>
              </NavItem> */}
         
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '4'}
                  onClick={() => { this.toggle(0, '4'); }}
                >
                    <strong>Application</strong>
                </NavLink>
              </NavItem>

            </Nav>
            <TabContent activeTab={this.state.activeTab[0]}>
              {this.tabPane()}
            </TabContent>
          </Col>
        
          </Col>
        <br></br>

     

      </div>
    );
  }
}

export default Tabs;
