import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';

class Forms extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300
    };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }

  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="6"></Col>
        <Row>
  
             

          <Col xs="12" md="6" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Upload Dokumen</strong>
                <small> </small>


              </CardHeader>
              <CardBody>
             
            
              
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>KTP Pemohon</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>

                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>KTP Pasangan</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>


                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>NPWP</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>

                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>KK (Kartu Keluarga)</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>


                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>Akte Nikah/Cerai</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>


                {/* <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>TDP/SIUP/NPWP</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row> */}

                {/* <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>PERUS</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row> */}
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>SPT</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>

                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>Slip Gaji</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>

                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>Slip Gaji</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>


                {/* <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>Rekening Koran</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row> */}

{/* 
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>Sertifikat Jaminan</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row> */}
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>Rekening Terakhir</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>Slip Gaji</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>Surat Keterangan</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>Akta Pisah Harta</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>Pernyataan Kepemilikan</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>SHM</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>IMB</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>PBB</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>

                {/* <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name"><strong>NJOP</strong></Label>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row> */}

    

           
       
              </CardBody>
              <CardFooter>
              <Link to="/detail-pekerjaan">
                 <Button  size="sm" color="secondary"><strong>Sebelumnya</strong> </Button>
            
                       </Link>
                       <div className="card-header-actions">

                     <Link to="/cpa-bank">
                <Button size="sm" color="secondary"><strong> Selanjutnya</strong></Button>
                </Link>
                </div>
           </CardFooter>
            </Card>
          </Col>



         
        </Row>
      </div>
    );
  }
}

export default Forms;
