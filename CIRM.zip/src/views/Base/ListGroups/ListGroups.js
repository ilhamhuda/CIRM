import React, { Component } from 'react';
import { Badge, FormGroup,Label,Input, Button, Card, CardBody, CardFooter, CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';

class Collapses extends Component {

  constructor(props) {
    super(props);
    this.onEntering = this.onEntering.bind(this);
    this.onEntered = this.onEntered.bind(this);
    this.onExiting = this.onExiting.bind(this);
    this.onExited = this.onExited.bind(this);
    this.toggle = this.toggle.bind(this);
    this.toggleAccordion = this.toggleAccordion.bind(this);
    this.toggleCustom = this.toggleCustom.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: false,
      accordion: [true, false, false],
      custom: [true, false],
      status: 'Closed',
      fadeIn: true,
      timeout: 300,
    };
  }

  onEntering() {
    this.setState({ status: 'Opening...' });
  }

  onEntered() {
    this.setState({ status: 'Opened' });
  }

  onExiting() {
    this.setState({ status: 'Closing...' });
  }

  onExited() {
    this.setState({ status: 'Closed' });
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleAccordion(tab) {

    const prevState = this.state.accordion;
    const state = prevState.map((x, index) => tab === index ? !x : false);

    this.setState({
      accordion: state,
    });
  }

  toggleCustom(tab) {

    const prevState = this.state.custom;
    const state = prevState.map((x, index) => tab === index ? !x : false);

    this.setState({
      custom: state,
    });
  }

  toggleFade() {
    this.setState({ fadeIn: !this.state.fadeIn });
  }

  render() {
    return (
      <div className="animated fadeIn">
         <br></br>
         <Row>
          <Col xs="12" sm="6">
            <Card>
              <CardHeader>
                <strong> Daftar Bank</strong>
                <small> </small>
                {/* <div className="card-header-actions">
                  <Badge style={{color:'white', backgroundColor:'#03a840',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge>
                </div> */}
              </CardHeader>
             </Card>
         </Col>
         </Row>

        <Row>
         
          <Col xl="6">
            <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>            
                  <img 
                      src="https://www.bankmandiri.co.id/o/mandiri-corporate-theme/images/icon/bmri-chat-logo-256x256.jpeg"
                      alt="Avatar"
                      style={{borderRadius: '50%', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                    marginLeft:10}}
                      />
      
                <Col  >
                  <div style={{marginLeft:5,marginTop:15}}>
                    <strong>Mandiri</strong>
                  </div>
                </Col>
                  <div className="card-header-actions">
                    <Link to="/bank-detail">
                      <Button color="primary" className="px-1">View Detail</Button>
                   </Link>   
                  </div>
               </Row>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>            
                  <img 
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAxlBMVEX4uA3///8AAAD/vg38uw34tAD4tgD/vw34swD/wQ7CkAqkegj1tg3usQy2hwrprQyPagfkqQyugQlXQASIZQfZoQvGkwrSnAtuUga6igqbcwh3WAb//PVDMgN5WgajeQhgRwVMOAQ2KAOTbQg9LQNdRQULCABqTwUWEAHWnwstIQL72JH725r85bf968X6zm/+9uX71IT98dYkGwH++Ov84Kf6y2P5xET5x1T847H96cD60XtJNgQeFgEqHwL5wDT5wTr/yQ6oOffSAAAXgUlEQVR4nN2daWOaTBCAcXdhRUHFO5poNIkmae6jzdm0//9PvTN7ICh4sRj7zodWCSKPMzvHXliF/7tY330DucuOCA+f7h7erl9fn6+urp5fX1+vbx6eng538tV5E97dPP/4+WU5dtGOC7x3vF/vP64fnvK9g/wIDx+eb78EiONYyQJ/QVbn1/31XW73kQ/h09v9l4NsKWgLpHDuy9VDLveSA+HN/VdxbbgIJijz5dk8pWHCw9ef66sukdK6NwxplPD6BfC2pdOQTtF6NwlpjvDmNjveDPLKmOsxRHh4ZRXN4ClI2355M3NrRggfbouG1BeDtK5M5AQGCG9+GVVflNF+z54OZCZ8+8qJT0IWb7M2yIyEb1/mzdMwYybChz956i9ktN+ztMcMhHcvu+CTjFffQHj4vis+FNt63TXhq23vjs/C5vhny0RnO8K7X7vlk4z3uyO82qWBzsT2tlHjFoR3f3avQClbqXFzwqu8I+Aysb82VuOmhIcv36VAKU5x08CxIeHN9tWtKbFfNov/mxH+KH43n4Xl40aWuhHhz++1UC2OvUn434DwydsPQJBNfOr6hA/f3wRnYr+YJ7z+niifJs7XurXxuoRX++BjouI4a5aNaxLe7xsg+pv1XOp6hO9742Mi4tg3xghv9xEQpLgO4jqEexIGE6S4Rp/qGoT7qkGUNbS4mnCfAddBXEl4v9eAEPtXedRVhHuRay+TlUFjBeHzvgNi6F+e3SwnvNl/QED0tie82/M2qMRZmoYvIzy09irZThf7fUvCX/8IIMSM560I9zIZTZElDjWd8Nq4l2GMSmGMGb6046R2T6USmvUyCBe0671as9tv1noHHQ84TX5BurdJJfwy1wgZZa3hMYnL5aBS5QYhUwfg0gjNNUJGL5rnJFGOhr45TRZTmmIKobFQT63KqQYaTWvleqVe7g3OxvpY98KUIp0UlOTDh4b61RgrS5BJ/yBg0seAUKDqlBuK+4Ib+a60qJhM+NMMIG//FhD9NotaI/dBtYxxv3wk/+xTI1+XXEklEpoJFMyb4v2fD614Y6NdQgYWHmI86ArGihE1Os7ahEY0yDsTvPkhm1MQKwlXWhWHgVE42allojUm2mkSoZGqnp4IR+ItGCD9INM6wJek3hhvf6KmL0xYapI/TSB8MGGjTKimHbM+hu2NBeQSoj/88UT9kVkDPLdkwFKdr7UIjcR69CGNOdMLyNRjbEgqzKId9DCaiQvDrbvZv9ZeTMEXCV9N2CgCNucbYJuQT/9vg3jwhqPeBhqRBpgT1E1ocSE/XSQ0UBQyBBzOq4RV4OjpgIw4hArLQ7X1NBPzMC+oZG+Li85mgfBHdhXS4ySFUNqUIf6E0nqL0ZqwTF1lMKH2dnaPWpwfsJknPMwOyNGLluOAjFdPwBDP6kGJtJhPiM+qAve8rKIJszCT8zMjOj9XEL5ntlFsbqQZM1HGWxD8z3seZ/ygI1K5AeUjlZqWpR6ZDyHkyIASH5YSPmWPFD560ViD4p0zQh4rvOIz78B3LWGuHh3q7HvcktH/An+azN5mvlKcI7zNrEIOjXASPcB8yMw+2q4LXAFEw0aVWX0IfyJgKBkKLoppeiuzFueUGCd8ytwKhY1GHQaFA49t7lagGZYpB//yQS1egVjiRSrFvrBqCuXGaWZ/OqfEOKGBVvg7EuZA6AFYHrTDCelWPLc6FpkqaPpgStmn5hu0j6ciE68K95r1HuJKjBFmd6Ssjk0s8h7SsxpnnSmEB8ZaWA52ZKNrMfcjVGHJrbbwKO3BG8PuNEZ4lZ0Q/OEwYmd8ShoucIri170kp21R0vuor8p4ZqVVjSVsOetd2E9phJl/PUxbzqPvPXQdrN6ivWa91INkGwp8rIYHzGIyWpRFH05XGTYFG/jMfBv2fQph9oyUHsVUyNiAnHKIDpPf5FTUukO3fDpu1Gn5GJBEN8aFd0aUZVfxI2iz2REPkwn/ZPUzoqHN3tLOuXAcLLiEFPTkHKzSE+lAFVzKCXrUo0mDMd6U/oWhj8GyspE5JkYnvkUIs9eFGMr7oQpdTF1EF4wLtz2dAH7HhWhZg8hAMTZiRyrCYAgZUIuVW0y4JuJnvRHnTyJh9lBBwc90tImBas47QhusREblOmDWOD0nY2SmgglKRnE2cGPBEXThECZzZZMBI0KYPRaCliYRwIYn39AusSgPyIRizXSAB6l0KBBGRFLqY3OFNujJeHOcPeq/JxBeZw8Vw5mRQoERppisXWK0eo5tzVfhrqqcCz16xKSU1sZwMh8jfWAiJFp2AuFLdiOFRlaRNweGqTslQEnQ2uqyeVWlcYr+NuE6A8xQ4b8jIKT9KdI+goPN7k3fFggPs1cVGO6r8qUfdix57XKV1WSkwB4oaaQD7U+wEIamS7HLA/wo/ts30RBneU1IaKB7BusmaaT8uKTqWtqBRAwcauvCc+FVg0jfQlRYAQXLHAGTNsgX0JuWF7t4tpCwwyYkzG6krKMLQ9ZRPS68coIdaU3smXFlJ4b4+4F6FRy0/p7IYMiE7YKGsToZZe+TCs1UExrovcCUTToaVqXCRdJp12dY2MJ73pYZaFNFBEFIR+Qcqv8zKsI9EJ5Q0TQ/sxOGZqoJs3tSURiciGBXcTsnB5BrV3p//RYHwsdhCYN+6Vi4UBHVRcgXho22zdoQC8EI8BfyY4nR1mLPEWYv7kVGg4kXOMYumZLPJj34C/HjxFX1w5FL3RGegic2m+Jc/FXOzgnjH01BiOaJDitzVgOEN3FCA/3cmhDc48hrPZIu5XVSwcao+2N8zAm6FKvkIfgd/JCHem8yRmoUrRQDP4fKOMh+O859jPDBQEd3qMMKqf/tY9kUkKrbKnfcdrdbL5UvyYjyBhlzDPcNTgNM8CA2nIM9t7B9AqEM/ER53GyEXzHC7LWvJBSBDCJ/xz3qcnocCAda5lj/UtYkAS2TTxcrECwbRcdFW7xskyl6G5OEVvEpSpg9VsjgLUM1a5DSR8CCoQuqnIC+5AC3270AZf3mogtqqtylLzq+D8i56GUUVvpohtC+jhKaGG7CtLQm46C81wu3DuUT73W8+mAwGEICCn4UeHlDu1JLaKxJMUD6EFxEaQj1h06NMonKviWhmSHDCroR+ZpOoEiCfAVyN8Z7ytOMAjh2XqOsowOjJQqPY0HYZu6nyFr9eGfW1qIaoiR8NjGihk1Kd3ZDFOhA6+pQiwbQrC4bstepzdg5+BfsNSa/mZhLBOo+4khYo+CBerIGfjQwlKg7pCxT0dCSJVGYUJJTF4dbONx7o0U5b4lpNT4d4Rm+zGnYSf/ib5NcCsIPVyhS1B3Z+zFQZESUhGYmkrJIBwSY7MDiFPvvy65wsIJqwErag8piijS74EBFoopzNHzZnA1k3paeCCYIs3fmC4Esc9ahj/1L/d7kbHwiLE62vbCr0Z2KzMwVim1IQggilzRWZWYUmZpapuK9JcNFM9YRRc7+fsi7ZZ+k7J+FLgSixjGVn8AeG0E4lZ+mxEhKY+kJ4JYxRyNtbxztLb2oETata7M8/QsJTahi0SsqyhEyDCeHgRdCZT8amupWPNSE2XvZlJB4rGa8dj4oq6K+06oLZwrBn6uiXoBX6h1GZUD5pDIzGpiZBSZnDlumMhoUDobWiw+OlmSHFJuc+vhHTnG09OhAnYS1Y4/LngsiP8sejQznCxFZjSA0cz1Zu88Vr4wFLc4gubnEjm0uhn8hNg5kwENCMdgmZ2j6ysuamnNq/1CEBjqhtJBFBfhk1BMdGEcQFps4pYQHyltixi3KEVkIY8rHz0zFChDnVhEaydmEoIrmo7VHqugxp23IvcGL4PAhrRMM/HwAukWPI/ttRH9wQMyk3UJE5z4S3pibtO6TSL++FD7qDc5cjjMw6aUcsQeOiTBRfyBOd0UqXqeyJU+NJDRCPEVoKFig4GSuj3hSiQqSA6Bgk+fyRQtDPx+Rkmh8YsiKHFE1eJV9rkIo2KWIhAamQYVSXRz/cwmRzJBwS08L4e+Mu/BjXIrhC1lN4a+AnXAGVShybyS8N7j6B1viJF77QNmnJo9q/bhj0ramMsgfcyr6cUqyfRpshZYMiEhoaFa3EjKvBjS9CuMUe0wFKSB96JoRGqawUYyKYipGzZQjRcFuYSQ0uoJLBLT4JEORdR83mx+iG0Z3l5Ke0GIg5reJCSo4Rv7bJKAI+UhocHmMpWaOxr0F89TSA9FbL5AaZV8UFiOBK/KehA9mFZxQi4Se2VV4DHKWydwkQ8hG/Yv2sIbZdqteusDZNYLtWJuoxYcqYhgUTGosg0mbEtGcfi9OvmdqyZr6X051F05GAKK/6Rv0oyjYK2zhAhmzl5WTDC9XThVVfA1xogBsmNWg7G7Lg1DM1iOf1aWIqmACp4Sn4diiicmlc4KJaS6EFhWT79vLbE4m2z25doZh9XRkZFVJTPIjlKsNIINJvWdMQMdlS8bHAL1qwzhfroQWbeF8taMgRY2scnnSkuvymJwsbKquj0mehBADxUBvzUq+c1+tkmX8QlS/JtZaLEquhKEvqbN0W2U8EInNZSsPDeZOCO1LzpHtBYnrRBm12jLVOTG76nkmitB0xJ8Jo6VHgfBRrrrRNeq4jJS2B2L5HulX81GgFcbD/AjRDCuXMu599sulwPegxrD8aqfSVGtkST/NGZkQnbUZzkvjwlh7SmbyefkYWdj92TO6Yn1BcOTCfG2xIIx79fnV+CjjZofnZp9ScCat8fowURi3LurNs1B7p/1eyTe8q0KS6PrQzOjhCsHufM78KojH+Q7oUHAE0XQ/zX5J8cF8X9t+ie5rMzCnbU9F95ca7PPeL3F0n/fdznb0UjvwbP15tYXPul7K+aVH13alQ3/aBZluPbbEOvIC6y6qEXOGBOHykB/ufbTkyHqiZpOebpunyQ0n5JDjOiImYwjCpZ3ebNiUEnZlsgt1ZNOlgorwKCvhuhPdxUxoQbg0IHKdiITGRbvqyNGG5rZrQrFyXRAun6evCSd0/gjZc0J7rfk0cnBPSCdcLaJlw8nKOyaU67sE4bIqP8KjOovodJ55Xdk14e1sXtsSZ8rCZfNqANeKrMEOZ2fpzeaWbjXHQkLG5jali2xWFz04d9UNCeVGJ5JwyZQhsYBHiZhmoaYVCBGLD+A2qu16szudTgflC7ybACuIahAOlIqKAkQRflilSr3S9nXxy6gVVHoD+Hy3WW+pGMS435EHp81eW27kEyf01NekNhW51aAkXJKZ8sYMSJgpj1SzOGGWdQaXsyPks0LpWL7UzpeqZek1pf2JOvWjpJYnTqP7uZ22xfzM3ohEZYCdOTFCpnZJ+0ydbSsXBknCJXkbk9t1yZvG7/Yi78WqwQMSl4Grm65a+6R9lefPnUnOPKan70VkSKOtX0uJxghdbVupI0AiZwvneadPMFW/u1wzgRNcK5H351EVhVJx5a+iJg9pggFfICRjVMDCYTD1RUISsAgh1Ys40p2dmBEVEqZmNVoBMgb2qUXF0uvfVB7GGefYK3857ZXLQ2XQv3ldMQkluuf6DkOU8aN+hWu6eR+soQsX6CnDm9IZYeNIv+rSGWFoF0sW76tFM4owNeari54qo9D+sOZGfkG/7svt9Fzld6tMfb+4wkXIovNSOLeqQ84FmEXrwBOfp67KlkJtDSinltq5h/CQkFrqJ1o2pKqWrCvC1IaogkXDlXN8S0o9LbXlg5oea0nXzpVJt7ka30Uz1VsLdVg0HjLtsFDPTF/AVQvcwhYnZma4kznusqs+fLokbKhmGK57SmuIKlg0KRW2Nv0rLHHsqrB/opwJ94KDcnOgVFDS9ih87WeIFY342s7kXibw47QOhs1BQxtBlJCqo54+Wtcxetk4s97uUxOmJd9qJ6AhU6pQA5v6rVhfQfVUCy0lpqNoOMFbrI6N5TR0ok+xeLV3FLtAsJxQW/jSlEovWNeEadt5Kgup6LYtv6wqNzEhYoIMDWf/zAj1nJmS/ik+w0UImlDNKYX7tgbzF1hBqKS5fFVGIU6Yti5I3RT4AzoOL43bA6gvc2e1FHJoLjFPFH9trpxumaUSWrMLk9DtLiXsq7OXTb7Ri/NmhMndwrq1BDFV4YpW9YeqDkyjg4C5LCTUxmlp3xH5uRShtI5PrjxRt12lOldYQVjXu6Iu0WC4q0JImNzhphMWNpusRdRGJPJlR2V1DRcdohcSiilc+LI5u9O4p1GXa6i4U8N1J/rrVhCWXXUkffOF2Y60sx0HknUovdZEzOnR3uBYzk2XP6eK57JDI0KobvZMpjfVBR26ytTKSu+daFa/ipDq3GGYFg9DI40QJtYXyieKmc3KuaidLbhMt0/csSRBHbIIocUj6bTaYEfXFn8pZzqM+yzUIQTE9ay0LCaIz36YBJlt/TEjTJztrS7ejxqZXPdClStRy+xJo9QKWqUIoV4lgqJcgrrAZNrs6lz2hFK1XVS3HQStkzUJxY4v4lrJlUXkeQmRvU2SymB2ru4D3yj/KHFVFDh1q2RBSlGTJbMNBBYz7wa1QnVEZDWhpX+Y5GVukd29I4SJa4HlZVRyFhYY+Ea5Vo8u3mEpVlPMFigsEMqEoTx/eB1Cpn/ZXhJiZC+sCGHCsgvt89UtyiajXiunAMHf1/FJySiIGeVsLZQ3jZ13LDfosWhrboj42NcsooimozlC0SOs22zSCpvofmbRfaISSqigglJXHQWsBG/0BavyT6J+8tq9/tnoctToN+sdT/dOuOrOZh3H3OpUmsenl+NRt3YwG8Jn3C+d9BtwgbN+rdLyuP7iivSwJflV4VHZrKk8XDlYJIzuex0lTPI1LNZptPhGd7XgCC8XY7uzv+sAymLXC0+Mf48+rC/AIpefvWbxL43fXSix7YRj+7Vl3uwrJlwZby+9SM1JYrsJxwjNDpXqZmhgj4sNJbaZcHxnSJMPlgm7Z3avwh+FVEITm0do0T0ZJleIrCfFw3RCM/vNC9EpzXGOk7qSxYlvBz1HaE6JrHGEMt5waMOA2E/LCA22ROH9ea7T1hLFnnuS7jyhwZV63yT24XJCo+70OyTuSJMI//XpQwtP8VjcV99sYrNrWXw4wiKhuXXP3yAJD7hIeL7FTiZj5iQJDylJIMxt7n7+IkfuVxIWXv9ZO016vlzis4L+nQcfxqX4mgCTSPiPPJ1zXvR42hqERmuM3Ymd+FDZZMJ/MiimPKozhdDQzlG7lLRnPKYQ/oP+NO05nWmEe/7A8UVJfQR5KmG+q6GMy0JJsQbh7ua3G5DkQLGCMIfH5eYmjpX6sNxlhIX7f6Yppj1ldRWhsV3O8pbi9RKIpYT/iLdJ9zKrCZ8MPVM2V7Hnn7S2CaGpPSPzlCVudB1Cc48+zkuSHsy5EWHhbb8Rna/0OLEm4X5nqMsC4dqE+4zoWIkl4aaEhed9RVwHcC3CfdWi46000XUJ99PdrHYyGxAWbuy9C/32n9W3vQFh4WHfshs7pdNia8LC037lqMWE3u2MhIXDlz3K4IpXq294Y8JC4X1f/I1jp3XKZCQsXO+Hv7G/1giD2xEW7rw9sNT1m+AWhIXCz++2VMdOGn4xSFh4/V5Ltb/mn51unLBw9/V9luoU71ffYGbCQuG++E1qtK0NfGgWwsLDt6jR2dDFZCHEbYl2rkbbW9Ipap6wcPeyW1N1NshizBBCubHD2OgUf24S5A0RQu3v7IbRKf7azkAzE2JzzJ/Rsb+28KCmCAuH9zkzOra3bFAif0JkdPLzq07xKyOfAUJgvLLyYXTsX5ns0xghyNsv47HDse33DP5lJmYIIT7eG1WkU/yzYQmRKqYIQd5eikYgHWjY90bUJ8QgIbTI5xc7I6RjF61bA61vJkYJQQ7fbp2tKQHv64c57UkxTYjy8OOPvSklmGbR+fm8dW6WLnkQghze/HhxEHMNTgdP9G6fTStPSU6EQu7ern5+FYsCdBEVj8Gfis6v9+eHHHSnJU9CKXcPrz9uX748jHBF5JXM1tefl/ertzzZpORPGMrh09PT3cPDw90dvFhr2MiI7JDwm+T/T/gfDLmXqWHGk/MAAAAASUVORK5CYII="
                      alt="Avatar"
                      style={{borderRadius: '50%', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                    marginLeft:10}}
                      />
      
                <Col  >
                  <div style={{marginLeft:5,marginTop:15}}>
                    <strong>Maybank</strong>
                  </div>
                </Col>
                  <div className="card-header-actions">
                    <Link to="/bank-detail">
                      <Button color="primary" className="px-1">View Detail</Button>
                   </Link>   
                  </div>
               </Row>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>            
                  <img 
                      src="https://is1-ssl.mzstatic.com/image/thumb/Purple123/v4/1f/0b/31/1f0b31ae-64c2-15c5-0ffa-9977a5a46904/AppIcon-0-1x_U007emarketing-0-85-220-0-8.png/320x0w.jpg"
                      alt="Avatar"
                      style={{borderRadius: '50%', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                    marginLeft:10}}
                      />
      
                <Col  >
                  <div style={{marginLeft:5,marginTop:15}}>
                    <strong>Danamon</strong>
                  </div>
                </Col>
                  <div className="card-header-actions">
                    <Link to="/bank-detail">
                      <Button color="primary" className="px-1">View Detail</Button>
                   </Link>   
                  </div>
               </Row>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>            
                  <img 
                      src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMPEBUTEBIRFRIVEhgXGBgXFRUWFRYWFRUYGRUYGBcYHyghGh0nHRgWITEhJSorLi8uFx8zODMtOigtLisBCgoKDg0OGxAQGy0lICUtLS0vLi0tLS0vLy0tLS0tLS0tLS0tLS0tLS8tLS0tLS4tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBEQACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABgcDBAUBAgj/xABNEAABAwICBgUHBwgHCQEAAAABAAIDBBESMQUGByFBURMiYXGBFCMyQlKRoTNDYnKCscEkc5KisrPR4RU0NVNjk9IXVHWDlLTC0/AW/8QAGwEBAAIDAQEAAAAAAAAAAAAAAAQFAQMGAgf/xAA4EQEAAgECBAMECAYBBQAAAAAAAQIDBBEFEiExQVFxEzJhgQYUIpGhscHRIzM0QuHwUxU1Q1Jy/9oADAMBAAIRAxEAPwC8UBAQEBAQEBAQEGKoqGRjE9zWt5uIA95WJmI7vVaWtO1Y3cGs13oIs6hrjyYHP/ZBC1Wz448U3HwvVZO1J+fRyKjafStPUiqH9uFjR8XX+C1zq6R5ptOAame8xDUdtVj4Usvi9o+668/XK+TdH0dy+N4/EbtVj40sng9p/BPrlfIn6O5fC8NmDajTE9eGob22Y4fB1/gsxq6NV/o/qI7TEurSa+UEvz+A/wCI1zPiRb4rZXUY58UPJwnV0/s39Orv0lZHMLxSMeObXBw+C3RMT2Qb470na0TDYWXgQEBAQEBAQEBAQEBAQEBAQEHhKCLad18pKUlocZpB6sdiAfpPyHxPYtGTUUos9LwnUZ+u20ecoHpfaJVz3ERbA36Au/xe78AFEvqrz26Og0/AdPj63+1P4IrU1D5XYpXve7m9znH3uKj2tNu64x4ceONqViPkxLy2CAgICAg+4pHMOJjnNdzaS0+8b1mJmOzxfHW8bWiJSXROvtbT2DpBMzlILnweOt77rfTU3r36qrUcE02XrWOWfh+ydaD2i0s9mzXgefb3xk9jxl9oBS6amlu/RQarguow9a/aj4d/uTFjw4Aggg5EbwfFSVRMTHSX0jAgICAgICAgICAgICBdBw9ZNaKegb512KQi7Y273nt+iO0rVky1pHVN0mgzaq21I6efgqjWLXGprSQXdHEfm2EgEfTdm77uxV+TUWv6Ot0fCcGnjeY3t5z+iOrQtRAQEBAQEBAQEBAQdnQGs1TQkdC+8d98bt8Z7h6veLeK2481sfZA1fDcGpje0bT5x3WtqvrnBXWbfo57fJuOfPA71h8exWOLPW7kdbwvNpZ3mN6+cfqky3K0QEBAQEBAQEBAQEEB1119EBMNGWulG50mbYzxA9p3wHbkomfUcvSvdfcN4PbNtky9K+Xn/hVk8zpHF73Fz3G5cTck9pVfNpmd5ddjx1x1itY2hjWHsQEBAQEBAQEBAQEBAQeg2NwSCDcEbiCMiCm+zE1i0bSsbU3aCQRDXO3ZNmPDsk/1e/mp+HU/22cvxLgm38TTx6x+yzGuuLjJTXM9n0gICAgICAgICCs9oGu5u6mpHWtcSSA778WMP3u8AoWo1G32aul4Twnm2zZo9I/WVbAKA6oQEBAQEBAQEBAQEBAQEBAQEE21E10NKWwVLr053Ncc4uQ+p93cpenz8v2bdnPcV4TGSJy4o+14x5/5/NbrHgi43g5KxcjMbdH0gICAgICAggO0jW3oAaWB3nXN67hnG08AeDiPcO8KJqM/LHLHdfcH4b7a3tckfZjt8VUAKudjAgICAgICAgICAgICAgICAgICAgsPZrrZgLaOd3VO6Fx9U8IyeR4e7kp2mzf22cxxrhnfPjj1j9VpBTnLiAgICAg4et+nm0FM6TcZD1Y2+085X7Bme5asuSKV3TNBpLarNFI7ePooqeZ0jnPe4ue4lzicyTmVU2mbTvL6Bjx1x0itY6QxrD2ICAgICAgICAgICAgICAgICAgIPQjExExtK6Nn2snltPgkPn4rB3N7fVf45HtHarXBl56/FwvFdDOmy9Pdnt+yWLeqxAQEHhQUbr1p3y2rcWnzMd2R8iB6T/E/ABVeoyc9/hDuuEaP6vgiZ963Wf2R1R1qICAgICAgICAgICAgICAgICAgICAg6erul3UVSyZt7A2ePaYfSH4jtAWzFk5LRKHr9LGpwzSe/h6r9p52yMa9hu1zQ5pGRBFwVbxMTHR89tWa2ms+DKssCAgi20TTJpaJwYbSTHo28wCOu7wbfxIWjUZOSiy4Tpfb6iN+0dZUmFVO9EBAQEBAQEBAQEBAQEBAQEBAQEBAQEBBbGyjTHSwOp3nrQm7fzbuHgbjuIVlpcm9dp8HG8d0vs80ZI7W/NPVKUQgIKa2oaT6at6MHqwNDftus55/ZHgVW6q+9tvJ2XAdPyYPaT3t+SHqKvRAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQd3UrSfktdE8mzXO6N/1ZN3wOE+C3YL8t4VvFtP7bTWjxjrHyXwrZwQgx1EwYxz3ei1pce4C5WJnaN3qtZtMRD86VdSZpHyO9KR7nnve4k/eqa1ua0y+kYMcY8daR4REMK8togICAgICAgICAgICAgICAgICAgICAgIBCMTG8bP0Fq3X+U0kMpzfG0n6wFnfEFXOO3NWJfOdVi9lmtTyl017R0e1+q+i0dOQbFzMA/5jg38VpzztjlO4Zj9pqqR8d/uUWql9BEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEFv7J6rHQln93M5vg4B4/aKs9LbejieO4+XVc3nEJspKmQfa3PhomN9uoaPANe78Aournai74BTfVb+USqJVrtBBPdRNUqaupnyzmQObMWdV+EYQ1h5fSKmYMFb13lznFeJ59PnimPbbaPD1SH/AGdUHtS/5o/gt31bH/sq7/rWt+H3PW7OKA5OmPdKP4J9Wx/7LE8b1kd9vucrW3UalpKOWaLpcbA22J9xve0G4tyJXjLp6VpMwlaDi+pzaiuO+20/BWqgOrbVFo6af5GGWS2ZYxzgO8gWC9Vpa3aGjLqcOLpe0R82Kpp3xOwysex3J7S0+4rE1mO73jy0yRvSYn0Jad7AC9j2g5FzXNB7iRvSYmO7NctLztWYnb4ktM9gBfHI0HIua5oPcSN6TEx3Yrlpadq2ifmxLDYyy0z2AF7HtByLmuaD3EjeszEx3eKZaXnasxPzZRo6Y7xBOR2RPse7cs8lvKWudVhjvePvhgkjLTZzXNIzBBBHgViYmO7bS9bxvWd31BTvkNo2PeRmGtc4jvDQkVmezF8tKRvaYj1fU1FKwXfFK0c3Me0e8hZmsx3h4rqMVp2raJn1hgXlufboyACWuAN7EggG2djxWdpeYvWZ2ieryOMuIDQXOOQAJJ7gEiJnpBa1axvadoeEW3HNYZiYmN4e9GbYrHDe17G187Xyv2LO07bsc1ebl36+Q+MttcEXFxcEXByIvmO1JiYZraLdp3eiJxaXBri0GxdY4QeROQTadt2OevNy7xv5PhYehBZOxyffUs4ebcPHGD9wU7Rz3hy30jp1pb1hZinOZV5tiPmacf4rj+of4qHrPdh0P0d/nX9P1Vaq91wgtnZTE1+j5WvAc11Q8EEXBBjjBBHJWWljfH83GcemY1cTHlH5ygmumq39Hz2a28D7mN1subCeY+It2qJnxclunZe8L11dTj2t70d/3cvRNc+kmZNDYPYfAji09hWul5pO8Jup0+PPjnHbxWrrJpiOt0LLNHkWsDmnNjhIzE0//clYZbxfFMw5HR6a2n4hXHbwn9JVtqrony2rjhNwwkl9s8DRd1u/LxUHDj57xDqeI6qdPp7ZI79o9Ux1p10fRSmloWRRshs0ktv1rXIaMgBz33N/GTlzzSeWik0HCa6mnts8zMz/ALui2setc9fGxkzYxgubtbYudlffe27gFHyZ5yRtK20fC8elta1Jnqkm0n+oUH1B+6apGp9yqr4L/VZf98Uq0johtdoyOEkCQwMfHfMPYxtj3b7HscpFqRemyowamdPq5yR23nf0Vpqbq+aysEcjSGRHFKDwDTbAe0kW7rqBhxTa+0+DqeJa+uHT81J627fulm2BwMFMW2wl7yLZEYBaykaz3YU/0e/nX9P1djTlbXRU1L5BH0hMYx9UOsAxuHiLcVtvN4rHJCDpsemvlv8AWLbR4fe4W0Ml+j6Z9UxjKwuF2i1wMJxjM7vROZsbLVqf5cTbusODfZ1d64pmaf7sj2pbpBHWmHH0nknVwXx3xj0cO+/ctOn32tt32WHF+WcmHn7c3Xfyb2rFRXmob5R5T5Nv6bygP6LorHFiMgsveKcvN9rfbx3aNfXRRin2O3P4cvff5InHTdNP0cAvjlwx35OdZl/CyjcvNbaF1OX2WDnyeEdfXZL9JSMqo56GEAiiYHQHi/oRhqe8m5I52upV9rxNI8OyiwRk096aq/8A5Pe+G/uuNqE62kacjnJ+4kWjT/zIWXGOukt8vzZNOxNrIRXxABxIbUsHqS8JAPZf9/ivWWIvHtK/Np0GS2nv9WyT8az5x5esMUv9kM/4g7/t1if5MerbX/uE/wDx+rr6T0P0sdJNM7oqWOghxyZknfaOMcXn4XW62PmiJntsgYdZOK+THjje83naP1lH9M6ZM4bHE3oqaP5OIH9d59Z54nt8THyZObpHaFppNFGKZyXne895/SPg5S1J4gn2x935TOOcLfg/+amaPvLnPpFH8Ok/GVrqwcmrzbEPM0/5137Ch6z3YdD9Hf51/T9VWqvdcILb2SuAoZCSABUPJJyAEcd1Z6T3Pm4vj/8AVR6R+coDtC1s/pCfDE78miJwfTdkZD9w7O8rdbq1aXHOON/GUc0dRyVMrIYRike6zRf3k8gBck8gvPLCRfNNY3mVv6b0AzR+hJYWb3WYXv4veZGXPdwA4ABec8bY5RuH5bZNdS0+f6Sr/U/Swo62KV/oXLX9jXixPgbHuBVfgvyX3l1XE9NOo080r37x8ko1y1MmmqHVNGGyxzWdYOaCCRvIubFpzuDxUjNp7WtzV8VTw3iuLFi9jm6TCLac1YqaKNj52ANfcbnB2E+y62Rtv3XCj3w2pG8rfS8Swam01x94SraT/UKD6g/dNUjU/wAuqn4L/VZvn+be1q0o+jh0bMzNjRce00xNDmnvHxtyWzLeaRWUTQ6aNRkzY5+P37sut2mYKWkfJSWE1f1sQzw4AHP7LDd9ZxPNZzZIrXevicP0mXPnimb3cfh+jlbRv7OoPzY/ctWvVe5VK4J/VZf98Uj1gZXmmpf6OLgejHSWMQ3YGYflPHJbrxk5Y5FbpJ0sZb/We3h38/g4+vcbxoqA1uA1geBcWvmcQ3bvRte2647lrzx/Cjm7pvCZj67b2G/J1/x+KNanOeIq4xF4k8k6pZcPvjHo4d9+5aMG/LbbyWfForOTDz9ubru2NVpa99VG15qnxOdaVs3SOiMXr4uk3ZX8V6xTlm3Xfb4tfEKaKuGZpyxbw2233+Rq22Gmkqq0hxggkdHDhIxOdI4hmEniI99z7SY4is2v4R2edbbLnpi00e9aIm3y8/mwaK0vQU0zJmQ1uJhvvkjIIIIcCLbwQSsVy4623iJbNRo9dlxTjtau3pLd0Zo4U2m42s3xOxyRHgY5IJC23dvH2V6rTlzdPVpzZ5zcOmbd42ifWJhHdXNLeSyXc3HC9uCVnB8bsx3jMfzWjHk5bdfHus9XpfrGGNulo6xPlKQazaLFLo5jWOD4n13SRPBvijdTnDftFiPBbstIrj2jturuH6i2fWTNo2tFNp9Yl7X6YNN5IHN6SCTR0LZYjk9vW3jk4cCs2ycnLv22ecWjjPOWaztaLztLi6e0MIQ2aBxkpJfk38WnjHIODhl22WnJj2jmr2WOi1k5JnFl6XjvHn8YcZaViIJ7sfb+UzHlCPi/+SmaPvLnPpFP8OnrK2FYOTQXa7Dioo3exUNJ7ix7fvIUXVxvRecAvy6mY84VIq12YgsDUHWWjpaSSGrfYvlc7D0UjwWOYwb8LSOB3Kdp81K02mXMcX4fqM+eL467xt5x8fi7f/6bQvsw/wDRv/8AWt31jH5/grP+la7/ANfxj92Wm1w0RE7FGWMda120sjTY5i4jWfrOPz/MnhOtnvX8Y/doa4650VVRSwwyudI8NwgxStvZ7Sd7mgDcCtWbPS1JiJS+H8L1OLUVveu0R8Y8vVVyr3Xulo3T1VTDDBPIxvsggt8GuBA8FsrlvWNolEzaDT5rc16RMsGkNJTVLsU8r5CMsRuB3DIeC82va3eWzDpcOCNsdYh5VaRlma1sssj2s9EOcSG7rbhw3JN7T0mTFpsWK02pWIme7yq0hLK1rZZZHtZ6Ic4kN3W3A5bkte1o2mTFpsWKZtSsRM92BzyQASSGiwBO4C5Nhy3knxWJndtilazMxHdnqq+WVrWSSPe1notc4kN3W3A5blmb2nvLVj02LFabUrETPdts1iq2gAVU4AFgA91gBkF6jNePFpnh2lmd5pDSrKySZ2KaSSR3N7i4juvkvNr2t3lIxYMeKNsdYj0fVFXSwEmGSSMkWJY4tJHI2St7V7Sxm0+LNG2SsT6s9RpuplaWyVM7mnMGR5B7xfevU5bz3lqpoNNSeatI3ahqXlgjL3dGHYg25wh1rYrc7cV45p22b/ZU5+fbr23YlhsbLdISgsIlkBjbhYcRuxtrWbyFiRZe+e3Tr2aJ02KYmOWOs7z8Zay8N8Rszvq5HRtjL3mNpu1hcS1pN7kDIHefeV6m0zGzVXBjrebxHWfF8zVDn4cbnOwtDW3N8LRk0ch2LEzMvVMdab8sbb9ZfUdXI1jo2veI3m7mAnC4jIluRKzFpiNnm2DHa8Xmsbx4sC8togsfY5D16l/DDG0e95P4Kdo47y5f6R39yvrKzlOcwje0Kl6XR044taH/AOW4OPwBWnUV3xysOFZOTV0n47feo5VLvxAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBBbmySlw0b3/wB5MfcwBv3hystJXam7i+P5ObU8vlCcqUpGGrpxLG9jsnsLT3OFisTG8bPVLTW0WjwfnSeExvcx3pMc5h72ktPxCpbRtOz6TivF6RaPGN/vY1hsEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAJsgv3VKh8nooIzucIwXfWd1nfElXGKvLSIfOtbl9rqL3+LsLYiiCldpejOgr3PA6kzRIPrei8e8A/aVZqqct9/N2vA9R7TT8k969P2RRRl0ICAgICAgICAgICAgICAgICAgICAgICDraq6M8rrIYrXaXhz/qM6zr99reK24ac14hB4lqPYaa1vHtHrK/1bvnwgIIftN0P5RRmRovJAcY5lmUg92/7Kj6nHzU9FtwbVew1ERPa3T9lNKrdyICAgICAgICAgICAgICAgICAgICAgICC0Nkmh8LJKpw3v82z6rT1z4u3fZVhpMe0c0uS4/qubJGGPDrPqsVTHOiAg8e24IO8FCJ2UNrhoM0NW+MDzbuvGfoHh3tNx4A8VU58fJZ33C9Z9ZwRM946S4i0rEQEBAQEBAQEBAQEBAQEBAQEBAQEBBuaI0c+rnZDH6T3Wv7LfWcewC5XvHTmtEI+r1FdPitkt4fj5P0BQUbYImRRizGNDQOwBXFaxEbQ+d5Mlsl5vbvLZWXgQEBBHNeNXvL6Yhtumj60Z5ni09hG7vseC058XtK7LDhutnS5otPuz0n0Ue9paSCCCCQQcwRuIPaqqYmOku9paLVi0dpfKw9CAgICAgICAgICAgICAgICAgICAgt3Znq35ND5RK200o3A5sjzA7Ccz4DgrLTYuWN57y4rjOv9vk9nX3Y/GU4UpSiAgICAgrXaXqoTesp28PPNAzt84PDP387wtTh3+1Do+C8S5P4GSenhP6K0UB1ggICAgICAgICAgICAgICAgICAgmuzvVTyqQVEw8wx3VB+deP/ABBz5kW5qXpsPNPNPZQcZ4l7Ks4cc/anv8I/db4CsXHvUBAQEBAQeOCG6pdftSzTl1RStvAd72DOI8wPY/Z7sq/Uafb7VXWcJ4tF4jDmnr4T5/5QVQ3RiAgICAgICAgICAgICAgICAglGpWqT69+N4LaZp6zsi8j1GfieHflJwYJvO89lPxTikaaOSnv/kuimgbGxrI2hrGgBrQLAAZABWURERtDibWm881p6yyrLAgICAgICAg+XC6Cs9dNQCCZqFtxm6EcOZj/ANPu5KFn02/WrpuG8a22x6ifSf3VyRY2O4g2IOYIzBUCejqKzFo3h4jIgICAgICAgICAgICAgIJrqbqI+qIlqg5kGYbk+T8Wt7czw5qXh002627Of4lxmuLfHh628/CP8rbpqdsbAyNoaxoAa0CwAGQAVhEREbQ5K1ptPNbrLKsvIgICAgICAgICAgi2tWpUFdd481P7bRud9dvrd+a0ZcFb+qz0PFMulnbvXy/ZVGndXqihdaeMht9zxvjd3O4HsNiq/JitTu67ScQw6mPsT18vFylqThAQEBAQEBAQEBAQbuitFTVb8FPG57uNvRb2udk0d690x2vPSEbUavFp682S236rQ1V2fxU1pKm0sw3gW82w9gPpHtPuCsMWmivWe7k9fxnJn+zj6V/GU3AUlSvUBAQEBAQEBAQEBAQEGOaFr2lr2hzSLEEAgjtBWNoZi01neEJ05s2gmu6mcYH+zbFGfDNvgbdijZNLW3WOi60vHc+L7OT7Ufigel9TqyluXQl7B60XXHuHWHiFEvp718N3Q6fi+mzf3bT5T0cC/wAFo2WUTE9hGRAQEBAQCbZoOvonVmqq7dDA/CfXcMDO/E7PwuttMF7eCBqOJ6bB71uvlHVOtCbMWNs6skLz7DLtZ4u9I+FlLx6SI62lQarj+S3TDG3xnunlDRRwMDIWNYwZBoAClxWIjaFDfJfJbmvO8thZeBAQEBAQEBAQEBAQEBAQEBAQc7SOhKep+XgieeZaMX6Wa8WpW3eG7Fqc2L3LTCO1mzWjkvg6aI/Rfce54K020uOVli45qqd5ifWHIqNlQ+bqyPrxB3xDgtU6OPCU2n0jv/dSPvajtlk/Cph/QePxXn6nPm3R9I6f8c/e8Gyyf/eIf0XrP1OfMn6R0/45+9swbKj85Vi3JsVj7y/8FmNHHjLVf6Rz/bT75dWj2ZUjPlHzyd7g0fqgH4rZGkpHdDyce1Nvd2hItHat0lPvip4muHrFuJ36Trlbq4617Qrsusz5ffvMustiMICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg//Z"
                      alt="Avatar"
                      style={{borderRadius: '50%', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                    marginLeft:10}}
                      />
      
                <Col  >
                  <div style={{marginLeft:5,marginTop:15}}>
                    <strong>CIMB</strong>
                  </div>
                </Col>
                  <div className="card-header-actions">
                    <Link to="/bank-detail">
                      <Button color="primary" className="px-1">View Detail</Button>
                   </Link>   
                  </div>
               </Row>
              </CardHeader>
            </Card>
            <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>            
                  <img 
                      src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQERIQEBAWEhIXFRIQFxcVEA8VFRYVFxIWFhYTFhUYHSgsGB0mGxUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGxAQGy0lHyUtLS0vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAOEA4QMBEQACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABgcDBAUCCAH/xABIEAACAQIBBwgFCAcIAwEAAAAAAQIDEQQFBhIhMUFRBxMyYXGBkbEUInJzoTM1UmKCsrPBI0JDkpPR0hUWJDRTVMLhRKPwF//EABsBAQACAwEBAAAAAAAAAAAAAAAEBQIDBgEH/8QALxEBAAICAQMCBQIHAQEBAAAAAAECAwQRBRIxIUETMjNRcRRhBiIjQoGRsRVSYv/aAAwDAQACEQMRAD8Auw9eAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQnOrP14HEPD+jKpaMJ6XO6PSV7W0WTdfU+LTu5Qdjd+Fft4a2ROUd4nEUcP6Koc5JQ0uevbU9dtFX2GWXR+HSbcsMW/8AEvFeE/RAWIAAAAAAAAAAAAAAAAAAAAAAAAAAABccPO6AHdCleVKS/tGev9nS+6y60Z4xev7qPejnL6ObmS1/aGE1/tV5M2bVo+DPq1asT8aOYX4ULogAAAAAB5yB6AAAAAAAAAAAAAAAAAAAAfPOX5v0rE638vX3v/VkdBgpX4cejms97fEn1aGm+L8Wbeyv2aviW+64+SyKeATau+dq7de9FNvemXiF5oxFsXMvGWc/8PRk4Yenz84trS1Rp3XCWty7lbrPMWre/rM+hl2qU9Kx6uKuUfEt/I0rcP0nnf8AIkxoV48ot+pWr6zCQ5Ez8o1pKFaPMSepPSUqbfDS1W71brNGXSvSOY9Wev1OmSeLRx/xLkyEtYmJgAHknlqYjKEIauk+C/mU271vBr+kes/aEjHr2s055Vluil4sosv8TZpn+SsQkV0493hZTqdXgaI/iPa58R/pn+koz0srfSj4P8mT9f8AiWZ+rX/TVfU48N+hiIz6Lv5nSa25h2I5xzyiXpavlkJbEDwAAAAAAAAAAAAAAA+d8v8A+bxXv6/4sjo8H06/hzGf6k/loG1pXNyVfN697V80Ue7P9Zf6X0FW1F6zS4vzLSniIVeW0VmZlljGxtiOFXlyTeX6ZNazeTnLDrUpYeo7ypW0W9rpu6Sv1NW7Gim3cMUt3R4l0nS9mclOy3mEwZXzPEcrdyMfj3K8YO0d74nF9X6zbJacWKeI+6fg14j1lzzmZnn1lM4DF6ADIcrObGTo4eVSlNwmpU7ST19NeK6jo/4Wju3q19uJVvU7TXDzDq5m51xxqdOpaOIirtbpx2ace/at1+s+hbGvOKfTwqsGx8SOPdJyMlAAAAAAAAAAAAAAB4I/iMy8nzlKpPDJyk5Tk+crK7bbb6WreSK7OWI4iUe2pimeZhg/uXkv/Qh/Gq/1mX6nN95YfpsH2h18l4PD4WnzVBRhC7lbTb1va7ybNFpve3Nm6sUpXiqknHW+1+Z0NI9Icps5ZtaYDYit/I2R62LnoUY32aUn0YrjJ/ltNObPXHHMpGvq3zzxVaebebVLBK8bzqtWlN71tsluV/8Aspc+xbLP7Om1dOmCP3fmdGPcIKlF2lLW+Kj/ANvyZQ9U2eyvw6+ZW2vj7p5lw8Lj7erPx/mcZsavM91VhEuimVs1mJ4ZgiJnwPapSeyLf2Wbq6ua3is/6lh8Sv3fkoNbU12po8vr5afNWY/w9i9Z90cz4qWwyj9KpFeCcvyR0/8AB+Lu3Zt9oVXWLcYYj90BpY2ph6tOvSdpwekuD+q+Kaun2n0/JSL14ly9bzS3ML6yNlGGKoU68OjOKlbg98X1p3XcUV6TS01lf4skXrFobhizAAAAAAAAAAAAAAVjyn50tuWAoS1ftpJ7Xt5pfC/alxLDUwf32Vm5s/2VV/haX61uwseFdDbpwue1hq2Ms1rx7yzG1XO/mvmzUxstJ3hRTtKe98YwvtfXuImztRi9I8rDT0bZ55n5Vq5PwFPDwVOlBQity3ve2976ylve155l02LDTHXisNkwlsQXLWI5yvUe5NwXZHUclvZZyZrSs8Ne2rSIba2MHWmpKMdd2kl1t2XYarasZp7eCbdscprg8GoLWk5b3/I6jQ6Tg1q8zHM/dXZc03ny2i17Y9oaRo8mlZjiYOZjwrXlUqxVShSikmoyqyt1vRj5SJvTNTHjtbJWOJn0VvUMs2iKzP7q8xm7vLjhWW49Fmcj+PcqNfDt/JzjUj1RqJ3X70G/tFVu14tFvutOn35rNfssEhLAAAAAAAAAAAAADgZ7ZfWBwspxtzs/0dJfWe2XZFXfgt5uwYviW49kfZzfDpz7qLV5y1tttttvW227tsu4iIj0UUzzLeS3IPZ9IZ4qxtiOIVl7zezdyfh1KSlNXgmrq7WlxV9xT9T6rXWr209bLXpnTLbE99/l/wCrSyVl6ioxpuHMpJJW1wS3dhzmLq1L2/qekupnU+HHFPDvRkmrp3XUWcWiY5hpl6PZ8EK6rv1pe1LzOKy/Pb8rWvhjNbJ1M24J4iF9yk126LLDpsc7EctOxPFJTQ6pWgBg54UlndlD0jGVqid4qXNx9mC0dXa033l1rU7KQoc+T4l5lHsY9neb2iyb8jsv8RiFxpRfhP8A7ZA3vEJ/Tvnla5WrYAAAAAAAAAAAACkOUPLXpWMmou9KlejDhdP15d8rrsii31MXZTn3lR7mXvyeniHBwkNr7iUjw26SMqw0bF+2vDcwuHc31Lb/ACK/qnUI1cfp80+GzpuhbZyevy+7rRVlZakcHlyTktNresu4x4q46xWsejpYOd49moh5I4luh2MkZWlQdneVN7Y8OuPBkrT3bYbcT4asuCLRzCaUaqmlKLumrpnT0vF6xMK6YmPKCZUo6FapH6za7G7r4M5LbpNM1o/daYrc1hqEZmz4PEOlONRbYu/at68Lm7XzTiyRZhevdHCd4PFQqxU4O6+K6mjrcOemWvdWVbek1niWY3MHAz0yysNhpaMrVZ/o4a9avtl3K/fYkauP4l+PaPKFv5/g4vTzPhTTLtT1+VpYl+t8Dx4sHkaoXniqltSjRgu9zk/KPiV+/McxCx6fE+srQK6FqAAAAAAAAAAADlZ1ZR9GwdesnaUYNR9uXqx+LRsxV7rxDVnv2Y5l8/F7Hhzzfpxskgz4bWHpt2S2sxz5q4Mc3si/DtnyxSqQYTBS0UqdOUlxjCUu/UjgNrNl2Mk3mJ9Xb6uCmvjisE4OLtJNPg00/BkS1Zr5SotEtrAPpLsZHzMqts0TDNIM1cdaToyep3lHqe9d619xddK2eLfDlE2cfp3QyZ2YLo1kvqS/4v8ALwMura/Mxkr/AJY62Tj+WUbKNMAMtCvOm7wk4vqdvHibMeW+OeazwxtWLeWzVyzXa11mlv6K1dqRKjb2MkxSLTMy12x46V7pQfK+Odabm22lqV227cX2nf8ATNL9Nhjv+afLh93a/VZ/5fEeHMuT2bnyd22eMFz8l2T+ZwMZtWlVlKr9now+Eb95T7d+7J6LvSp240uIyWAAAAAAAAAAACC8r2JccHSpr9etG/ZGEpeeiS9GOb8oG/b+nEKmpK8kust1RDeDNZPJ3m/B03ia0FJydqakrpRW2VuLfkVfUMkXmMftH/U3peHt5yz5lPErbNRAiIhb8y1Mo5Op4iLjUjfg/wBaL4p7jTkwUvHEw9reaygFXASw9apSlrtaz4p60/8A7eczuYpx24lZYbd0cvRDbWXDVXCcZrbFqXgbMF+zJEsLxzWYWBUhGcXFq8ZKzXFM7Ga1yU4nxKqj+WUKyvkuVCXGm9kvyfWcvuadsFv2WGLNF4c8g8t4Bwst5Q0r0oPV+s+P1ew7boHSuzjPkj19v2/dyPWupRfnBjn093DqvcdRbxwptanu1sRKy7dRgly/ci5Nliq9LDw2zkk39GO2Uu5XZry3ilOWWLHN79r6Gw9GNOEYQVoxSilwSVkvgUUzzPLoaxxHD2HoAAAAAAAAAAAK65ZE+awvDnKnjoK35k3R+aVd1DxCs8KvW7mWirrDpYLDOrUp0o9Kc4012yklfuvcxvbtrMtlazaeIX1g8PGlThTgrRjFRXYlYobT3TzK+x0itYiPZlPGYeCJ52pc9F7+bSf70rfmc91ef6kR+ydq+JcMp0oZ7HkWJhehD2Y/dR2mH6dfwqbeZeqlNSTjJJp7U1dGVqRaOJeRMx4cDH5tJ3dGWj9WV7dz3FPsdKiZ7saVTZmI/mQXL2NdKUqEWtJapSi00upNb/IsekdCt3fEzx+IUvVer8R8PDPr7yjp2HiHKx/NLBJ3NcrOle2vDSrzu+pag9laXJVm9zVJ4yorTqrRpp7qX0vtP4JcSp3MvdPbC10sPbHfKfkNYAAAAAAAAAAAAAQvlYwTqYFVF+yqwqP2ZKUH8Zx8CVpW4ycT7oW9XnHz9lSYTa+wuFNCZ8m+E5zGxk9lOEqn2n6q+8/Ag7+WtKREz5T9Kndk/C3Cq5j2XEh68eK1VQV5OxG2NrHr07ryyrSbT6Iplalz0nUXS4dS3dpweXqVs2ebW8StcePtrw4xKiefD17oUnOUYLbJqPi7G3FTuvER92N54rysRK2ruO0rXiIhVT5G7a2ZPJ4jyr7O/PO+lQwktWuM6q+MYf1eHEstTT/ut/pQ7/UfNMf+0DLSIiFHM8+rxVe48tKVr4/7pa1epZdbNaZLs5i5svHV7zX+HptOo/pPaqS7d/V2ojbOb4deI8ykauD4luZ8Qu+MUkklZLUkty4FOvIh+gAAAAAAAAAAAAAwZQwca9KpRqK8JxlB9jVj2tprPMMb1i0cSoHF5PnhsRUoVVaUG49q2xkupqz7y9xXi9YmHP3pNLTVL8wKXy0/Yj5v80cL/Gme1Zx0if3X3RccT3TKawxU1sm/G/mcbi6ns444reV3OCk+z28bU+m/h/I226zt2jiby8jXp9mCc3J3k2+13IOXYyZZ5vaZbK0rXxDyaWTk5SpaMrrY/PeXGpkm1OJYzDp5q4HSm6zXqx1R65Pa+5eZ0nStbut8SfEIexf07YSHKOUKWHg6laahFcdrfBLe+pHRUxzeeIVmXLTFXm0qxznzuqYu9OnenQ2Wv60/aa3dXiXGvpxT1t5c7udQtm/lr6R/1GScrPy/JSsJnhsxU75YJPezSsoiIjiGfIGRauUK6pU1aO2c91OHF8W9y3vva0580Y6tuHDOS3ovLI+TKeFowoUY2hFd7e+UnvbZTXvN57pXePHFK9sNwxbAAAAAAAAAAAAAAACLZ65qLGxVWnaOIgmk9inH6En5PcyRr7Hw59fCLs6/xI5r5R7MrDyp060KkXCaq2akrNNQjtRx38Z27s+OY8cJvR6TWkxbzykZxS6AB6DZvxYJt6yPyOTXXaWyKd2+rel1nQ9O0bZbf/n3aNjLFI490kw9GNOKhFWilZHY4scY6xWvhVWtMzyjPKJkp1sMqkFedKTnZbXBq07fB/ZJ2nkimT1VnU8E5MXNfZVheuX9xhlEczwwylc1zPKxx44pDbyJkKtj6vNUVaCtzlRp6MF18XwW8j5s8Y4/dJxYZyWXPkHItLBUVRoxstspPpTlvlJ8fLcU+TJN55ldYsVcccQ6Jg2AAAAAAAAAAAAAAAAABgxGEjPatfFbSv3en4duvF49fv8AZsx5JpPo51bJc10WpdupnNZ/4ayRP9O3MJlNuv8Ac13g6v0H8CD/AOHsR5if8N0bGP7v2GAqv9W3a0iTh6Jm5+X/AG8nZxw3MPklLXN36ls8S61uiVr65JR8m3M/K6UIJKyVkXuPHWleKxwhzMz6y/TN4NAmInyg+cGYSqSdTCyUG3d05X0L/Va6PZrXYT8G/NY4uptrpUWmbYvRFq2ZePvbmLriqlK3xZKndxz7tGLp2Sns6eSuTitNp4moqUd8YPSm127I/Ej5N6P7UzHpW/uWJkzJ1LDU40qEFCC2JfFt731sr7WteeZWVMdaRxENo8ZAAAAAAAAAAAAAAAAAAAAfoH4DkAAAAAAAAA5AAAAAAAAAAAAAAAAAAABLjZ3ZZeCws68YKck4xim2leUkrvqW024cXxLxVo2Mvwqd0KlxmfOUKjb9JcFwpxhFLvtf4lzXSxV9lLfdy2ny0JZyY1/+bX/j1V5Mz/TYo/tj/TX+py//AFP+23hM88fSd1ipy6p6M0/3l+ZhbUwz7M67mWJ8p/mZn6sXNYfEQVOs76Mo9CbSu1Z9GW3VrvbuK7Z05xx3R4WWtu/Entt5bfKJnHVwNGnzFlUqScdJq+iopNtJ7XrSMNPBGW3Fmzc2JxVjtV5/f7KP+4/9ND+ksv0WH7Kv9dm+5/f7KP8AuV/Bof0j9Hh+x+uzfc/v9lH/AHK/g0P6R+iw/Y/XZvuz4HP/AB/O09OspQ04aUeapK8dJaSuo6tVzDJpY4rPEM8e7lm8cys7PHLE8HhKmIpxUppwjHSva8pKN2t9r3sVmDFGTJFZWuxlnHjm0Knq585Qk9L0prqjCkl2W0S3jSw8eFNO7mmfKZ5g571MTV9GxTi5tNwmko6TWtwklvtrVuDIO3qRjjuqn6m7OS3bdPqjsm1wb+BX+/CxmfSZhRs8+MoN39LkupQopeGiXtdPFx4UFtzNz5WXyeZwVcdh5yr2dSE+bckktJaKkm0tj1tauBWbWGMV+IWunnnLXmyUkZLAAAAAAAAAAAAAARHlT+bp+8pffRK0vrQhb/0pUuX0qD3W1m5mLga2Ew9WpSk5zpQnJ89VWtxTdknqKbNt5a5JiJ913g08VscTMeyHZ/5tU8BVpczJunUjOSjJ3cXBxur716y+JM09i2WJ7vZB3NeuG0dvujuAqSjVpSh0lOEo223UlYk5OJpPP2RsU8XheGd+bMco0oQdR05QlpqSjpbU042v2eBQ4M84bTML/Pg+NWIROpyVpJv0x6k38it32ibHUpmeOEK3TYiOeVaRd7FpE8qmY4SfMvNNZRVZus6XNuC6GlfS0utfRImztThmI4TNbVjNzPKYZM5MKVOrCpUxEqkYyUtFQUU2ndJu71XIWTqFrRxxwnU6dWs93Lp8qPzdU9uj+LE1aX1Ybt/0wypUvnPs2DxMqNSFWm7ThJTi+tO67jC9O+s1lnS3baLQ+gMk5SjisNDEQ2ThpW+jK1pR7nddxzt6fDv2/u6OmSMmPu/Z88nSV8OamfVavI58hiPex/DRT9Q+pH4XPTfklYJAWQAAAAAAAAAAAAA8nwe6I8qfzdP3lL76Jel9aELf+jKli+UCU4DP3G0KUKNN09CEYwjeld2Ssru5Dvo0tabT7ptN7JWsVj2cXLGV62Lqc7iJ6craK1JKK22ilsN+LFXFHFWjLmvknm0pXybZu0a9WNerWhJ02pqin6+kn6s5p7k9erfbXuIW7ntWO2I/ymaOCtrd0yt0qV1w8V+jL2X5HseYY2+Wfw+aobEdN7OWnytDkZ6OL7aPlUKrqXmq26Z4ssgrVqifKl83Vfbo/ixJel9aEPf+jKlC9c862Xsl8x6PNK0K2Ho14+04LTj+9r+0iPgy90zE+0pGbH2RE/dLeSnLWjKrgpvVNSq0/aS9eK7Vr+yyHv4fF4TdDL82OVetbSzr4Vl/mWryOfIYj3sfw0U/UPqR+Fz035JWCQFkAAAAAAAAAAAAAPJ8HuiPKn83T95S++iXpfWhC3/oypYvp8KBaOQeTvC4jDUK06lZSqU4VGozppJyinqThsKjLu5K3mscLjFoUvji08+rgZ9ZmRwEIVqVWU6cp821NLSi9FyTutqtF7iRqbU5Zmtkbb1IxRE1RTB4qdGcatKTjOLUotbn+a6iZakXjtlDpeaW5h9CZGxvpGHo17W5ynCpbg5RTa8TnL17bTDpsVu6kS2a/Rl7L8jyPMPb/LP4fNUNiOmjw5afKz+Rno4vto+VQq+pea/5W3TPFlklYtUT5Uvm6r7dH8WJL0vrQh730ZUoXrnlr5WyL6XkXCyir1aVClVjxaVNacO9a+1IpqZezYnnxMrvJi+JrR94iFY5NxkqFWnWhthKM112etdjV13ltkpF68eyopaa25hhqyvKTSsm27cLvYZVjiOGNp5nlafI38hiPex/DRT9Q+pH4XPTfklYJAWQAAAAAAAAAAAAACI8qfzdP3lH76JWl9aEPfj+lKly+c+nWR+UmeHoUqHosZqnCNNS56UbqKtdrRZXZNCL2m3cscXUJpSK9ri5052VsoaMakYwpxblGEbv1rW0nJ7Xa63bWb9fVri9Y8tGxtWzefDh0KEqkowhFynJqMUtrk9SRItaKx3Sj0rNp4h9DZGwfMYejR+hThB9qik/ic3kt3WmXTYq9tIhs1+jL2X5HkeYZX+WXzVDYjpo8OWt5WhyM9HF9tHyqFV1LzVbdM8WWQVq1RPlR+bqvt0fxYkrS+tCHv8A0ZUoXzn1/wCZ/wDkMH7il9xHO7H1bfl0uv8ASj8Khz5yJ6Hi6kYq1Kd6tPhoyeuP2Xddli3083fj/Cl3MXw8n5R8l8onC1eRz5DEe9j+Gim6h88fhddN+SVgkBZAAAAAAAAAAAAAANbKWAp4ilOhWjpU5qzXfdNPc00mn1GVbzSeYY3pW9e2yvcfyVa26GK1bo1YX7tKP8iwp1GYji0Ky/Tf/mXMnyX4zdVoP7VVf8DdHUMf2lpnpuT7w2cLyV12/wBLiacVv0Izm/jomFuo149Ks69Nt7ymebWZuGwL04J1Ktrc5Ozavt0UtUfPrIWbZvl8+PsnYdSmLx5+6REdKAK4yjyWqVSUqGJ5uDbajKnpaN3sTUlqLHH1C1YiJhV5enRaZmJSLMvNX+zlVTrc66jg36milo6XW79IjbGxOaYmYStbW+Dz6pKR0po5cyXDF0KmHqXUZpK62pppxkuxpMyx3mlotDXlxxkrNZV//wDlMr/5yOj7h3+8WP8A6M8eFbPTPXysPI+B9HoUaGlpc3CNPSta+irXtuK69pvabLPHTsr2tDOnNullCmoVG4yi9KE420ot7VbenvXUjZhz2xW5hqz69c1eJQeXJVVvqxcLe6lfw0id/wCj+yv/APMnn5k1zRzajk+lKnGo6jnLTlJpJX0UrJblq6yDnzTltzKw19eMMccu6aUgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/2Q=="
                      alt="Avatar"
                      style={{borderRadius: '50%', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                    marginLeft:10}}
                      />
      
                <Col  >
                  <div style={{marginLeft:5,marginTop:15}}>
                    <strong>BTN</strong>
                  </div>
                </Col>
                  <div className="card-header-actions">
                    <Link to="/bank-detail">
                      <Button color="primary" className="px-1">View Detail</Button>
                   </Link>   
                  </div>
               </Row>
              </CardHeader>
            </Card>
         


         
           
          </Col>
        </Row>
      </div>
    );
  }
}

export default Collapses;
