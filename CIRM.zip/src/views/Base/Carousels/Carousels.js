import React, { Component } from 'react';
import { Badge, Button, Card, CardBody, CardFooter, InputGroup,Input,FormGroup, InputGroupAddon,CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';

class Collapses extends Component {

  constructor(props) {
    super(props);
    this.onEntering = this.onEntering.bind(this);
    this.onEntered = this.onEntered.bind(this);
    this.onExiting = this.onExiting.bind(this);
    this.onExited = this.onExited.bind(this);
    this.toggle = this.toggle.bind(this);
    this.toggleAccordion = this.toggleAccordion.bind(this);
    this.toggleCustom = this.toggleCustom.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: false,
      accordion: [true, false, false],
      custom: [true, false],
      status: 'Closed',
      fadeIn: true,
      timeout: 300,
    };
  }

  onEntering() {
    this.setState({ status: 'Opening...' });
  }

  onEntered() {
    this.setState({ status: 'Opened' });
  }

  onExiting() {
    this.setState({ status: 'Closing...' });
  }

  onExited() {
    this.setState({ status: 'Closed' });
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleAccordion(tab) {

    const prevState = this.state.accordion;
    const state = prevState.map((x, index) => tab === index ? !x : false);

    this.setState({
      accordion: state,
    });
  }

  toggleCustom(tab) {

    const prevState = this.state.custom;
    const state = prevState.map((x, index) => tab === index ? !x : false);

    this.setState({
      custom: state,
    });
  }

  toggleFade() {
    this.setState({ fadeIn: !this.state.fadeIn });
  }

  render() {
    return (
      <div className="animated fadeIn">
         <br></br>
         <Row>
     
          <Col xs="12" sm="6">
        
            <Card>
              <CardHeader>
                <strong>Bank Product</strong>
                <small> </small>
              
              </CardHeader>
             </Card>
         </Col>
         </Row>

        <Row>
         
          <Col xl="6">
      
                  <Card>
             <CardHeader>
               <Row style={{marginRight:10}}>
               
               <Col  >
              <strong>Mandiri KPR Take Over</strong>
               <br></br>
              <small></small>

                </Col>
               <div className="card-header-actions">
               <Link >
                     <Button color="primary" className="px-1">View Detail</Button>
                        </Link>   </div>
               </Row>
             
             </CardHeader>
             <CardBody>
             Pembiayaan untuk pengambilalihan kredit dari KPR bank lain, 
                      dengan maksimum limit kredit sebesar outstanding (sisa pinjaman)
                       terakhir di bank asal atau limit kredit baru sesuai perhitungan 
                       bank. Jadi, apabila jumlahnya lebih besar dari outstanding 
                       terakhir di bank asal, Anda bisa menggunakannya untuk memenuhi 
                       beragam kebutuhan lain.
             </CardBody>
           
           </Card>

           <Card>
             <CardHeader>
               <Row style={{marginRight:10}}>
               
               <Col  >
              <strong>Mandiri KPR Flexible</strong>
               <br></br>
              <small></small>

                </Col>
               <div className="card-header-actions">
               <Link >
                     <Button color="primary" className="px-1">View Detail</Button>
                        </Link>   </div>
               </Row>
             
             </CardHeader>
             <CardBody>
             Sistem pembayaran angsuran yang fleksibel memungkinkan Anda untuk membeli rumah tinggal/ruko/rukan/apartemen dengan menentukan sendiri jangka waktu dan pembagian jumlah kreditnya (tersedia rekening revolving).
                         
             </CardBody>
           
           </Card>

           <Card>
             <CardHeader>
               <Row style={{marginRight:10}}>
               
               <Col  >
              <strong>Mandiri KPR Top Up</strong>
               <br></br>
              <small></small>

                </Col>
               <div className="card-header-actions">
               <Link >
                     <Button color="primary" className="px-1">View Detail</Button>
                        </Link>   </div>
               </Row>
             
             </CardHeader>
             <CardBody>
             Penambahan limit kredit untuk mandiri KPR yang sudah berjalan minimal satu tahun,
                       asalkan kolektibilitas (status pembayaran angsuran) berjalan lancar selama enam bulan terakhir. 
                       Adanya tambahan limit kredit memungkinkan Anda untuk memenuhi beragam kebutuhan lain.
                      
             </CardBody>
           
           </Card>
         
           
          </Col>
        </Row>
      </div>
    );
  }
}

export default Collapses;
