import React, { Component } from 'react';
import { Badge, Button, Card, CardBody, CardFooter, CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';

class Collapses extends Component {

  constructor(props) {
    super(props);
    this.onEntering = this.onEntering.bind(this);
    this.onEntered = this.onEntered.bind(this);
    this.onExiting = this.onExiting.bind(this);
    this.onExited = this.onExited.bind(this);
    this.toggle = this.toggle.bind(this);
    this.toggleAccordion = this.toggleAccordion.bind(this);
    this.toggleCustom = this.toggleCustom.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: false,
      accordion: [true, false, false],
      custom: [true, false],
      status: 'Closed',
      fadeIn: true,
      timeout: 300,
    };
  }

  onEntering() {
    this.setState({ status: 'Opening...' });
  }

  onEntered() {
    this.setState({ status: 'Opened' });
  }

  onExiting() {
    this.setState({ status: 'Closing...' });
  }

  onExited() {
    this.setState({ status: 'Closed' });
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleAccordion(tab) {

    const prevState = this.state.accordion;
    const state = prevState.map((x, index) => tab === index ? !x : false);

    this.setState({
      accordion: state,
    });
  }

  toggleCustom(tab) {

    const prevState = this.state.custom;
    const state = prevState.map((x, index) => tab === index ? !x : false);

    this.setState({
      custom: state,
    });
  }

  toggleFade() {
    this.setState({ fadeIn: !this.state.fadeIn });
  }

  render() {
    return (
      <div className="animated fadeIn">
         <br></br>
         <Row>
          <Col xs="12" sm="6">
            <Card>
              <CardHeader>
                <strong>Bank Officer Cabang </strong>
                <small> </small>
                {/* <div className="card-header-actions">
                  <Badge style={{color:'white', backgroundColor:'#03a840',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge>
                </div> */}
              </CardHeader>
             </Card>
         </Col>
         </Row>

        <Row>
         
          <Col xl="6">
            <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>
                <img 
                      src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxASEhUQEA8PEBUQFRAVFRUVFRUVEA8VFRUWFhUVFRUYHSggGBolHRUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OFxAQFysdHR0tKy0tKy0rLS0tLS0rLS0tLS0tKy0rLS0tLS0rLS0rLS0tKy03Ky0tLSstKy0tLSstLf/AABEIAMIBAwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAACAAEDBAUGBwj/xAA9EAABBAAEAggDBQcDBQAAAAABAAIDEQQSITEFQQYTIlFhcYGRMqHBB0JSsdEUIzNykqLwYoKyJENzwuH/xAAaAQEBAQEBAQEAAAAAAAAAAAAAAQIDBAYF/8QAIhEBAQACAgIDAAMBAAAAAAAAAAECEQMhEjEEQVETImEy/9oADAMBAAIRAxEAPwB3BRuCncFE4LIhIQkKUtQkIqKkqR0lSoGkQCcBEAgTQiASARgIpAKRoTNCkpAgiCZrCduWp2AA7ySqM3GMMz48RCKNVnBN91DmmhpBG1c+Ol2Bv+OD40a+at4fpHg3/DiI/Wx8zoppqNgIgoYJWvFsc14PNpBHyUwUaGAnpMEaAKRBqIBSNaima1Stak1qla1FhmtUgaja1G1qptHkThqlyJw1NJtFlTgKTKlStAgIw1OAjAUA5UykpOg4shRuCnKjcFXGoSgIUhCEoiOkqRUmRTJwknQEEYQhV8bjxG0u3I5Uda1Pt3eKKtTOysc/TsAnXb9fH0XNcQ6Xsbo0usb02xXIjS/8CwOP8akkd1crnsYSLDRRDd9r7R20JWNjeIsL80LSwUPi1cRd0e8+KntfQ+M8Vlmeese/volwbrro0aAURWiy3amzuUUkhO/LYcm+A8PBDmWtMmJCJpPJNakY3XXRNLtdweJmaczJMju8ZrPmtqDppxCMUXxygc3stw8LBB91hMfQ0A9QCPW9fZH1gcNgCPbyV0bddgPtGkBHXwMrmY7B/pcT+a7rg/FYcSzPC8O5Efeae4jkvEg2vXZavR3Hvw07JWE0SA8cnt7j7qWRZXtICla1DFTgHDZwBHqp2NWHQmtU7GJ2RqZrVdGwtaiDUYanpVAgJEI6T0gjypw1HSWVANJwEVJwEDUmUtJKDiXBAQpnBRkKuVQuCAhTEKMhEAhpGUyAaSToSUVLCe0KBOuwqzWtCyFwnSHic8jnNLnMawloYCC0drL2jpryN89l2mM45Fh4nRt/eTytfTG65Wmmhzq+ECibsamteXnfF5YY8ksbw8yiUuqw4F4AylpaKqr13U1tZWDiBlNVqKvUHfUUeYqlEk51+XIWTSZbjJ0k4CIMNooAVIxyIwHuUohIFVvv9FNqiBJ1UzPD/KSjhKswYY93NNmjGO6V3A4fMWgkCyNToBqN1Ph8FelWli43MvdvLTT3U2PaMK0ZQBsAB7K3G1eW9B+lD4ntgndcTqAcd2EmhZ2rx/NesMCab2JjVIGp2hSBqAMqfKpMqVIIw1PSOk9IbBScBEAipDaIhO0IyEzQiHypI6TIOIcFEVM5RFGAOUZUhCAhEAUKIpigEqfh0Ic8WMwbbiLourUDY7nSvFQrU6Nwh8uUg3kkLaNdoNOXX1Sjzzj+EcMRKeshIjDiXFzg0zGhlzmrczTc1v6cK9/KyfDWh46rvumrR1jY4y3q8OKLMoa23NBNUd7zdo2SdVwcrhZseWuo0PhW9H05JitQqSOhqUzBa0osE0iyCmV0uOO2d8R08h3rbwWDFahSw4YDZaOHgXHPP8d8OP8AUbMEDWgRu4Y07BaUEKtsiC4+ddv445w8MINAWVrcP4MN37DYf/e5akMAtW8vLuVvLUx4Zvs2EwTBs0aKTi/BWYiMgAMdXZdWoPK+8KaAFakEWi5eV3t6PDGzTx+Jr43ujlFOaS1w8e9e39EcaZ8LHI7V1ZXeJboV57064WGysmaK6wUT4hdV9l8hMMo5CQHloS3Xx3C/Qwy8sdvzcsfHKx2zGqQBJoUoaqApIhS5UJCCOkqREJUoGATogE9IIykAnLU4CBUnRJ0HBuUblK5RORgBQFGUKIjQkIymQBStcLxHVyNeboZga0NEEae6r0iaEHKdJcKGyyNIDu1IbHw1ZLbvlqP834nisBa7ex93yOvd4r0vG4QzYklwBAZlob2I9ze1/qua6UcIAaXizubHM2L07tVjDprJyMK2cONFmGPKarX8lp4bZM2+P2vYcLThAWXCVoxPXCx6JV+KlbjpUIwrsEfisWOsWIlZ0UHV0nislZajRw1WtWLwWdw+CytMUNlluMbpxhwcLn/A4fPuVv7LIv8Ap3mquSvOmj9VN0ijz4SYAbMJ9lf+zzAdVg2WCDIXOPvQ+QXs+Pf6vD8j/vbpWtUgak0KQBd64hpCQpaQkKCEhIBG4JgENkAnpEE9KCEhMApi1AWopUkjpJE04ByjKNyAhGaEoCjQlERlMiIQoEEbUIRTOc2KR7Dlc0Na134XPOUOA7wMxHiAluptrDG5ZTGfZsGGDEgPaXAinNGhvK7Lm7warXkfRZXHZY2ySRSOhiILsjCRTc1OAOmo7OVcezDSQ4h0mGe8Pjskg2516uv8V8wd1i8blkkmfPKQ50xLiQAASe4DQeSxjZW+biy47qp5Mr3W3UfmRz9dT6qdqq4NvZCs+KUx9LMbwNSVYg4iwb6dyzOqvtONJ2NiHxu+lqTGLc62m8YiH3ifILUwPEWOqnLnmxRUCyOwdjep8r3U0b2jb2TLCLjyZO7iaMmZRtbWqxcHjnOpnJdJxqVmHiY4i3PF+HqvPZ3p6ZldbZ2L42YRoxzvAblZEvSyeQgAGPwolvqqeO467cNA1q6tx8K5eqscJxk8zHSiIubGMzqy58ou3BpoOGh58l3xw1PTzZZ3ft1eDxsr8NMyQAkxS04c+ydD4rv+DgdRHQIAY0UasVpWi4no3KySM1VHML5OG23Ly5LtOj1/s7L3GYHxIcbWOPL+/jHXPDfH5X60vgIwEgEQC9LyhITEKSkJCCIhDSlITUi0ICcJ6TgKIYBItRAIqQR0kjpJF286co3I3IHIzQlAUTkCIYpkikgSlkaDC6zVSQ+gqQX7lvyUYU0DM1x3XWAtvkCdWE+Tg0qZTeNjfFn4cmOX486i6x08giJzPkcwd51y/RZfH8IYnGJxBLDVrseERsw3EpGPGhaXsvkZGh5359pwXPdK2EyvcRo4kj3XHC6y093yMfLi81CKOqBFaA+4VmOPRaHSJg/dStaQ18bNeV66ewCp4c2t14sO1OaElTDBZqIIbQLdrsH138VoiC1JHhgFPNvwA9zhC2F2UhmxDQD3fRVWRabk+a0TEglYBoly2sw0WCcQQfJdhxDBHEYRr9zES3TeiB7LjWr0LoQ/PG+M62LXDPqyvTx942OBPC7GUtdV3VnT9N10HR3hjWAxhzwx/wATQaD/AAcd63021WtisIA8kaUVYwgAOrRat5LpJxTa6yNjNGtA8tl1nBG/uW6Vq/8A5u1XLRss2uz4dHUTB/pB99fqrwTeVrPyLrHSUBOAjpPS9bxgpMWqWkxCCAhNSlLUqUEeVOGqUNT5UEOVOApC1MGoGpJSUkg8vcgcjcoygEoSnKAoySSZJA4RhAEYVSsfplwV0rhig7K3q3Oz6AteD24ye8udmHg9cfKyWVvadmyg1e69MxEDZ4H4WR5Y15a9rqzCN7diWjcEEg14LmsF0ZxDXZZDEGX8Ye1wI8Gjte4HouOUsvT28Nxzx1llpnQY9k+BEBDRLC5pG1uaAR77f0rGw66XpF0NljeZ8KxzoHtD2m9YzVSMPk4O9wuYiK1e3mnXpsYdystKzsPIrsblzsd8akIVTE/M/JXnBUptNe5SNUGQ6eK7zoMwslHiD8wvPGYh2a9Trtp8l3fRXGaOdm7WU5a1INaEhZ5MavHySNnjEJZLThWbUeN7qKKPmqWKfM8tMj3SGMVmNWbNkmtPZauHHZC4PT9JYLXb4QHIyxRytsd2i5Xg8YfMxtWLs+na+i7Ol6uDG914+fL1EdJwEeVFlXoeZGAmIUtJqQREJsqlypw1BGAiyow1EAhtDlT5VKWpNaobR5U6kLUlTby5+HKgkiIXQSYdVZsOom2E5qjIWhNCqj2qyG0CSkpCWq6NmCkagARtWQbVIgapAjToOjVSxy4Zx+6Xt79dHf8AqfUrxjjOCMU8kR+65w9NwvV+A4nq543XQJynydp9b9Fg/avwXLKMSxpp+j6GxGn0PusXqjgIir0L1nNNK3E5ZsblTTTk6BRvcSkTVncqkZHu3OVJF3a0cDE0HtFt8ha1uj8L2vdbgM10LFnVYmHwDjrmHlSvx4GR1AOF7bc0rpOP7062Bzg6jzq1t4eiNO5cacHimZSHCRgGpPxNvlry/VdVw55LbK4ZR0xtnTpOikNve/8AC2vVx/QFdNSy+i2Gyw5jvI4n0Gg+p9Vr0vXxzWLy8mW8qYBPScBFS25gpKkdJgFANJ6RUnpAICekQCKkAUmpSUlSBsqSKk6DjC1VpGq2VWkVZrMxUazJmLZxSzZWqxIolqWRTEJw1bmLSvlSAVhzFGWrGWKwmo2oAjCw0liYXEACySAB3lbuNx0E7Wse9ro8UwFr/uiRpLX+Vlp/wqHgmBLopp/wMLWfzu0J9Af7lyvAsOcRwV0je0/ByzNI5hhpxsepPusZkrmek3R2TCvojs3oRtsFkRuXWcK6Wskj/ZceC9h0bLu+PlZ7wue41gDh5Mth7HjNHI3Vkjb0IPNSKjD05iB2VdrlZjcmmpVqAOAqv0Wnw0yB2rBV72qWGPNb/DpWnShusWuuOV/WlHiOzVbqfr2xQukOzWk+fcPU6KMwgDMdANVm8XxjXtEAoucWkt/C3U2e46GvIrGOO7FyvTovs46Rlg/Z8S/Rxtrjs17j2gTyBJ9D5r0nKvDC2tua6fhHT9+HLYJ2daxjWjMD++AOw10dt4ea9mnmvb02k+VZHDOlOCnoRzsDj91/Yf5U7f0tbSjIMqWVSJIAAT0npJAwRJk6BJJJIEkkkg4tz1Xe5QnEBQSTqxihxD1SkUksigc5axIApBOlS6tkgcEaFx9fqpkAUkMTnGgNtzyaO8nks7jXFoMLbZSXy0CIGEZ9dusdtEOetu8FkTdIsQ/BvlIbEJZTFE1gNANAdI8uOrnC2NB0rtHeq4VXsWAjZ+wBrDmD2v7QrtEuILhr7ei8z4PxAcMx80WIAGGx2ZkhAPVxzb5tfuHM/wANSPulWehHTSM4eHCSyZZMOX0Xf91pfmb2jzF7dwWr0z4LHiYXOFZu0662ja3MWnnqbN/icCs2bZ3qvKuNYdjZntjILA45aIOnLUKGDHvY0xkNkjJsxvstB/E2tWnxBCqTdhzmjMQ0mr0dXKwNPUaIg8FTTe9rLGxO+CTqz+CT4fISAV/UAi6wt3HtRB8iNCqVKaJjealVsYXENrcK7hcYGWXGgNbO3usB/E44xTG5nfVXMHhpHESYkizq1m+QeW1pMNly02MXx6SRuWIUDVuI3/lb9TQ7rS4VGGdokuc6ySdST3k+ihsAUApI3gLtjhMWLna0ZZQBfd81iZ+sl1AOuti0+NxmlJ+DRbvKX8axWp4Gj4S5vhdj2KucP4xjIP4OIe0D7tkN/p1b8lVxRQx7LNbnbr8B9pOMZpNEyUd4FOPq3T+1dBhPtPwZ/isliPkHD6H5LzEuQi3GgptPGPaMN024bJtjIm+D7Yf7gFtYXFxSjNFIyQd7HBw9wvAZsrRVAlBBbDnje+Fw2dG4sI9lU8fx9DpWvGOG9NuJQ1+9ZiWjlK3tV/O3UnzXZcB+0bDTUzEMdhXaC3HNAT/5B8PrSM3Gx2ySZjgQCCCDqCNQU6ISSSSDx7iOKlbQiyWRK45roNjYZHHQ8mtcfRU243E9lzjhi1z2t0zZr7JIFn4gHDRWsaJAWujDSQJmmyRQkjdGSCNbpxrxpZroJjlaWMAEwlJzOLiaY12pJu8t+ZK45XLy6fQfDx+JfjT+Tw8tX3Zv3f8AfzWlufiLRM2G9S0k6HQ2A0fM+yOPGRkkB7TVk+QNE3zAO6pYvDyGYSM26vITYtvbBJo+FrH4hGyCANnkDHhkoj7QJlDnaCOMdog6WToKOq9Er55vYzigazOwtfTmA3YoPIAPlraunFxAWZYgCS0W9jbI3GpXn/EuMPcTGYmwDs5hlPWvytAZmcRy3oAb81nDGPZ2mSPaa1LSQT5nmuuN2PSJuPYBgt+IdKQSMkDC46f6nUB56hc1xjpfK8ZMMz9kYWlrqOaZ973LVtG2ja599LmzxAvPbcXHvJs+6TlnPKRrGbRP3JNknUk6knvJ5lddx6JrOH4Fo5tked/ikJcfzaPRcjINFe4nxJ0ojbZywsawd2g10XFazpG81v8ACumGJhjdC49Y14rtalut7rEeefeoHBWM1Ni5873OqrJNdyg8tD+fmhLlDGXWS7nzuyfFWkXDJWh3QOd4oMS8ZWu/2n8wgjeCuV6rpO1nhEQdOy9db9guqxERzZi4UNgB+Z71zfBTc2laNPkNQtyd+upXbD055exyy0gMvPwtUZZbNblRzycvRW1JEoJe71W9EQ1tLIwEdalXs9rLaVzrUgNBQh1KJ8pOgUrUuxlxcaCuEhgoKPDRhovmoJ5LKa12m93Qc1lTSv5KGFBO9RonznRrdytZmSJvVmnF3x3qNeVc1kYM5c0tXkHZHe46D9fRRNmc400kk/E76Ban6mV3067o50qnwjhFG/PGTfUu7WQV9119ny/RezYPEtljbKz4XtDh30Rz8V4PgcO2NoJGq9E+znjuYHCvOrbdETzH3m+m/qe5Wxzd0kkksjyWRVnJJIpo+fgyYjwIjcQfMEWvNOhbjNPmmJmOusnbPPm606SMVHxf+M/+ZVCkktOk9Kzt1oxbJJLOSYhek7ZJJSLQN2KjcnSViIXKNySS0yCb4P8Ad9E2HSSXLN1xaXAt3ny/MrUlP+e6SS7Y+nO+1DDn956lE34vUpJLNbjZj2/zuUjEklWKUyfCbhMks321PS/NsqZTJK5GI2bKvKkks1sp/wCB/uP/ABKn4GEklufTGX20cSdVr9EnEYuCiR+8Z8yAfzKSS1WI9pSSSXNX/9k="
                      alt="Avatar"
                      style={{borderRadius: '50%', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                    marginLeft:10}}
                      />
      
                <Col  >
               <strong>Syahroni</strong>
                <br></br>
                 <small>Mandiri</small>

                 </Col>
                <div className="card-header-actions">
                <Link to="/bank-officer-detail">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>   </div>
                </Row>
              
              </CardHeader>
            
            </Card>
         
            <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>
                <img 
                      src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSckzLXWaNfujj_7pK0_1Uefe_RTV2vIyZdnpj7Xfxd4UF2uBXQ&usqp=CAU"
                      alt="Avatar"
                      style={{borderRadius: '50%', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                    marginLeft:10}}
                      />
      
                <Col  >
               <strong> Diki Sennoaji</strong>
                <br></br>
                 <small>Mandiri</small>
           
                 </Col>
                <div className="card-header-actions">
                <Link to="/bank-officer-detail">
                      <Button color="primary" className="px-1">View Detail</Button>
                         </Link>   </div>
                </Row>
              
              </CardHeader>
            
            </Card>
          </Col>
        </Row>
      </div>
    );
  }
}

export default Collapses;
