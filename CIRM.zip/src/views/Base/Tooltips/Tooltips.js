import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';

class Forms extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300
    };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }

  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="6"></Col>
        <Row>
  
             

          <Col xs="12" md="6" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Informasi Tambahan</strong>
                <small> </small>


              </CardHeader>
              <CardBody>
             
              <strong>Provinsi Tempat Tinggal</strong>
              <br></br>
              <small>DKI Jakata  </small>
              <br></br>
                <strong>Kota/Kabupaten Tempat Tinggal</strong>
                <br></br>
                <small>Jakata Barat </small>
                <br></br>
                <strong>Kecamatan Tempat Tinggal</strong>
                <br></br>
                <small>Kemayoran </small>
                <br></br>
                <strong>Kelurahan/Desa Tempat Tinggal</strong>
                <br></br>
                <small>Gunung Sahid </small>
                <br></br>
               
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Kode</Label>
                      <Input type="text" id="name" placeholder="" required />
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Status Pernikahan</Label>
                      <Input type="text" id="name" placeholder="" required />
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Jumlah Tanggungan</Label>
                      <Input type="text" id="name" placeholder="" required />
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Pendidikan Terakhir</Label>
                      <Input type="text" id="name" placeholder="" required />
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Status Kepemilikan Rumah</Label>
                      <Input type="text" id="name" placeholder="" required />
                    </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Review oleh Loan Advisor</Label>
                      <Input type="textarea" rows="9"id="name" placeholder="" required />
                    </FormGroup>
                  </Col>
                </Row>
       
              </CardBody>
              <CardFooter>
              <Link to="/detail-pekerjaan">
                 <Button  size="sm" color="secondary"><strong>Sebelumnya</strong> </Button>
            
                       </Link> <Button type="reset" size="sm" color="transparant"> </Button>
                <div className="card-header-actions">
                 <Link to="/upload-document">
                 <Button  size="sm" color="secondary"><strong>Selanjutnya</strong> </Button>
            
                       </Link>
                </div>
              </CardFooter>
            </Card>
          </Col>



         
        </Row>
      </div>
    );
  }
}

export default Forms;
