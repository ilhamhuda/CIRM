
import React, { Component } from 'react';
import { Badge,InputGroup,InputGroupAddon, Button,FormGroup, Card,Input, CardBody, CardFooter, CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
class Collapses extends Component {

  constructor(props) {
    super(props);
    this.onEntering = this.onEntering.bind(this);
    this.onEntered = this.onEntered.bind(this);
    this.onExiting = this.onExiting.bind(this);
    this.onExited = this.onExited.bind(this);
    this.toggle = this.toggle.bind(this);
    this.toggleAccordion = this.toggleAccordion.bind(this);
    this.toggleCustom = this.toggleCustom.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: false,
      accordion: [true, false, false],
      custom: [true, false],
      status: 'Closed',
      fadeIn: true,
      timeout: 300,
    };
  }

  onEntering() {
    this.setState({ status: 'Opening...' });
  }

  onEntered() {
    this.setState({ status: 'Opened' });
  }

  onExiting() {
    this.setState({ status: 'Closing...' });
  }

  onExited() {
    this.setState({ status: 'Closed' });
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleAccordion(tab) {

    const prevState = this.state.accordion;
    const state = prevState.map((x, index) => tab === index ? !x : false);

    this.setState({
      accordion: state,
    });
  }

  toggleCustom(tab) {

    const prevState = this.state.custom;
    const state = prevState.map((x, index) => tab === index ? !x : false);

    this.setState({
      custom: state,
    });
  }

  toggleFade() {
    this.setState({ fadeIn: !this.state.fadeIn });
  }

  render() {
    return (
      <div className="animated fadeIn">
        <br></br>
        <Row>
          <Col xs="12" md="6" className="mb-4">
            <Card>
              <CardHeader>
                <strong> Pilih Bank</strong>
                <small> </small>
                <div className="card-header-actions">
         
                </div>
              </CardHeader>
             </Card>
         </Col>
         </Row>
         <Row>
          <Col xs="12" md="6" className="mb-4">
            <Card>
            <CardHeader>
            <Link to="/upload-document">
                 <Button  size="sm" color="secondary"><strong>Sebelumnya</strong> </Button>
            
                       </Link> <Button type="reset" size="sm" color="transparant"> </Button>
                <div className="card-header-actions">
                 <Link to="/cpa-bank-result">
                 <Button  size="sm" color="secondary"><strong>Selanjutnya</strong> </Button>
            
                       </Link>
                </div>
               
              
              </CardHeader>
             </Card>
         </Col>
         </Row>
         <Col xl="6">
          <FormGroup row>
                    <Col md="12">
                      <InputGroup>
                     
                        <Input type="text" id="input1-group2" name="input1-group2" placeholder="" />
                        <InputGroupAddon addonType="prepend">
                          <Button type="button" color="primary"><i className="fa fa-search"></i> Search</Button>
                        </InputGroupAddon>
                      </InputGroup>
                    </Col>
                  </FormGroup>
         
          </Col>
        <Row>
          
          <Col xl="6">
            <Card>
              <CardHeader>
                <row>

                  <img 
                      src="https://www.bankmandiri.co.id/o/mandiri-corporate-theme/images/icon/bmri-chat-logo-256x256.jpeg"
                      alt="Avatar"
                      style={{borderRadius: '50%', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                    marginLeft:10}}
                      />
                &nbsp; &nbsp; &nbsp; <strong> Bank Mandiri</strong> 
                <div className="card-header-actions">
          
                </div>
                </row>
              </CardHeader>
              <CardBody>
                <div id="accordion">
                <strong>Bank Product :</strong>
                <br></br>
                <br></br>
                  <Card className="mb-0">
                    <CardHeader id="headingOne">
                      <Button block color="link" className="text-left m-0 p-0" onClick={() => this.toggleAccordion(0)} aria-expanded={this.state.accordion[0]} aria-controls="collapseOne">
                        <h5 className="m-0 p-0">Mandiri KPR Take Over</h5>
                      </Button>
                    </CardHeader>
                    <Collapse isOpen={this.state.accordion[0]} data-parent="#accordion" id="collapseOne" aria-labelledby="headingOne">
                      <CardBody>
                      Pembiayaan untuk pengambilalihan kredit dari KPR bank lain, 
                      dengan maksimum limit kredit sebesar outstanding (sisa pinjaman)
                       terakhir di bank asal atau limit kredit baru sesuai perhitungan 
                       bank. Jadi, apabila jumlahnya lebih besar dari outstanding 
                       terakhir di bank asal, Anda bisa menggunakannya untuk memenuhi 
                       beragam kebutuhan lain.
                         </CardBody>
                    </Collapse>
                  </Card>
                  <Card className="mb-0">
                    <CardHeader id="headingTwo">
                      <Button block color="link" className="text-left m-0 p-0" onClick={() => this.toggleAccordion(1)} aria-expanded={this.state.accordion[1]} aria-controls="collapseTwo">
                        <h5 className="m-0 p-0">Mandiri KPR Top Up</h5>
                      </Button>
                    </CardHeader>
                    <Collapse isOpen={this.state.accordion[1]} data-parent="#accordion" id="collapseTwo">
                      <CardBody>
                      Penambahan limit kredit untuk mandiri KPR yang sudah berjalan minimal satu tahun,
                       asalkan kolektibilitas (status pembayaran angsuran) berjalan lancar selama enam bulan terakhir. 
                       Adanya tambahan limit kredit memungkinkan Anda untuk memenuhi beragam kebutuhan lain.
                      </CardBody>
                    </Collapse>
                  </Card>
                  <Card className="mb-0">
                    <CardHeader id="headingThree">
                      <Button block color="link" className="text-left m-0 p-0" onClick={() => this.toggleAccordion(2)} aria-expanded={this.state.accordion[2]} aria-controls="collapseThree">
                        <h5 className="m-0 p-0">Mandiri KPR Flexible</h5>
                      </Button>
                    </CardHeader>
                    <Collapse isOpen={this.state.accordion[2]} data-parent="#accordion" id="collapseThree">
                      <CardBody>
                      Sistem pembayaran angsuran yang fleksibel memungkinkan Anda untuk membeli rumah tinggal/ruko/rukan/apartemen dengan menentukan sendiri jangka waktu dan pembagian jumlah kreditnya (tersedia rekening revolving).
                       </CardBody>
                    </Collapse>
                  </Card>
                </div>
              </CardBody>
              <CardFooter>
              <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="4">
                    <Input type="text" id="text-input" name="text-input" placeholder="Wilayah" />
                    </Col>
                    &nbsp;
                    <Col md="4">
                    <Input type="text" id="text-input" name="text-input" placeholder="Cabang" />
                    </Col>
                    &nbsp;
                    <Col xs="12" md="3">
                    <Button style={{color:'white', backgroundColor:'#35d44f',}} className="px-2"><i className="fa fa-plus"></i> Tambah</Button>
              
                      </Col>
                  </FormGroup>
                  </Col>
                </Row>
{/*                
                       <div className="card-header-actions">

                     
                </div> */}
                    
                  
                </CardFooter>
            </Card>
           
          </Col>




          <Col xl="6">
            <Card>
              <CardHeader>
                <row>

                <img 
                      src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAxlBMVEX4uA3///8AAAD/vg38uw34tAD4tgD/vw34swD/wQ7CkAqkegj1tg3usQy2hwrprQyPagfkqQyugQlXQASIZQfZoQvGkwrSnAtuUga6igqbcwh3WAb//PVDMgN5WgajeQhgRwVMOAQ2KAOTbQg9LQNdRQULCABqTwUWEAHWnwstIQL72JH725r85bf968X6zm/+9uX71IT98dYkGwH++Ov84Kf6y2P5xET5x1T847H96cD60XtJNgQeFgEqHwL5wDT5wTr/yQ6oOffSAAAXgUlEQVR4nN2daWOaTBCAcXdhRUHFO5poNIkmae6jzdm0//9PvTN7ICh4sRj7zodWCSKPMzvHXliF/7tY330DucuOCA+f7h7erl9fn6+urp5fX1+vbx6eng538tV5E97dPP/4+WU5dtGOC7x3vF/vP64fnvK9g/wIDx+eb78EiONYyQJ/QVbn1/31XW73kQ/h09v9l4NsKWgLpHDuy9VDLveSA+HN/VdxbbgIJijz5dk8pWHCw9ef66sukdK6NwxplPD6BfC2pdOQTtF6NwlpjvDmNjveDPLKmOsxRHh4ZRXN4ClI2355M3NrRggfbouG1BeDtK5M5AQGCG9+GVVflNF+z54OZCZ8+8qJT0IWb7M2yIyEb1/mzdMwYybChz956i9ktN+ztMcMhHcvu+CTjFffQHj4vis+FNt63TXhq23vjs/C5vhny0RnO8K7X7vlk4z3uyO82qWBzsT2tlHjFoR3f3avQClbqXFzwqu8I+Aysb82VuOmhIcv36VAKU5x08CxIeHN9tWtKbFfNov/mxH+KH43n4Xl40aWuhHhz++1UC2OvUn434DwydsPQJBNfOr6hA/f3wRnYr+YJ7z+niifJs7XurXxuoRX++BjouI4a5aNaxLe7xsg+pv1XOp6hO9742Mi4tg3xghv9xEQpLgO4jqEexIGE6S4Rp/qGoT7qkGUNbS4mnCfAddBXEl4v9eAEPtXedRVhHuRay+TlUFjBeHzvgNi6F+e3SwnvNl/QED0tie82/M2qMRZmoYvIzy09irZThf7fUvCX/8IIMSM560I9zIZTZElDjWd8Nq4l2GMSmGMGb6046R2T6USmvUyCBe0671as9tv1noHHQ84TX5BurdJJfwy1wgZZa3hMYnL5aBS5QYhUwfg0gjNNUJGL5rnJFGOhr45TRZTmmIKobFQT63KqQYaTWvleqVe7g3OxvpY98KUIp0UlOTDh4b61RgrS5BJ/yBg0seAUKDqlBuK+4Ib+a60qJhM+NMMIG//FhD9NotaI/dBtYxxv3wk/+xTI1+XXEklEpoJFMyb4v2fD614Y6NdQgYWHmI86ArGihE1Os7ahEY0yDsTvPkhm1MQKwlXWhWHgVE42allojUm2mkSoZGqnp4IR+ItGCD9INM6wJek3hhvf6KmL0xYapI/TSB8MGGjTKimHbM+hu2NBeQSoj/88UT9kVkDPLdkwFKdr7UIjcR69CGNOdMLyNRjbEgqzKId9DCaiQvDrbvZv9ZeTMEXCV9N2CgCNucbYJuQT/9vg3jwhqPeBhqRBpgT1E1ocSE/XSQ0UBQyBBzOq4RV4OjpgIw4hArLQ7X1NBPzMC+oZG+Li85mgfBHdhXS4ySFUNqUIf6E0nqL0ZqwTF1lMKH2dnaPWpwfsJknPMwOyNGLluOAjFdPwBDP6kGJtJhPiM+qAve8rKIJszCT8zMjOj9XEL5ntlFsbqQZM1HGWxD8z3seZ/ygI1K5AeUjlZqWpR6ZDyHkyIASH5YSPmWPFD560ViD4p0zQh4rvOIz78B3LWGuHh3q7HvcktH/An+azN5mvlKcI7zNrEIOjXASPcB8yMw+2q4LXAFEw0aVWX0IfyJgKBkKLoppeiuzFueUGCd8ytwKhY1GHQaFA49t7lagGZYpB//yQS1egVjiRSrFvrBqCuXGaWZ/OqfEOKGBVvg7EuZA6AFYHrTDCelWPLc6FpkqaPpgStmn5hu0j6ciE68K95r1HuJKjBFmd6Ssjk0s8h7SsxpnnSmEB8ZaWA52ZKNrMfcjVGHJrbbwKO3BG8PuNEZ4lZ0Q/OEwYmd8ShoucIri170kp21R0vuor8p4ZqVVjSVsOetd2E9phJl/PUxbzqPvPXQdrN6ivWa91INkGwp8rIYHzGIyWpRFH05XGTYFG/jMfBv2fQph9oyUHsVUyNiAnHKIDpPf5FTUukO3fDpu1Gn5GJBEN8aFd0aUZVfxI2iz2REPkwn/ZPUzoqHN3tLOuXAcLLiEFPTkHKzSE+lAFVzKCXrUo0mDMd6U/oWhj8GyspE5JkYnvkUIs9eFGMr7oQpdTF1EF4wLtz2dAH7HhWhZg8hAMTZiRyrCYAgZUIuVW0y4JuJnvRHnTyJh9lBBwc90tImBas47QhusREblOmDWOD0nY2SmgglKRnE2cGPBEXThECZzZZMBI0KYPRaCliYRwIYn39AusSgPyIRizXSAB6l0KBBGRFLqY3OFNujJeHOcPeq/JxBeZw8Vw5mRQoERppisXWK0eo5tzVfhrqqcCz16xKSU1sZwMh8jfWAiJFp2AuFLdiOFRlaRNweGqTslQEnQ2uqyeVWlcYr+NuE6A8xQ4b8jIKT9KdI+goPN7k3fFggPs1cVGO6r8qUfdix57XKV1WSkwB4oaaQD7U+wEIamS7HLA/wo/ts30RBneU1IaKB7BusmaaT8uKTqWtqBRAwcauvCc+FVg0jfQlRYAQXLHAGTNsgX0JuWF7t4tpCwwyYkzG6krKMLQ9ZRPS68coIdaU3smXFlJ4b4+4F6FRy0/p7IYMiE7YKGsToZZe+TCs1UExrovcCUTToaVqXCRdJp12dY2MJ73pYZaFNFBEFIR+Qcqv8zKsI9EJ5Q0TQ/sxOGZqoJs3tSURiciGBXcTsnB5BrV3p//RYHwsdhCYN+6Vi4UBHVRcgXho22zdoQC8EI8BfyY4nR1mLPEWYv7kVGg4kXOMYumZLPJj34C/HjxFX1w5FL3RGegic2m+Jc/FXOzgnjH01BiOaJDitzVgOEN3FCA/3cmhDc48hrPZIu5XVSwcao+2N8zAm6FKvkIfgd/JCHem8yRmoUrRQDP4fKOMh+O859jPDBQEd3qMMKqf/tY9kUkKrbKnfcdrdbL5UvyYjyBhlzDPcNTgNM8CA2nIM9t7B9AqEM/ER53GyEXzHC7LWvJBSBDCJ/xz3qcnocCAda5lj/UtYkAS2TTxcrECwbRcdFW7xskyl6G5OEVvEpSpg9VsjgLUM1a5DSR8CCoQuqnIC+5AC3270AZf3mogtqqtylLzq+D8i56GUUVvpohtC+jhKaGG7CtLQm46C81wu3DuUT73W8+mAwGEICCn4UeHlDu1JLaKxJMUD6EFxEaQj1h06NMonKviWhmSHDCroR+ZpOoEiCfAVyN8Z7ytOMAjh2XqOsowOjJQqPY0HYZu6nyFr9eGfW1qIaoiR8NjGihk1Kd3ZDFOhA6+pQiwbQrC4bstepzdg5+BfsNSa/mZhLBOo+4khYo+CBerIGfjQwlKg7pCxT0dCSJVGYUJJTF4dbONx7o0U5b4lpNT4d4Rm+zGnYSf/ib5NcCsIPVyhS1B3Z+zFQZESUhGYmkrJIBwSY7MDiFPvvy65wsIJqwErag8piijS74EBFoopzNHzZnA1k3paeCCYIs3fmC4Esc9ahj/1L/d7kbHwiLE62vbCr0Z2KzMwVim1IQggilzRWZWYUmZpapuK9JcNFM9YRRc7+fsi7ZZ+k7J+FLgSixjGVn8AeG0E4lZ+mxEhKY+kJ4JYxRyNtbxztLb2oETata7M8/QsJTahi0SsqyhEyDCeHgRdCZT8amupWPNSE2XvZlJB4rGa8dj4oq6K+06oLZwrBn6uiXoBX6h1GZUD5pDIzGpiZBSZnDlumMhoUDobWiw+OlmSHFJuc+vhHTnG09OhAnYS1Y4/LngsiP8sejQznCxFZjSA0cz1Zu88Vr4wFLc4gubnEjm0uhn8hNg5kwENCMdgmZ2j6ysuamnNq/1CEBjqhtJBFBfhk1BMdGEcQFps4pYQHyltixi3KEVkIY8rHz0zFChDnVhEaydmEoIrmo7VHqugxp23IvcGL4PAhrRMM/HwAukWPI/ttRH9wQMyk3UJE5z4S3pibtO6TSL++FD7qDc5cjjMw6aUcsQeOiTBRfyBOd0UqXqeyJU+NJDRCPEVoKFig4GSuj3hSiQqSA6Bgk+fyRQtDPx+Rkmh8YsiKHFE1eJV9rkIo2KWIhAamQYVSXRz/cwmRzJBwS08L4e+Mu/BjXIrhC1lN4a+AnXAGVShybyS8N7j6B1viJF77QNmnJo9q/bhj0ramMsgfcyr6cUqyfRpshZYMiEhoaFa3EjKvBjS9CuMUe0wFKSB96JoRGqawUYyKYipGzZQjRcFuYSQ0uoJLBLT4JEORdR83mx+iG0Z3l5Ke0GIg5reJCSo4Rv7bJKAI+UhocHmMpWaOxr0F89TSA9FbL5AaZV8UFiOBK/KehA9mFZxQi4Se2VV4DHKWydwkQ8hG/Yv2sIbZdqteusDZNYLtWJuoxYcqYhgUTGosg0mbEtGcfi9OvmdqyZr6X051F05GAKK/6Rv0oyjYK2zhAhmzl5WTDC9XThVVfA1xogBsmNWg7G7Lg1DM1iOf1aWIqmACp4Sn4diiicmlc4KJaS6EFhWT79vLbE4m2z25doZh9XRkZFVJTPIjlKsNIINJvWdMQMdlS8bHAL1qwzhfroQWbeF8taMgRY2scnnSkuvymJwsbKquj0mehBADxUBvzUq+c1+tkmX8QlS/JtZaLEquhKEvqbN0W2U8EInNZSsPDeZOCO1LzpHtBYnrRBm12jLVOTG76nkmitB0xJ8Jo6VHgfBRrrrRNeq4jJS2B2L5HulX81GgFcbD/AjRDCuXMu599sulwPegxrD8aqfSVGtkST/NGZkQnbUZzkvjwlh7SmbyefkYWdj92TO6Yn1BcOTCfG2xIIx79fnV+CjjZofnZp9ScCat8fowURi3LurNs1B7p/1eyTe8q0KS6PrQzOjhCsHufM78KojH+Q7oUHAE0XQ/zX5J8cF8X9t+ie5rMzCnbU9F95ca7PPeL3F0n/fdznb0UjvwbP15tYXPul7K+aVH13alQ3/aBZluPbbEOvIC6y6qEXOGBOHykB/ufbTkyHqiZpOebpunyQ0n5JDjOiImYwjCpZ3ebNiUEnZlsgt1ZNOlgorwKCvhuhPdxUxoQbg0IHKdiITGRbvqyNGG5rZrQrFyXRAun6evCSd0/gjZc0J7rfk0cnBPSCdcLaJlw8nKOyaU67sE4bIqP8KjOovodJ55Xdk14e1sXtsSZ8rCZfNqANeKrMEOZ2fpzeaWbjXHQkLG5jali2xWFz04d9UNCeVGJ5JwyZQhsYBHiZhmoaYVCBGLD+A2qu16szudTgflC7ybACuIahAOlIqKAkQRflilSr3S9nXxy6gVVHoD+Hy3WW+pGMS435EHp81eW27kEyf01NekNhW51aAkXJKZ8sYMSJgpj1SzOGGWdQaXsyPks0LpWL7UzpeqZek1pf2JOvWjpJYnTqP7uZ22xfzM3ohEZYCdOTFCpnZJ+0ydbSsXBknCJXkbk9t1yZvG7/Yi78WqwQMSl4Grm65a+6R9lefPnUnOPKan70VkSKOtX0uJxghdbVupI0AiZwvneadPMFW/u1wzgRNcK5H351EVhVJx5a+iJg9pggFfICRjVMDCYTD1RUISsAgh1Ys40p2dmBEVEqZmNVoBMgb2qUXF0uvfVB7GGefYK3857ZXLQ2XQv3ldMQkluuf6DkOU8aN+hWu6eR+soQsX6CnDm9IZYeNIv+rSGWFoF0sW76tFM4owNeari54qo9D+sOZGfkG/7svt9Fzld6tMfb+4wkXIovNSOLeqQ84FmEXrwBOfp67KlkJtDSinltq5h/CQkFrqJ1o2pKqWrCvC1IaogkXDlXN8S0o9LbXlg5oea0nXzpVJt7ka30Uz1VsLdVg0HjLtsFDPTF/AVQvcwhYnZma4kznusqs+fLokbKhmGK57SmuIKlg0KRW2Nv0rLHHsqrB/opwJ94KDcnOgVFDS9ih87WeIFY342s7kXibw47QOhs1BQxtBlJCqo54+Wtcxetk4s97uUxOmJd9qJ6AhU6pQA5v6rVhfQfVUCy0lpqNoOMFbrI6N5TR0ok+xeLV3FLtAsJxQW/jSlEovWNeEadt5Kgup6LYtv6wqNzEhYoIMDWf/zAj1nJmS/ik+w0UImlDNKYX7tgbzF1hBqKS5fFVGIU6Yti5I3RT4AzoOL43bA6gvc2e1FHJoLjFPFH9trpxumaUSWrMLk9DtLiXsq7OXTb7Ri/NmhMndwrq1BDFV4YpW9YeqDkyjg4C5LCTUxmlp3xH5uRShtI5PrjxRt12lOldYQVjXu6Iu0WC4q0JImNzhphMWNpusRdRGJPJlR2V1DRcdohcSiilc+LI5u9O4p1GXa6i4U8N1J/rrVhCWXXUkffOF2Y60sx0HknUovdZEzOnR3uBYzk2XP6eK57JDI0KobvZMpjfVBR26ytTKSu+daFa/ipDq3GGYFg9DI40QJtYXyieKmc3KuaidLbhMt0/csSRBHbIIocUj6bTaYEfXFn8pZzqM+yzUIQTE9ay0LCaIz36YBJlt/TEjTJztrS7ejxqZXPdClStRy+xJo9QKWqUIoV4lgqJcgrrAZNrs6lz2hFK1XVS3HQStkzUJxY4v4lrJlUXkeQmRvU2SymB2ru4D3yj/KHFVFDh1q2RBSlGTJbMNBBYz7wa1QnVEZDWhpX+Y5GVukd29I4SJa4HlZVRyFhYY+Ea5Vo8u3mEpVlPMFigsEMqEoTx/eB1Cpn/ZXhJiZC+sCGHCsgvt89UtyiajXiunAMHf1/FJySiIGeVsLZQ3jZ13LDfosWhrboj42NcsooimozlC0SOs22zSCpvofmbRfaISSqigglJXHQWsBG/0BavyT6J+8tq9/tnoctToN+sdT/dOuOrOZh3H3OpUmsenl+NRt3YwG8Jn3C+d9BtwgbN+rdLyuP7iivSwJflV4VHZrKk8XDlYJIzuex0lTPI1LNZptPhGd7XgCC8XY7uzv+sAymLXC0+Mf48+rC/AIpefvWbxL43fXSix7YRj+7Vl3uwrJlwZby+9SM1JYrsJxwjNDpXqZmhgj4sNJbaZcHxnSJMPlgm7Z3avwh+FVEITm0do0T0ZJleIrCfFw3RCM/vNC9EpzXGOk7qSxYlvBz1HaE6JrHGEMt5waMOA2E/LCA22ROH9ea7T1hLFnnuS7jyhwZV63yT24XJCo+70OyTuSJMI//XpQwtP8VjcV99sYrNrWXw4wiKhuXXP3yAJD7hIeL7FTiZj5iQJDylJIMxt7n7+IkfuVxIWXv9ZO016vlzis4L+nQcfxqX4mgCTSPiPPJ1zXvR42hqERmuM3Ymd+FDZZMJ/MiimPKozhdDQzlG7lLRnPKYQ/oP+NO05nWmEe/7A8UVJfQR5KmG+q6GMy0JJsQbh7ua3G5DkQLGCMIfH5eYmjpX6sNxlhIX7f6Yppj1ldRWhsV3O8pbi9RKIpYT/iLdJ9zKrCZ8MPVM2V7Hnn7S2CaGpPSPzlCVudB1Cc48+zkuSHsy5EWHhbb8Rna/0OLEm4X5nqMsC4dqE+4zoWIkl4aaEhed9RVwHcC3CfdWi46000XUJ99PdrHYyGxAWbuy9C/32n9W3vQFh4WHfshs7pdNia8LC037lqMWE3u2MhIXDlz3K4IpXq294Y8JC4X1f/I1jp3XKZCQsXO+Hv7G/1giD2xEW7rw9sNT1m+AWhIXCz++2VMdOGn4xSFh4/V5Ltb/mn51unLBw9/V9luoU71ffYGbCQuG++E1qtK0NfGgWwsLDt6jR2dDFZCHEbYl2rkbbW9Ipap6wcPeyW1N1NshizBBCubHD2OgUf24S5A0RQu3v7IbRKf7azkAzE2JzzJ/Rsb+28KCmCAuH9zkzOra3bFAif0JkdPLzq07xKyOfAUJgvLLyYXTsX5ns0xghyNsv47HDse33DP5lJmYIIT7eG1WkU/yzYQmRKqYIQd5eikYgHWjY90bUJ8QgIbTI5xc7I6RjF61bA61vJkYJQQ7fbp2tKQHv64c57UkxTYjy8OOPvSklmGbR+fm8dW6WLnkQghze/HhxEHMNTgdP9G6fTStPSU6EQu7ern5+FYsCdBEVj8Gfis6v9+eHHHSnJU9CKXcPrz9uX748jHBF5JXM1tefl/ertzzZpORPGMrh09PT3cPDw90dvFhr2MiI7JDwm+T/T/gfDLmXqWHGk/MAAAAASUVORK5CYII="
                      alt="Avatar"
                      style={{borderRadius: '50%', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                    marginLeft:10}}
                      />
                &nbsp; &nbsp; &nbsp; <strong> Maybank</strong> 
                <div className="card-header-actions">
          
                </div>
                </row>
              </CardHeader>
              <CardBody>
                <div id="accordion">
                <strong>Bank Product :</strong>
                <br></br>
                <br></br>
                  <Card className="mb-0">
                    <CardHeader id="headingOne">
                      <Button block color="link" className="text-left m-0 p-0" onClick={() => this.toggleAccordion(0)} aria-expanded={this.state.accordion[0]} aria-controls="collapseOne">
                        <h5 className="m-0 p-0"> Kredit Properti Multiguna</h5>
                      </Button>
                    </CardHeader>
                    <Collapse isOpen={this.state.accordion[0]} data-parent="#accordion" id="collapseOne" aria-labelledby="headingOne">
                      <CardBody>
                      Pembiayaan untuk pengambilalihan kredit dari KPR bank lain, 
                      dengan maksimum limit kredit sebesar outstanding (sisa pinjaman)
                       terakhir di bank asal atau limit kredit baru sesuai perhitungan 
                       bank. Jadi, apabila jumlahnya lebih besar dari outstanding 
                       terakhir di bank asal, Anda bisa menggunakannya untuk memenuhi 
                       beragam kebutuhan lain.
                         </CardBody>
                    </Collapse>
                  </Card>
                  <Card className="mb-0">
                    <CardHeader id="headingTwo">
                      <Button block color="link" className="text-left m-0 p-0" onClick={() => this.toggleAccordion(4)} aria-expanded={this.state.accordion[1]} aria-controls="collapseTwo">
                        <h5 className="m-0 p-0">KTA (Tanpa Agunan)</h5>
                      </Button>
                    </CardHeader>
                    <Collapse isOpen={this.state.accordion[1]} data-parent="#accordion" id="collapseTwo">
                      <CardBody>
                      Penambahan limit kredit untuk mandiri KPR yang sudah berjalan minimal satu tahun,
                       asalkan kolektibilitas (status pembayaran angsuran) berjalan lancar selama enam bulan terakhir. 
                       Adanya tambahan limit kredit memungkinkan Anda untuk memenuhi beragam kebutuhan lain.
                      </CardBody>
                    </Collapse>
                  </Card>

                </div>
              </CardBody>
              <CardFooter>
              <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="4">
                    <Input type="text" id="text-input" name="text-input" placeholder="Wilayah" />
                    </Col>
                    &nbsp;
                    <Col md="4">
                    <Input type="text" id="text-input" name="text-input" placeholder="Cabang" />
                    </Col>
                    &nbsp;
                    <Col xs="12" md="3">
                    <Button style={{color:'white', backgroundColor:'#35d44f',}} className="px-2"><i className="fa fa-plus"></i> Tambah</Button>
              
                      </Col>
                  </FormGroup>
                  </Col>
                </Row>
{/*                
                       <div className="card-header-actions">

                     
                </div> */}
                    
                  
                </CardFooter>
            </Card>
           
          </Col>
        </Row>
      </div>
    );
  }
}

export default Collapses;
