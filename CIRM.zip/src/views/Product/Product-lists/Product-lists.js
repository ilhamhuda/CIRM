


import React, {Component} from 'react';
import {Badge,Card, ButtonDropdown,
  ButtonGroup,
  ButtonToolbar,Dropdown,
  DropdownItem,
  DropdownMenu,CardHeader,
  DropdownToggle, CardBody, Col, Button,Nav, NavItem, NavLink, Row, TabContent, TabPane} from 'reactstrap';
import classnames from 'classnames';
import { Link } from 'react-router-dom';

class App extends Component {

  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      activeTab: new Array(4).fill('1'),
    };
  }
   submit(data) {
    this.props.history.push({
      pathname: '/product-detail',
      id: data
    })
    }


  note() {
    return (
     
      <Row>
       
        <Col>
          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong> KPR</strong>
              <br></br>
          
               </Col>
              <div className="card-header-actions">
        
                      <Button  onClick={() => this.submit(1)} color="primary" className="px-1">View Detail</Button>
                         </div>
              </Row>
            
            </CardHeader>
          
          </Card>

          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong> Kredit Multiguna Individu</strong>
              <br></br>
          
               </Col>
              <div className="card-header-actions">
        
                      <Button  onClick={() => this.submit(3)} color="primary" className="px-1">View Detail</Button>
                         </div>
              </Row>
            
            </CardHeader>
          
          </Card>


          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong> Take Over Individu</strong>
              <br></br>
          
               </Col>
               <div className="card-header-actions">
        
                      <Button  onClick={() => this.submit(2)} color="primary" className="px-1">View Detail</Button>
                         </div>
              </Row>
            
            </CardHeader>
          
          </Card>
       
        </Col>
      </Row>
   
    )
   }
   
   loan() {
    return (
     
      <Row>
       
        <Col >
          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong> Rekening Koran Perusahaan</strong>
              <br></br>
          
               </Col>
                <div className="card-header-actions">
        
                      <Button  onClick={() => this.submit(5)} color="primary" className="px-1">View Detail</Button>
                         </div>
              </Row>
            
            </CardHeader>
          
          </Card>

          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong> Kredit Investasi Perusahaan</strong>
              <br></br>
          
               </Col>
                 <div className="card-header-actions">
        
                      <Button  onClick={() => this.submit(4)} color="primary" className="px-1">View Detail</Button>
                         </div>
              </Row>
            
            </CardHeader>
          
          </Card>


          <Card>
            <CardHeader>
              <Row style={{marginRight:10}}>
         
              <Col  >
             <strong> Take Over Perusahaan</strong>
              <br></br>
          
               </Col>
               <div className="card-header-actions">
        
                      <Button  onClick={() => this.submit(6)} color="primary" className="px-1">View Detail</Button>
                         </div>
              </Row>
            
            </CardHeader>
          
          </Card>
       
        </Col>
      </Row>
   
    )
   }
  toggle(tabPane, tab) {
    const newArray = this.state.activeTab.slice()
    newArray[tabPane] = tab
    this.setState({
      activeTab: newArray,
    });
  }

  tabPane() {
    return (
      <>
        <TabPane tabId="1">
          {this.note()}
        </TabPane>
        <TabPane tabId="2">
        {this.loan()}
        </TabPane>
        <TabPane tabId="3">
       
        </TabPane>
      </>
    );
  }

  render() {
    return (
      <div className="animated fadeIn">
        <br></br>
        <Row>
          <Col xs="12" sm="6">
            
            <Card>
              <CardHeader>
                <strong>Product</strong>
                <small> </small>
             
              </CardHeader>
             </Card>
         </Col>
         </Row>
        <Row>
     
          <Col xs="12" md="6" className="mb-4">
            <Nav tabs>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '1'}
                  onClick={() => { this.toggle(0, '1'); }}
                >
                  <strong>Individu</strong>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '2'}
                  onClick={() => { this.toggle(0, '2'); }}
                >
                    <strong>Perusahaan</strong>
                </NavLink>
              </NavItem>
         
            </Nav>
            <TabContent activeTab={this.state.activeTab[0]}>
              {this.tabPane()}
            </TabContent>
          </Col>
        
          </Row>
        <br></br>

     

      </div>
    );
  }
}

export default App;
