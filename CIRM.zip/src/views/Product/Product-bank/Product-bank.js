import React, { Component } from 'react';
import { Badge, Button, Card, CardBody, CardFooter, InputGroup,Input,FormGroup, InputGroupAddon,CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
class Collapses extends Component {

  constructor(props) {
    super(props);
    
    this.state = {
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      title: '',
      listing: [],
      Detail: '',
      listing_bank: [],
      listing_produk: [],
      selectedBank: null,
      selectedProduk: null
    };
  }

   componentWillMount() {
   
      const bank = `${this.state.API_URL}/bank/lists/`;
    axios.get(bank, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listing_bank: data })
     })

      const produk = `${this.state.API_URL}/bank/product_lists`;
    axios.get(produk, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listing_produk: data })
     })

  }

  submit() {
 const data = `${this.state.API_URL}/bank/product_bank_by_category/`+ this.state.selectedBank +`?id_product=`+ this.state.selectedProduk;
    axios.get(data, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listing: data })
     })



  }

   listing(listing) {
      return(
       
             <Card>
             <CardHeader>
               <Row style={{marginRight:10}}>
               
               <Col  >
              <strong>{listing.title}</strong>
               <br></br>
              <small></small>

                </Col>
               <div className="card-header-actions">
           
                     <Button  onClick={() => this.detail()} color="primary" className="px-1">View Detail</Button>
                      </div>
               </Row>
             
             </CardHeader>
             <CardBody>
            
<div>{ ReactHtmlParser(listing.description) }</div>
             </CardBody>
            
           
           </Card>
  
           )
    }

     detail(id) {
    console.log('data profile adalah :', id)
  
  this.props.history.push({
    pathname: '/bank-product-detail',
    id: id,
  })
  }


  render() {
    return (
      <div className="animated fadeIn">
         <br></br>
         <Row>
     
          <Col xs="12" >
        
            <Card>
              <CardHeader>
                <strong>Product</strong>
                <small> </small>
              
              </CardHeader>
              <CardBody>

              <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="4">
           
           
               
              
                      <Input onChange={(event)=> this.setState({selectedBank: event.target.value})} placeholder="Pilih Bank"  type="select" name="selectSm" id="SelectLm" bsSize="sm">
                          <option >Pilih Bank</option>
                         {this.state.listing_bank.map(listing_bank => (
                                
                                <option  value={listing_bank.id} >{listing_bank.name}</option>
                              ))}
                       
                      </Input> 
       
               
                    </Col>
                  
                    <Col md="4">
                    
              
                      <Input onChange={(event)=> this.setState({selectedProduk: event.target.value})} placeholder="Pilih Produk" type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       <option>Pilih Produk</option>
                         {this.state.listing_produk.map(listing_produk => (
                                
                                <option  value={listing_produk.id} >{listing_produk.title}</option>
                              ))}
                       
                      </Input> 
                  
                
                    </Col>
                  
                    <Col md="4">
                    <Button onClick={() => this.submit()}  style={{color:'white', backgroundColor:'#35d44f',}} className="px-2">
                    <i className="fa fa-search"></i> Search Product</Button>
              
                      </Col>
                  </FormGroup>
                  </Col>
                </Row>
              </CardBody >
              

                    
                  
            
             </Card>
             
         </Col>
         </Row>

        <Row>
         
          <Col xl="6">
      
             
          {this.state.listing.map((item)=>this.listing(item))}
    
           
          </Col>
        </Row>
      </div>
    );
  }
}

export default Collapses;
