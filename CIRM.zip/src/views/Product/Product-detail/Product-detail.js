import React, { Component } from 'react';
import { Badge,FormGroup,Input,Label, Button, Card, CardBody, CardFooter, CardHeader, Col, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import axios from 'axios';

class App extends Component {
   constructor(props) {
    super(props);


    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300,
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      title: '',
      listing: [],
      Detail: '',
    };
  }

  componentWillMount() {
    const { id } = this.props.location
    console.log('ini data kiriman : ', id)
    const url = `${this.state.API_URL}/bank/product_detail/` + id;
    axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ Detail: data })
      console.log('data API : ',this.state.Detail)
     })

     const urlmy = `${this.state.API_URL}/bank/lists_by_product/`+ id;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listing: data })
      console.log('data API : ',this.state.contact)
     })
  }

   submit(id) {
    console.log('data profile adalah :', id)
  
  this.props.history.push({
    pathname: '/product-bank',
    id: id,
    id_user: id 
  })
  }

    listing(listing) {
      return(
       
            <Card  key={listing.id}>
             <CardHeader>
               <Row style={{marginRight:10}}>
               
               <Col  >
              <strong>{listing.name}</strong>
               <br></br>
              <small></small>

                </Col>
               <div className="card-header-actions">
             
                     <Button  onClick={() => this.submit(listing.id)}  color="primary" className="px-1">View Detail</Button>
                     </div>
               </Row>
             
             </CardHeader>
           
           </Card>
  
           )
    }

  render() {
    return (
      <div className="animated fadeIn">
        <br></br>
        <Row>
          <Col xs="12" md="6">

          <h1> {this.state.Detail.title}</h1>


<div>{ ReactHtmlParser(this.state.Detail.content) }</div>
          </Col>
         
        </Row>

        <Row>
         
         <Col xl="6">
          <strong> Daftar Bank yang menyediakan Produk ini : </strong>
          <br/>
          <br/>
        {this.state.listing.map((item)=>this.listing(item))}
          
         </Col>
       </Row>
      </div>
    );
  }
}

export default App;