import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
   Modal, ModalBody, ModalFooter, ModalHeader,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';
import axios from 'axios';
import NumberFormat from 'react-number-format';

class Forms extends Component {
  constructor(props) {
    super(props);

    this.state = {
      id: null,
      detail: [],
      contact: [],
     user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm/',
      notif_delete:false
    };
  this.toggleDanger = this.toggleDanger.bind(this);
  }
  toggleDanger() {
    this.setState({
      notif_delete: !this.state.notif_delete
    });
  }
  componentWillMount() {
    // global.userid = 1;
    this.state.id = localStorage.getItem("loanId");
  
     
     const url = `${this.state.API_URL}application/detail/`+this.state.id;
     axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ detail: data })
      console.log('data API : ',this.state.access)
     })

    
     axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.contact)
    .then((data) => {
      this.setState({ contact: data })
      console.log('data API : ',this.state.access)
     })
  }

  delete() {
    const url = `${this.state.API_URL}/application/delete/` + this.state.id ;
    axios.post(url,{}, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);
        
     this.setState({
      notif_delete: !this.state.notif_delete,
    });

      this.props.history.push({
      pathname: '/application-lists',
    })

     })

 
  }
  edit() {
      this.props.history.push({
      pathname: '/application-edit',
    })


  }


  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="6"></Col>
        <Row>
  
             

          <Col xs="12" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Detail Pinjaman</strong>
                <small> </small>
                <div className="card-header-actions">
               
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button onClick={() => this.edit()} style={{color:'white', backgroundColor:'grey'}} className="mr-1"><i className="fa fa-pencil"></i></Button>
                     &nbsp;&nbsp;
                     <Button color="danger"  onClick={this.toggleDanger} className="mr-1"><i className="fa fa-trash"></i> </Button>
          
                
              
                <Modal isOpen={this.state.notif_delete} toggle={this.toggleDanger}
                       className={'modal-danger ' + this.props.className}>
                  <ModalHeader toggle={this.toggleDanger}>Hapus Loan</ModalHeader>
                  <ModalBody>
                    Apakah kamu yakin ingin menghapus Contact?
                  </ModalBody>
                  <ModalFooter>
                    <Button color="danger" onClick={() => this.delete()}>Hapus</Button>{' '}
                    <Button color="secondary" onClick={this.toggleDanger}>Batal</Button>
                  </ModalFooter>
                </Modal>     
                </div>

              </CardHeader>
              <CardBody>
             
              <strong>Status Pinjaman</strong>
              <br></br>
              <small>{this.state.detail.loan_step} </small>
              <br></br>
           
              <small>__________________________________________________</small>
            
               
                <Row>
                  <Col xs="12">
                  <FormGroup row>
               
                    <Col md="9">
                      <FormGroup >
                     
                 <Label check className="form-check-label" htmlFor="radio1"><strong>Nama Nasabah</strong></Label>
                   <br></br>
                   <small> {this.state.contact.name}</small>
                  
                      </FormGroup>
              
                      <FormGroup >
                     
                    <Label check className="form-check-label" htmlFor="radio3"><strong>Jumlah Pinjaman</strong></Label>
                 <br></br>
                  
                 <NumberFormat value={this.state.detail.loan_amount} displayType={'text'} thousandSeparator={true} prefix={'Rp.'} />
                <small>,-</small>
               
                      </FormGroup>
                    
                      <FormGroup >
                    
                    <Label check className="form-check-label" htmlFor="radio3"><strong>Tanggal Pengajuan</strong></Label>
                 <br></br>
                 <small> {this.state.detail.created_date} </small>
                   
                      </FormGroup>
                     <FormGroup >
                      
                     <Label check className="form-check-label" htmlFor="radio3"><strong>Loan Advisor</strong></Label>
                   <br></br>
                   <small> {this.state.detail.advisor}</small>
                      </FormGroup>
       
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
       
              </CardBody>
              <CardFooter>
                 <Button size="sm" color="success"> Process to Bank</Button>
                <Button type="reset" size="sm" color="transparant"></Button>
              
              </CardFooter>
            </Card>
          </Col>



         
        </Row>
      </div>
    );
  }
}

export default Forms;
