import React, { Component } from 'react';
import { Badge,Alert, TabPane,Nav,NavItem,Label,NavLink,
  Modal, ModalBody, ModalFooter, ModalHeader,
  TabContent, Button, Card, FormGroup, InputGroup, InputGroupAddon, Input, CardBody, CardFooter, CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
import NumberFormat from 'react-number-format';
import Search from 'react-search'
import { PDFReader } from 'reactjs-pdf-reader'
import PDFViewer from 'pdf-viewer-reactjs'
import Viewer, { Worker } from '@phuocng/react-pdf-viewer';

import '@phuocng/react-pdf-viewer/cjs/react-pdf-viewer.css';
class Collapses extends Component {


//    HiItems(id,e) {
//  console.log('ENTITAS DATA',id,e)
//     var data = e
//      const urlmy = `${this.state.API_URL}/bank/branch_by_location/`+id + `?location` + data;
//      // https://loanmarket.co.id/api/crm/bank/branch_by_location/10?location=KOTA
//     axios.get(urlmy, {auth: {
//       username: this.state.user,
//       password: this.state.pass
//     }}).then(response => response.data.data)
//     .then((data) => {
//       if(data != undefined){
//       this.setState({ listingBranch: data, })
//       console.log('Branch', this.state.data)
//       }
//      })
     
//   }



HiItems(items) {

  this.setState({ listingBranch: [], })
 console.log('inisiasi data BO', items)

const urlmy = `${this.state.API_URL}/bank/branch_by_location/`+ 10 + `?location` + 'Jakarta';
   // https://loanmarket.co.id/api/crm/bank/branch_by_location/10?location=KOTA
  axios.get(urlmy, {auth: {
    username: this.state.user,
    password: this.state.pass
  }}).then(response => response.data.data)
  .then((data) => {
    if(data != undefined){
    this.setState({ listingBranch: data, })
   
    }
   })
        
}

getItemsAsync(searchValue, cb) {
 
  const urlmy = `${this.state.API_URL}/lookup/loc_sugg/` + searchValue;
  axios.get(urlmy, {auth: {
    username: this.state.user,
    password: this.state.pass
  }}).then(response => response.data.data)
  .then((data) => {

    let items = data.map( (res, i) => { return { id: i, value: res.label } })
    this.setState({ listingWilayah: items })

    cb(searchValue)

   });
}





  constructor(props) {
    super(props);
 
   this.state = {
      radio1: 0,
      radio2: 0,
      radio3: 0,
      radio4: 0,
      radio5: 0,
      radio6: 0,
      radio7: 0,
      branchT:null,
      radio8: 0,
      radio9: 0,
      radio10: 0,
      radio11: 0,
      radio12: 0,
      radio13: 0,
      radio14: 0,
      radio15: 0,
      radio16: 0,
      radio17: 0,
      radio18: 0,
      radio19: 0,
      radio20: 0,
      docs1: [],
      docs2: null,
      docs3: null,
      docs4: null,
      docs5: null,
      docs6: null,
      docs7: null,
      docs8: null,
      docs9: null,
      docs10: null,
      docs11: null,
      docs12: null,
      docs13: null,
      docs14: null,
      docs15: null,
      docs16: null,
      radio1Check: false,
      radio2Check: false,
      radio3Check: false,
      radio4Check: false,
      radio5Check: false,
      radio6Check: false,
      radio7Check: false,
      radio8Check: false,
      radio9Check: false,
      radio10Check: false,
      radio11Check: false,
      radio12Check: false,
      radio13Check: false,
      radio14Check: false,
      radio15Check: false,
      radio16Check: false,
      radio17Check: false,
      radio18Check: false,
      radio19Check: false,
      radio20Check: false,
      pdf: 'https://arxiv.org/pdf/quant-ph/0410100.pdf',
      dependents_type: [],
      doc_type: [],
      bankListsProduct: [],
      education_type: [],
      job_position: [],
      job_type: [],
      idBank: null,
      lenght_of_employement: [],
      marital_status: [],
      listing_produk:[],
      monthly_income: [],
      listingWilayah: [],
      listingBranch: [],
      residential_status: [],
      bankterpilih: [],
      collapse: false,
      accordion: [true, false, false],
      custom: [true, false],
      status: 'Closed',
      fadeIn: true,
      timeout: 300,
      activeTab: new Array(4).fill('1'),
      contact:[],
      detail: [],
      id_user:null,
      id_contact: null,
      id:null,
      access:[],
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm/',
      provinsi: [],
      ref: [],
      provinsiT: null,
      kota: [],
      kotaT: null,
      kecamatan: [],
      kecamatanT: null,
      kelurahan: [],
      kelurahanT: null,

      //pinjaman
      property_price: null,
      loan_amount: null,
      tenor: null,

      //pekerjaan
      id_job_type: null,
      company: null,
      position: null,
      id_lenght_of_employement: null,
      id_monthly_income: null,

      //alamat
      id_province: null,
      id_city: null,
      id_subdistrict: null,
      postal_code: null,
      id_suburb: null,

      //Informasitambahan
      la_review: null,
      id_marital_status:null,
      id_dependents_type: null,
      id_education_type:null,
      id_residential_status: null,
      selectedProduk: null,
      notif_email:false,

      
      ProductTerpilih: [],

      contact_nama: null,
      no_ktp : 8293437410239123029,
      contact_advisor: null,
      contact_address: null
















    };
    this.selectedProduk = this.selectedProduk.bind(this);
    this.toggleDanger = this.toggleDanger.bind(this);
  }
  toggleDanger() {
    this.setState({
      notif_email: !this.state.notif_email
    });
  }
  componentWillMount() {

       const produk = `${this.state.API_URL}/bank/product_lists`;
    axios.get(produk, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listing_produk: data })
     })

     
    //  const CPA = `${this.state.API_URL}/application/cetak_cpa/` + this.state.id;
    //  axios.get(CPA, {auth: {
    //    username: this.state.user,
    //    password: this.state.pass
    //  }}).then(response => response.data)
    //  .then((data) => {
    //    this.setState({ pdf: data.file })
    //   })

this.state.id = localStorage.getItem("loanId");
  
     
     const url = `${this.state.API_URL}application/detail/`+this.state.id;
     axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data)
    .then((data) => {
      this.setState({ detail: data,
      
       //pinjaman
      property_price: data.data.property_price,
      loan_amount: data.data.loan_amount,
      tenor: data.data.tenor,

      //pekerjaan
      id_job_type: data.contact.id_job_type,
      company: data.contact.company,
      position: data.contact.position,
      id_lenght_of_employement: data.contact.id_lenght_of_employement,
      id_monthly_income: data.contact.id_monthly_income,
      id_contact: data.contact.id,
      id_user: data.contact.id_user,
      //alamat
      id_province: data.contact.id_province,
      id_city: data.contact.id_city,
      id_subdistrict: data.contact.id_subdistrict,
      postal_code: data.contact.postal_code,
      id_suburb: data.contact.id_suburb,

      //Informasitambahan
      la_review: data.data.la_review,
      id_marital_status:data.contact.id_marital_status,
      id_dependents_type: data.contact.id_dependents_type,
      id_education_type:data.contact.id_education_type,
      id_residential_status: data.contact.id_residential_status,


        //Informasitambahan
      bankterpilih: data.application_product,
      

      contact_nama: data.data.contact,
      contact_advisor: data.data.advisor,
      contact_address: data.contact.address,










      })
      console.log('data position', this.state.position, this.state.company)
   
     })

    
    const urlprov = `${this.state.API_URL}lookup/province`;
     axios.get(urlprov, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ provinsi: data })
 
     })

       const urlref = `${this.state.API_URL}lookup/reference`;
     axios.get(urlref, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data)
    .then((data) => {
      this.setState({ ref: data ,
        dependents_type: data.dependents_type,
        doc_type: data.doc_type,
        education_type: data.education_type,
        job_position: data.job_position,
        job_type: data.job_type,
        lenght_of_employement: data.lenght_of_employement,
        marital_status: data.marital_status,
        monthly_income: data.monthly_income,
        residential_status: data.residential_status,
      })
    
     })
  }
  
  selectedProduk(event){
    console.log('data', event.target.value)
    const id = event.target.value
    const urlpro = `https://loanmarket.co.id/api/crm/bank/product_bank_by_category?id_product=` + event.target.value;
     axios.get(urlpro, {auth: {
      username:  'admin',
      password: 'lo4nM4rk3t'
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ bankListsProduct: data, selectedProduk: id })
 
     })

  }

 


  kota(id){
 const url = `${this.state.API_URL}lookup/city/` + id;
     axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ kota: data })

     })
  }


kecamatan(id){
 const url = `${this.state.API_URL}lookup/subdistrict/` + id;
     axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ kecamatan: data })

     })
  }



kelurahan(id){
 const url = `${this.state.API_URL}lookup/suburb/` + id;
     axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ kelurahan: data })
     
     })
  }

  
submit() {
    
    var bodyFormData = new FormData();

   //pinjaman
      bodyFormData.set('property_price', this.state.property_price);
      bodyFormData.set('loan_amount', this.state.loan_amount);
      bodyFormData.set('tenor', this.state.tenor);
   
 
      //pekerjaan

      bodyFormData.set('id_job_type', this.state.id_job_type);
      bodyFormData.set('company', this.state.company);
      bodyFormData.set('position', this.state.position);
      bodyFormData.set('id_lenght_of_employement', this.state.id_lenght_of_employement);
      bodyFormData.set('id_monthly_income', this.state.id_monthly_income);

      //alamat

      bodyFormData.set('id_province', this.state.id_province);
      bodyFormData.set('id_city', this.state.id_city);
      bodyFormData.set('id_subdistrict', this.state.id_city);
      bodyFormData.set('postal_code', this.state.postal_code);
      bodyFormData.set('id_suburb', this.state.id_suburb);

      //Informasitambahan
      bodyFormData.set('la_review', this.state.la_review);
      bodyFormData.set('id_product', this.state.selectedProduk);
      bodyFormData.set('id_marital_status', this.state.id_marital_status);
      bodyFormData.set('id_dependents_type', this.state.id_dependents_type);
      bodyFormData.set('id_education_type', this.state.id_education_type);
      bodyFormData.set('id_residential_status', this.state.id_residential_status);



        //Informasitambahan
 bodyFormData.set('id_advisor', this.state.id_user);
      bodyFormData.set('id_contact', this.state.id_contact);


      bodyFormData.set('docs[1]', this.state.docs1);
      bodyFormData.set('docs[2]', this.state.docs2);
      bodyFormData.set('docs[3]', this.state.docs3);
      bodyFormData.set('docs[4]', this.state.docs4);
      bodyFormData.set('docs[5]', this.state.docs5);
      bodyFormData.set('docs[6]', this.state.docs6);
      bodyFormData.set('docs[7]', this.state.docs7);
      bodyFormData.set('docs[8]', this.state.docs8);
      bodyFormData.set('docs[9]', this.state.docs9);
      bodyFormData.set('docs[10]', this.state.docs10);
      bodyFormData.set('docs[11]', this.state.docs11);
      bodyFormData.set('docs[12]', this.state.docs12);
      bodyFormData.set('docs[13]', this.state.docs13);
      bodyFormData.set('docs[14]', this.state.docs14);
      bodyFormData.set('docs[15]', this.state.docs15);
      bodyFormData.set('docs[16]', this.state.docs16);
      
    const url = `${this.state.API_URL}/application/update/` + this.state.id;
    axios.post(url,bodyFormData, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
        console.log(data);

   

     })
      this.props.history.push({
          pathname: '/application-detail',
          id: this.state.contact_id 
        })
  }
 
   pinjaman() {
    return (
     <Row>
    <Col xs="12" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Pinjaman</strong>
                <small> </small>
              </CardHeader>
              <CardBody>
       
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Harga Properti</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.property_price} onChange={(event)=> this.setState({property_price: event.target.value })}type="number" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>


                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
                   
                    <strong>Jumlah Pinjaman</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.loan_amount}  onChange={(event)=> this.setState({loan_amount: event.target.value })} type="number" id="text-input" name="text-input" placeholder="" />
                       </Col>
                  </FormGroup>
                  </Col>
                </Row>


                  <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
                   
                    <strong>Jangka Waktu</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.tenor} onChange={(event)=> this.setState({tenor: event.target.value })}type="number" id="text-input" name="text-input" placeholder="" />
                       </Col>
                  </FormGroup>
                  </Col>
                </Row>
               
               
           
               
              </CardBody>
             
            </Card>
          </Col>

      </Row>
   
   
    )
   }

 pekerjaan() {
    return (
     
       
       
     
        <Row>
          <Col xs="12" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Detail Pekerjaan</strong>
                <small> </small>
              </CardHeader>
              <CardBody>
                <Row>
                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Pekerjaan Anda Sekarang</strong>
                    </Col>
                    <Col xs="12" md="9">
                        <Input value={this.state.id_job_type} onChange={(event)=> this.setState({id_job_type: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.job_type.map(listing => (
                            
                                <option  value={listing.id} >{listing.name}</option>
                              ))}
                       
                      </Input> 
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Nama Kantor/Nama Usaha</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.company} onChange={(event)=> this.setState({company: event.target.value })} type="text" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
                   
                    <strong>Jabatan Anda Sekarang</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.position} onChange={(event)=> this.setState({position: event.target.value })} type="text" id="text-input" name="text-input" placeholder="" />
                       </Col>
                  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
                 
                      <strong>Lama Bekerja</strong>
                    </Col>
                    <Col xs="12" md="9">
                         <Input value={this.state.id_lenght_of_employement} onChange={(event)=> this.setState({id_lenght_of_employement: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.lenght_of_employement.map(listing => (
                            
                                <option  value={listing.id} >{listing.name}</option>
                              ))}
                       
                      </Input> 
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
         
                      <strong>Penghasilan Per Bulan</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={this.state.id_monthly_income} onChange={(event)=> this.setState({id_monthly_income: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.monthly_income.map(listing => (
                            
                                <option  value={listing.id} >{listing.name}</option>
                              ))}
                       
                      </Input> 

                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
           
               
              </CardBody>
             
            </Card>
          </Col>

      </Row>
   
    )
   }

review() {
    return (
     
     
      <Row>
  
             

          <Col xs="12"  className="mb-4">
            <Card>
              <CardHeader>
                <strong>Review</strong>
                <small> </small>


              </CardHeader>
              <CardBody>
             
           
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Review oleh Loan Advisor</Label>
                      <Input value={this.state.la_review} onChange={(event)=> this.setState({la_review: event.target.value })} type="textarea" rows="9"id="name" placeholder="" required />
                    </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                     <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Jenis Pinjaman</Label>
                           <Input value={this.state.selectedProduk} onChange={this.selectedProduk} placeholder="Pilih Produk" type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       <option>Pilih Produk</option>
                         {this.state.listing_produk.map(listing_produk => (
                                
                                <option  value={listing_produk.id} >{listing_produk.title}</option>
                              ))}
                       
                      </Input> 
                       </FormGroup>
                  </Col>

                </Row>

              </CardBody>
            
            </Card>
          </Col>



         
        </Row>
   
    )
   }

     informasi() {
    return (
     
     
      <Row>
  
             

          <Col xs="12"  className="mb-4">
            <Card>
              <CardHeader>
                <strong>Informasi Tambahan</strong>
                <small> </small>


              </CardHeader>
              <CardBody>
             
             
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Status Pernikahan</Label>
                     <Input value={this.state.id_marital_status} onChange={(event)=> this.setState({id_marital_status: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.marital_status.map(listing => (
                            
                                <option  value={listing.id} >{listing.name}</option>
                              ))}
                       
                      </Input> 
  </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Jumlah Tanggungan</Label>
                     <Input value={this.state.id_dependents_type} onChange={(event)=> this.setState({id_dependents_type: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.dependents_type.map(listing => (
                            
                                <option  value={listing.id} >{listing.name}</option>
                              ))}
                       
                      </Input> 
 </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Pendidikan Terakhir</Label>
                       <Input value={this.state.id_education_type} onChange={(event)=> this.setState({id_education_type: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.education_type.map(listing => (
                            
                                <option  value={listing.id} >{listing.name}</option>
                              ))}
                       
                      </Input> 
 </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                    <FormGroup>
                      <Label htmlFor="name">Status Kepemilikan Rumah</Label>
                     <Input value={this.state.id_residential_status} onChange={(event)=> this.setState({id_residential_status: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.residential_status.map(listing => (
                            
                                <option  value={listing.id} >{listing.name}</option>
                              ))}
                       
                      </Input> 
  </FormGroup>
                  </Col>
                </Row>
               
       
              </CardBody>
            
            </Card>
          </Col>



         
        </Row>
   
    )
   }

    alamat() {
    return (
     
             
        <Row>
          <Col xs="12" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Alamat</strong>
                <small> </small>
              </CardHeader>
              <CardBody>
              

                <Row>
                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Provinsi Tempat Tinggal</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={

                        (event)=> 
                        {
                          this.setState({provinsiT: event.target.value})
                          this.kota(event.target.value)

                        }

                        } type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.provinsi.map(provinsi => (
                            
                                <option  value={provinsi.id} >{provinsi.name}</option>
                              ))}
                       
                      </Input> 
       
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>


                    <Row>
                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Kota/Kabupaten Tempat Tinggal</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={

                        (event)=> 
                        {
                          this.setState({kotaT: event.target.value})
                          this.kecamatan(event.target.value)

                        }

                        } type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.kota.map(kota => (
                            
                                <option  value={kota.id} >{kota.name}</option>
                              ))}
                       
                      </Input> 
       
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>

                    <Row>
                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Kecamatan Tempat Tinggal</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={

                        (event)=> 
                        {
                          this.setState({kecamatanT: event.target.value})
                          this.kelurahan(event.target.value)

                        }

                        }  type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.kecamatan.map(kecamatan => (
                            
                                <option  value={kecamatan.id} >{kecamatan.name}</option>
                              ))}
                       
                      </Input> 
       
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>

                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
                   
                    <strong>Kode Pos</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input type="number" id="text-input" name="text-input" placeholder="" />
                       </Col>
                  </FormGroup>
                  </Col>
                </Row>

                    <Row>
                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Kelurahan Tempat Tinggal</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={(event)=> this.setState({kelurahanT: event.target.value})} type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.kelurahan.map(kelurahan => (
                            
                                <option  value={kelurahan.id} >{kelurahan.name}</option>
                              ))}
                       
                      </Input> 
       
                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
           
               
              </CardBody>
            
            </Card>
          </Col>

      </Row>
   
    )
   }
  
  upload() {
    return (
     
      
      <Row>
  
             

          <Col xs="12" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Upload Dokumen</strong>
                <small> </small>
              </CardHeader>
              <CardBody>

                <Row>
                  <Col xs="12">
                    <FormGroup>
                    <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>KTP Pemohon</strong></Label>
                        &nbsp;
                        &nbsp;
                        <input value={this.state.radio1Check} onChange={(event)=> this.setState({radio1Check: !this.state.radio1Check})}  style={{marginTop:5}} type="checkbox" />
                       
                        &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input value={this.state.docs1} onChange={(e)=>this.setState({docs1:e.target.files})} type="file" name="file1"   />  
                      </FormGroup>    
                  </Col>
                </Row>


                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>KTP Pasangan</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio2Check} onChange={(event)=> this.setState({radio2Check: !this.state.radio2Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input value={this.state.docs2} onChange={(e)=>this.setState({docs2:e.target.files})} type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>


                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>NPWP</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio3Check} onChange={(event)=> this.setState({radio3Check: !this.state.radio3Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input  value={this.state.docs3} type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>


                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>KK (Kartu Keluarga)</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio4Check} onChange={(event)=> this.setState({radio4Check: !this.state.radio4Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>


                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>Akte Nikah/Cerai</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio5Check} onChange={(event)=> this.setState({radio5Check: !this.state.radio5Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>


               
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>SPT</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio6Check} onChange={(event)=> this.setState({radio6Check: !this.state.radio6Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>

                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>Slip Gaji</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio7Check} onChange={(event)=> this.setState({radio7Check: !this.state.radio7Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>

                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>Slip Gaji</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio8Check} onChange={(event)=> this.setState({radio8Check: !this.state.radio8Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>


              
                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>Rekening Terakhir</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio9Check} onChange={(event)=> this.setState({radio9Check: !this.state.radio9Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>Slip Gaji</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio10Check} onChange={(event)=> this.setState({radio10Check: !this.state.radio10Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>Surat Keterangan</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio11Check} onChange={(event)=> this.setState({radio11Check: !this.state.radio11Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>Akta Pisah Harta</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio12Check} onChange={(event)=> this.setState({radio12Check: !this.state.radio12Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>Pernyataan Kepemilikan</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio13Check} onChange={(event)=> this.setState({radio13Check: !this.state.radio13Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>SHM</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio14Check} onChange={(event)=> this.setState({radio14Check: !this.state.radio14Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                <Row>
                  <Col xs="12">
                    <FormGroup>
                     <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>IMB</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio15Check} onChange={(event)=> this.setState({radio15Check: !this.state.radio15Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>
                
                <Row>
                  <Col xs="12">
                    <FormGroup>
                       <Row style={{marginLeft:0}}>
                      <Label htmlFor="name"><strong>PBB</strong></Label>
                         &nbsp;
                        &nbsp;
                        <input value={this.state.radio16Check} onChange={(event)=> this.setState({radio16Check: !this.state.radio16Check})}  style={{marginTop:5}} type="checkbox" />
                           &nbsp;
                        &nbsp;
                        <p> Verified</p>
                    </Row>
                      <Input type="file" id="file-input" name="file-input" />  
                      </FormGroup>
                  </Col>
                </Row>

            
    

           
       
              </CardBody>
          
            </Card>
          </Col>



         
        </Row>
   
    )
   }


  bankListsProduct(listing) {
   return (
     
            <Card>
            <CardBody >
              <div >

                    <div >
                      <span class="pull-left">
                        <input type="checkbox" name="input[48]" value="1" id="input_481"/>

                      </span>
                      <div >
                      &nbsp;
                      <label for="input_481">
                      
                        <div ><b>  {listing.title} </b></div>
                       <small>{listing.description} </small>
                <br/>
                 <small><b>Interest Rate</b> : {listing.interest_rate} </small>
         
               
        
                        
                      </label>
                        
                       </div>
                    </div>

                  </div>
                   </CardBody >
                  
            </Card>
 
    );
   }


   bankpilihan() {
   return (
      <div className="animated fadeIn">
        <br></br>
       
         <Row>
      
         </Row>
    
        <Row>
          
          <Col xl="6">
          
            {this.state.bankListsProduct.map((item)=>this.bankListsProduct(item))}

          </Col>
         
        </Row>
      </div>
    );
   }



   bankLists(listing){
    return (
        <Card>
                <CardBody>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Bank</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={listing.id_bank} type="text" id="text-input" name="text-input" disabled placeholder="Mandiri" />
                         </Col>
                  </FormGroup>
                  </Col>
                 
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Product</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value={listing.id_bank_product}  type="text" id="text-input" name="text-input" disabled placeholder="Cibubur" />
                         </Col>
                  </FormGroup>
                  </Col>

                    <Col xs="12">
                     <FormGroup row>
                     <Col md="3">
               
                      <strong>Wilayah</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                
                      {/* <Search items={this.state.listingWilayah}
                        multiple={false}
                        placeholder='Cari Wilayah'
                        getItemsAsync={this.getItemsAsync.bind(this)}
                        onItemsChanged={(e)=>this.HiItems(listing.id,e)
                        } /> */}

                        <Search items={this.state.listing}

                        multiple={false}
                        placeholder='Cari Cabang'
                        getItemsAsync={this.getItemsAsync.bind(this)}
                        onItemsChanged={this.HiItems.bind(this)}


                        />
       
                    </Col>


                  </FormGroup>
         
          </Col>


                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Cabang</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={

                        (event)=> 
                        {
                          this.setState({branchT: event.target.value})
                          this.branch(event.target.value)

                        }

                        } type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.listingBranch.map(a => (
                            
                                <option  value={a.id} >{a.name}</option>
                              ))}
                       
                      </Input> 
       
                    </Col>
                  </FormGroup>
                  </Col>
     
   <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Bank Officer</strong>
                    </Col>
                    <Col xs="12" md="9">
                      <Input onChange={

                        (event)=> 
                        {
                          this.setState({kotaT: event.target.value})
                          this.kecamatan(event.target.value)

                        }

                        } type="select" name="selectSm" id="SelectLm" bsSize="sm">
                       
                         {this.state.kota.map(kota => (
                            
                                <option  value={kota.id} >{kota.name}</option>
                              ))}
                       
                      </Input> 
       
                    </Col>
                  </FormGroup>
                  </Col>
     

                   
                </Row>
              </CardBody>
                </Card>


    )

   }

   bankterpilih() {
    return (
     
     
    <Row>
          <Col xs="12"className="mb-4">
            <Card>
              <CardHeader>
                <strong>Data Bank Terpilih</strong>
                <small> </small>
              </CardHeader>
              <CardBody>

              
               {/* {this.state.bankterpilih.map((item)=>this.bankLists(item))} */}

               <Card>
                <CardBody>
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Bank</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value='MANDIRI' type="text" id="text-input" name="text-input" disabled placeholder="Mandiri" />
                         </Col>
                  </FormGroup>
                  </Col>
                 
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Product</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input value="KPR MANDIRI"  type="text" id="text-input" name="text-input" disabled placeholder="Cibubur" />
                         </Col>
                  </FormGroup>
                  </Col>

                    <Col xs="12">
                     <FormGroup row>
                     <Col md="3">
               
                      <strong>Wilayah</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                
                    <Input value="Jakarta Pusat"  type="text" id="text-input" name="text-input" disabled placeholder="Cibubur" />
                       
                        {/* <Search items={this.state.listingWilayah}

                        multiple={false}
                        placeholder='Cari Cabang'
                        getItemsAsync={this.getItemsAsync.bind(this)}
                        onItemsChanged={this.HiItems.bind(this)}


                        /> */}
       
                    </Col>


                  </FormGroup>
         
          </Col>


                  <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Cabang</strong>
                    </Col>
                    <Col xs="12" md="9">
                    <Input value='Menteng' type="text" id="text-input" name="text-input" disabled placeholder="Cibubur" />
                   
       
                    </Col>
                  </FormGroup>
                  </Col>
     
   <Col xs="12">
           
                    <FormGroup row>
                    <Col md="3">
                    <strong>Bank Officer</strong>
                    </Col>
                    <Col xs="12" md="9">
                    <Input value='Simon Santoso' type="text" id="text-input" name="text-input" disabled placeholder="Cibubur" />
                   
       
       
                    </Col>
                  </FormGroup>
                  </Col>
     

                   
                </Row>
              </CardBody>
                </Card>
           
               
              </CardBody>
          
              
            </Card>
          </Col>

      
      
        </Row>
   
    )
   }

    ExamplePDFViewer = () => {
    return (
        <PDFViewer
            document={{
                url: 'https://arxiv.org/pdf/quant-ph/0410100.pdf',
            }}
        />
    )
}


   cpa() {
    return (
     
     
    <Row>
          <Col xs="12"className="mb-4">
            <Card style={{height:800, width:'100%'}} >
              <CardHeader>
                <strong>Preview CPA</strong>
                <small> </small>
              </CardHeader>
              <CardBody>

           

              <iframe style={{height:800, width:'100%'}} src="https://loanmarket.co.id//api/assets/pdf/application/cpa/1.pdf" />
              </CardBody>
          
              
            </Card>
          </Col>

      
      
        </Row>
   
    )
   }

   emailLists(listing) {
    return (
     
      <Row key={listing.id}>
       
        <Col>
        <Card>
              {/* <CardHeader>
              
                <strong>Bank : {listing.id_bank}</strong>

               
               
                <small> </small>
             
               
                
                 <div className="card-header-actions">
             
             <Button  onClick={this.toggleDanger} className="mr-1">Detail Email</Button>
      
            
          
 
                      </div>
                
               
              
              </CardHeader> */}
              <CardHeader>
              <strong>Bank : {listing.id_bank}</strong>
                <small> </small>
                <div className="card-header-actions">
               
                     <Button  style={{marginLeft:30}}onClick={this.toggleDanger} className="mr-1">Detail Email</Button>
      
                </div>

              </CardHeader>
            
            </Card>
       
        </Col>
      </Row>
   
    )
   }

   email() {
    return (
     
     
    <Row>
          <Col xs="12"className="mb-4">
            <Card>
              <CardHeader>
                <strong>Email to Bank Officer</strong>
                <small> </small>
                <div className="card-header-actions">
              
              <Button onClick={() => this.submit()} style={{marginLeft:30, paddingRight:30,paddingLeft:30}}  size="sm" color="primary"><strong>Sent Email</strong> </Button>
         
           </div>
              </CardHeader>
              <CardBody>

   
              {/* {this.state.bankterpilih.map((item)=>this.emailLists(item))} */}

              <Row >
       
       <Col>
       <Card>
             {/* <CardHeader>
             
               <strong>Bank : {listing.id_bank}</strong>

              
              
               <small> </small>
            
              
               
                <div className="card-header-actions">
            
            <Button  onClick={this.toggleDanger} className="mr-1">Detail Email</Button>
     
           
         

                     </div>
               
              
             
             </CardHeader> */}
             <CardHeader>
             <strong>Bank : Mandiri </strong>
               <small> </small>
               <div className="card-header-actions">
              
                    <Button  style={{marginLeft:30}}onClick={this.toggleDanger} className="mr-1">Detail Email</Button>
     
               </div>

             </CardHeader>
           
           </Card>
      
       </Col>
     </Row>
               
              </CardBody>
          
              
            </Card>
          </Col>

      
      
        </Row>
   
    )
   }

   suketUI(listing){
     return(

      <Col xs="6"className="mb-4">
      <Card>
        <CardHeader>
          <strong>Surat Keterangan</strong>
          <small> </small>
        </CardHeader>
        <CardBody>
<div>
<strong> {this.state.contact_address} </strong>,
<br/>Ref :
<br/>
<br/>Kepada Yth: 

<br/>Perihal : Surat Pengantar Aplikasi Loan Market
<br/>

<br/>Sehubungan dengan adanya aplikasi atas nama debitur:
<br/>

<br/>Nama Debitur : <strong> {this.state.contact_nama} </strong>

<br/>No. KTP : <strong>387364758920</strong>

<br/>Alamat : <strong> {this.state.contact_address} </strong>

<br/>Plafon Kredit : <strong> {this.state.property_price} </strong>

<br/>Jenis Fasilitas : <strong> KPR </strong>

<br/>Alamat Agunan : <strong> {this.state.contact_address} </strong>
<br/>

<br/>Maka dengan ini kami ingin memberitahukan bahwa calon debitur tersebut merupakan referral dari Loan Market. Kami mohon bantuan rekan-rekan Bank<strong>   MANDIRI </strong> untuk dapat membantu memproses kredit calon debitur tersebut.

<br/>Demikian surat ini kami buat atas perhatian dan kerjasamanya kami ucapkan terima kasih.
<br/>
<br/> <strong>{this.state.contact_advisor}</strong>
<br/>Principal
</div>             
     
         
        </CardBody>
    
        
      </Card>
    </Col>


     )


   }
   suket() {
    return (
     
     
    <Row>
      
      {/* {this.state.bankterpilih.map((item)=>this.suketUI(item))} */}
        
      <Col xs="12"className="mb-4">
      <Card>
        <CardHeader>
          <strong>Surat Keterangan</strong>
          <small> </small>
        </CardHeader>
        <CardBody>
<div>
<strong> Depok </strong>,
<br/>Ref :
<br/>
<br/>Kepada Yth: <strong>Simon Santoso</strong>

<br/>Perihal : Surat Pengantar Aplikasi Loan Market
<br/>

<br/>Sehubungan dengan adanya aplikasi atas nama debitur:
<br/>

<br/>Nama Debitur : <strong> Riko Suheluhu</strong>

<br/>No. KTP : <strong>387364758920</strong>

<br/>Alamat : <strong> Depok</strong>

<br/>Plafon Kredit : <strong> Rp. 100.000.000 </strong>

<br/>Jenis Fasilitas : <strong> KPR </strong>

<br/>Alamat Agunan : <strong> Depok </strong>
<br/>

<br/>Maka dengan ini kami ingin memberitahukan bahwa calon debitur tersebut merupakan referral dari Loan Market. Kami mohon bantuan rekan-rekan Bank<strong>   MANDIRI </strong> untuk dapat membantu memproses kredit calon debitur tersebut.

<br/>Demikian surat ini kami buat atas perhatian dan kerjasamanya kami ucapkan terima kasih.
<br/>
<br/> <strong>Kiyoko Sari</strong>
<br/>Principal
</div>             
     
         
        </CardBody>
    
        
      </Card>
    </Col>
      
        </Row>
   
    )
   }

   toggle(tabPane, tab) {
    const newArray = this.state.activeTab.slice()
    newArray[tabPane] = tab
    this.setState({
      activeTab: newArray,
    });
  }

  tabPane() {
    return (
      <>
        <TabPane tabId="1">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
       
                       </div>
          {/* {this.my()} */}
          {this.pinjaman()}
        </TabPane>

        <TabPane tabId="2">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
     
                       </div>
                       {this.pekerjaan()}
        </TabPane>

       <TabPane tabId="3">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
     
                       </div>
                       {this.alamat()}
        </TabPane>
         <TabPane tabId="4">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
     
                       </div>
                       {this.informasi()}
        </TabPane>
         <TabPane tabId="5">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
     
                       </div>
                       {this.upload()}
        </TabPane>
         <TabPane tabId="6">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >

     
                       </div>
                       {this.bankpilihan()}
        </TabPane>
            <TabPane tabId="8">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
      
     
                       </div>
                       {this.review()}
        </TabPane>
         <TabPane tabId="7">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
     
                       </div>
                       {this.bankterpilih()}
        </TabPane>

        <TabPane tabId="9">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
     
                       </div>
                       {this.suket()}
        </TabPane>

        <TabPane tabId="10">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
     
                       </div>
                       {this.cpa()}
        </TabPane>

        <TabPane tabId="11">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
     
                       </div>
                       {this.email()}
        </TabPane>


      </>
    );
  }

  render() {
    var modalStyles = {overlay: {zIndex: 1}};
    return (
      
      <div className="animated fadeIn" style={{marginLeft:-30, marginRight:-30}}>
                  <Modal style={ modalStyles }  isOpen={this.state.notif_email} toggle={this.toggleDanger}
                 className={'modal-primary ' + this.props.className}>
            <ModalHeader toggle={this.toggleDanger}>Email to Bank Officer</ModalHeader>
            <ModalBody>
            <Row>
  
             

  <Col xs="12"  className="mb-4">
    <Card>
      <CardHeader>
        <strong>Review</strong>
        <small> </small>


      </CardHeader>
      <CardBody>
     
      <Row>
             <Col xs="12">
            <FormGroup>
              <Label htmlFor="name"> Bank Officer :     <strong>Simon Santoso</strong></Label>
           
               </FormGroup>
          </Col>
     
        </Row>
          
      <Row>
             <Col xs="12">
            <FormGroup>
              <Label htmlFor="name">Subject</Label>
                   <Input value='Sehubungan Dengan Pengajuan Pinjaman KPR' onChange={this.selectedProduk} placeholder="Pilih Produk" type="text" name="selectSm" id="SelectLm" bsSize="sm">
              </Input> 
               </FormGroup>
          </Col>

        </Row>

        <Row>
          <Col xs="12">
            <FormGroup>
              <Label htmlFor="name">Compose Email</Label>
              <Input value='Maka dengan ini kami ingin memberitahukan bahwa calon debitur tersebut merupakan referral dari Loan Market. Kami mohon bantuan rekan-rekan Bank MANDIRI untuk dapat membantu memproses kredit calon debitur tersebut.' onChange={(event)=> this.setState({la_review: event.target.value })} type="textarea" rows="9"id="name" placeholder="" required />
            </FormGroup>
          </Col>
        </Row>
      

      </CardBody>
    
    </Card>
  </Col>



 
</Row>
            </ModalBody>
            <ModalFooter>
              <Button color="primary">Simpan</Button>{' '}
              <Button color="secondary" onClick={this.toggleDanger}>Batal</Button>
            </ModalFooter>
          </Modal> 
         <br></br>
         <Col >
          <Col xs="12" >
     
            <Card>
              <CardHeader>
   
                <strong>Detail Application</strong>
               <small> </small>
                <div className="card-header-actions">
              
                 <Button onClick={() => this.submit()} style={{marginLeft:30, paddingRight:30,paddingLeft:30}}  size="sm" color="primary"><strong>Save</strong> </Button>
            
              </div>
              </CardHeader>
             </Card>
         </Col>
     
         
        

     
         
          <Col xs="12" className="mb-4">
       
            <Nav tabs>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '1'}
                  onClick={() => { this.toggle(0, '1'); }}
                >
                  <strong>1. Pinjaman</strong>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '2'}
                  onClick={() => { this.toggle(0, '2'); }}
                >
                    <strong>2. Pekerjaan</strong>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '3'}
                  onClick={() => { this.toggle(0, '3'); }}
                >
                    <strong>3. Alamat</strong>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '4'}
                  onClick={() => { this.toggle(0, '4'); }}
                >
                    <strong>4. Informasi Tambahan</strong>
                </NavLink>
              </NavItem>
                <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '5'}
                  onClick={() => { this.toggle(0, '5'); }}
                >
                    <strong>5. Upload Document</strong>
                </NavLink>
              </NavItem>
               <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '8'}
                  onClick={() => { this.toggle(0, '8'); }}
                >

                   <strong>6. Review</strong>
                </NavLink>
              </NavItem>
               <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '6'}
                  onClick={() => { this.toggle(0, '6'); }}
                >
                    <strong>7. Bank Pilihan</strong>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '7'}
                  onClick={() => { this.toggle(0, '7'); }}
                >
                    <strong>8. Bank Terpilih</strong>
                </NavLink>
              </NavItem>

              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '9'}
                  onClick={() => { this.toggle(0, '9'); }}
                >

                   <strong>9. Surat Keterangan</strong>
                </NavLink>
              </NavItem>
               <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '10'}
                  onClick={() => { this.toggle(0, '10'); }}
                >
                    <strong>10. PDF CPA </strong>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '11'}
                  onClick={() => { this.toggle(0, '11'); }}
                >
                    <strong>11. Email to BO</strong>
                </NavLink>
              </NavItem>
           

            
         
            </Nav>

            <TabContent activeTab={this.state.activeTab[0]}>
              {this.tabPane()}
            </TabContent>
             
          </Col>
        </Col>
      </div>
    );
  }
}

export default Collapses;
