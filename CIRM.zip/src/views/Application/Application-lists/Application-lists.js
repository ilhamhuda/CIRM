import React, { Component } from 'react';
import { Badge,Alert, TabPane,Nav,NavItem,NavLink,TabContent, Button, Card, FormGroup, InputGroup, InputGroupAddon, Input, CardBody, CardFooter, CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
import NumberFormat from 'react-number-format';
class Collapses extends Component {

  constructor(props) {
    super(props);
    this.onEntering = this.onEntering.bind(this);
    this.onEntered = this.onEntered.bind(this);
    this.onExiting = this.onExiting.bind(this);
    this.onExited = this.onExited.bind(this);
    this.toggle = this.toggle.bind(this);
   this.state = {
      collapse: false,
      accordion: [true, false, false],
      custom: [true, false],
      status: 'Closed',
      fadeIn: true,
      timeout: 300,
      activeTab: new Array(4).fill('1'),
      contact:[],
      id_user:null,
      access:[],
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm/'
    };
  }

  componentWillMount() {
    // global.userid = 1;
    this.state.id_user = localStorage.getItem("userId");
    const urlmy = `${this.state.API_URL}application/lists_by_la/`+this.state.id_user+`?source=my`;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ contact: data })
      console.log('data API : ',this.state.contact)
     })
     
     const urlac = `${this.state.API_URL}application/lists_by_la/`+this.state.id_user+`?source=other`;
     axios.get(urlac, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ access: data })
      console.log('data API : ',this.state.access)
     })
  }
  

  onEntering() {
    this.setState({ status: 'Opening...' });
  }

  onEntered() {
    this.setState({ status: 'Opened' });
  }

  onExiting() {
    this.setState({ status: 'Closing...' });
  }

  onExited() {
    this.setState({ status: 'Closed' });
  }

  submit(id) {
    console.log('data profile adalah :', id)
  localStorage.setItem("loanId", id);
  this.props.history.push({
    pathname: '/application-detail',
    id: id,
  })
  }
  access(listing) {
    return (
     
      <Row key={listing.id}>
       
        <Col>
        <Card>
              <CardHeader>
                <Row style={{marginRight:5}}>
                
                <Col  >
                <strong>{listing.contact}</strong>
                <br></br>
                <small>Loan Step : {listing.loan_step}</small>
                <br></br>
                 <small>Property Price : </small>
                <NumberFormat value={listing.property_price} displayType={'text'} thousandSeparator={true} prefix={'Rp.'} />
                  <small>,-</small>
               
                 <br></br>
                 <small>Loan Amount : </small>
                 <NumberFormat value={listing.loan_amount} displayType={'text'} thousandSeparator={true} prefix={'Rp.'} />
                <small>,-</small>
                 <br></br>
                 <small>Tenor : {listing.tenor} Tahun</small>
                 </Col>
                <div className="card-header-actions">
             
                      <Button onClick={() => this.submit(listing.id)} color="primary" className="px-1">View Detail</Button>
                        
                          </div>
                </Row>
              
              </CardHeader>
            
            </Card>
       
        </Col>
      </Row>
   
    )
   }
   
   my(listing) {
    return (
     
       <Row key={listing.id}>
       
        <Col>
        <Card>
              <CardHeader>
                <Row style={{marginRight:5}}>
                
                <Col  >
                <strong>{listing.contact}</strong>
                <br></br>
                <small>Loan Step : {listing.loan_step}</small>
                <br></br>
                 <small>Property Price : </small>
                <NumberFormat value={listing.property_price} displayType={'text'} thousandSeparator={true} prefix={'Rp.'} />
                  <small>,-</small>
               
                 <br></br>
                 <small>Loan Amount : </small>
                 <NumberFormat value={listing.loan_amount} displayType={'text'} thousandSeparator={true} prefix={'Rp.'} />
                <small>,-</small>
                 <br></br>
                 <small>Tenor : {listing.tenor} Tahun</small>
                 </Col>
                <div className="card-header-actions">
             
                      <Button onClick={() => this.submit(listing.id)} color="primary" className="px-1">View Detail</Button>
                        
                          </div>
                </Row>
              
              </CardHeader>
            
            </Card>
       
        </Col>
      </Row>
   
    )
   }

  
   toggle(tabPane, tab) {
    const newArray = this.state.activeTab.slice()
    newArray[tabPane] = tab
    this.setState({
      activeTab: newArray,
    });
  }

  tabPane() {
    return (
      <>
        <TabPane tabId="1">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
       
                       </div>
          {/* {this.my()} */}
          {this.state.contact.map((item)=>this.my(item))}
        </TabPane>
        <TabPane tabId="2">
        <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center"
        }}
      >
     
                       </div>
                       {this.state.access.map((item)=>this.access(item))}
        </TabPane>
       
      </>
    );
  }

  render() {
    return (
      <div className="animated fadeIn" style={{marginLeft:-30, marginRight:-30}}>
         <br></br>
         <Col >
          <Col xs="12" >
            
            <Card>
              <CardHeader>
   
                <strong>Loan</strong>
                <small> </small>
                <div className="card-header-actions">
                 <Link to="/application-add">
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 {/* <Button style={{color:'white', backgroundColor:'#35d44f',}} className="px-2"><i className="fa fa-plus-square"></i> Tambah</Button>
                    */}
                       </Link>
                </div>
              </CardHeader>
             </Card>
         </Col>
     
         
          <Col xl="12">
          <FormGroup row>
                    <Col md="12">
                      <InputGroup>
                     
                        <Input type="text" id="input1-group2" name="input1-group2" placeholder="" />
                        <InputGroupAddon addonType="prepend">
                          <Button type="button" color="primary"><i className="fa fa-search"></i> Search</Button>
                        </InputGroupAddon>
                      </InputGroup>
                    </Col>
                  </FormGroup>
         
          </Col>


     
         
          <Col xs="12" className="mb-4">
       
            <Nav tabs>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '1'}
                  onClick={() => { this.toggle(0, '1'); }}
                >
                  <strong>My Prospect</strong>
                </NavLink>
              </NavItem>
              <NavItem>
                <NavLink
                  active={this.state.activeTab[0] === '2'}
                  onClick={() => { this.toggle(0, '2'); }}
                >
                    <strong>Website</strong>
                </NavLink>
              </NavItem>

            
         
            </Nav>
            <TabContent activeTab={this.state.activeTab[0]}>
              {this.tabPane()}
            </TabContent>
          </Col>
        </Col>
      </div>
    );
  }
}

export default Collapses;
