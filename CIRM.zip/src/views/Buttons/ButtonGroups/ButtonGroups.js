import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import {
  Badge,
  Button,

  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';

class Forms extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300
    };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }

  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="6"></Col>
        <Row>
  
             

          <Col xs="12" md="6" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Profile</strong>
                <br></br>
            
                <small> </small>
         

              </CardHeader>
              <CardBody>
              <div style={{display: "flex",alignItems: 'center',justifyContent: 'center',}}>
                <img 
      src="https://loanmarket.co.id/img/advisor/2020/03/13/cdf55033f7fd45224d03502446e8d8d9.png"
      alt="Avatar"
      style={{borderRadius: '50%', borderWidth:2, borderColor:'grey',width:150, height:150, marginBottom:20}}
      />
          </div>
           
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                
                    <Col md="9">
                      <FormGroup >
                      <i className="fa fa-user"></i> 
                  &nbsp; <Label check className="form-check-label" htmlFor="radio1"><strong>Nama LA</strong></Label>
                   <br></br>
                   <small> Kiyoko Sari Sari</small>
                  
                      </FormGroup>
                      <FormGroup >
                      <i className="fa fa-bank"></i> 
                      &nbsp;<Label check className="form-check-label" htmlFor="radio2"><strong>Office</strong></Label>
                 <br></br>
                 <small> Loan Advisor Alam Sutra</small>
                     
                      </FormGroup>
                    
                    
                      <FormGroup >
                      <i className="fa fa-envelope"></i> 
                      &nbsp; <Label check className="form-check-label" htmlFor="radio3"><strong>Email</strong></Label>
                 <br></br>
                 <small> meikosari@loanmarket.co.id</small>
                   
                      </FormGroup>

                      <FormGroup >
                      <i className="fa fa-phone"></i> 
                      &nbsp; <Label check className="form-check-label" htmlFor="radio3"><strong>Phone</strong></Label>
                 <br></br>
                 <small> 08601777308</small>
                   
                      </FormGroup>
                     <FormGroup >
                      <i className="fa fa-user"></i> 
                      &nbsp; <Label check className="form-check-label" htmlFor="radio3"><strong>Jenis Kelamin</strong></Label>
                   <br></br>
                   <small> Perempuan</small>
                      </FormGroup>
                     
                     
                     

                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
       
              </CardBody>
              <CardFooter>
              <Link to='/edit-profile'>
                <Button   color="primary" aria-pressed="true">Edit Profile</Button>
                </Link>
              </CardFooter>
            </Card>
          </Col>



         
        </Row>
      </div>
    );
  }
}

export default Forms;
