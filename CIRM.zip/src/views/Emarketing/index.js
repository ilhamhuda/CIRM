import Emarketingdetail from './Emarketing-detail';
import Emarketinglist from './Emarketing-list';

export {
  Emarketingdetail, Emarketinglist,
};