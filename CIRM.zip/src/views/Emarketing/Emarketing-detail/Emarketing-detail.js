import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import {
  Badge,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';

class Forms extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.toggleFade = this.toggleFade.bind(this);
    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300
    };
  }

  toggle() {
    this.setState({ collapse: !this.state.collapse });
  }

  toggleFade() {
    this.setState((prevState) => { return { fadeIn: !prevState }});
  }

  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="6"></Col>
        <Row>
          <Col xs="12" sm="6">
            <Card>
              <CardHeader>
                <strong>E-Marketing</strong>
                <small> </small>
              </CardHeader>
              <CardBody>
              <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Kategori</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                    <Row>
                  <Col xs="12">
                  <FormGroup row>
               
                    <Col md="9">
                      <FormGroup check className="radio">
                        <Input className="form-check-input" type="radio" id="radio1" name="radios" value="option1" />
                        <Label check className="form-check-label" htmlFor="radio1"><strong>Not Contacted</strong></Label>
                      </FormGroup>
              
                      <FormGroup check className="radio">
                        <Input className="form-check-input" type="radio" id="radio2" name="radios" value="option2" />
                        <Label check className="form-check-label" htmlFor="radio2"><strong>Debitor</strong></Label>
                      </FormGroup>
                 
                      <FormGroup check className="radio">
                        <Input className="form-check-input" type="radio" id="radio3" name="radios" value="option3" />
                        <Label check className="form-check-label" htmlFor="radio3"><strong>Hot Leads</strong></Label>
                      </FormGroup>
               
              
                      <FormGroup check className="radio">
                        <Input className="form-check-input" type="radio" id="radio3" name="radios" value="option3" />
                        <Label check className="form-check-label" htmlFor="radio3"><strong>In CPA Process</strong></Label>
                      </FormGroup>
                     
                      <FormGroup check className="radio">
                        <Input className="form-check-input" type="radio" id="radio3" name="radios" value="option3" />
                        <Label check className="form-check-label" htmlFor="radio3"><strong>Just Improved</strong></Label>
                      </FormGroup>
                  
                      <FormGroup check className="radio">
                        <Input className="form-check-input"  type="radio" id="radio3" name="radios" value="option3" />
                        <Label check className="form-check-label" htmlFor="radio3"><strong>Not Connected</strong></Label>
                      </FormGroup>
               

                    </Col>
                  </FormGroup>
                  </Col>
                </Row>     </Col>
                  </FormGroup>
                  </Col>
                </Row>
              <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Subject</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input type="text" id="text-input" name="text-input" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
               
                
             
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                    <Col md="3">
               
                      <strong>Pesan</strong>
                  
                    </Col>
                    <Col xs="12" md="9">
                      <Input type="textarea" name="textarea-input" id="textarea-input" rows="9" placeholder="" />
                         </Col>
                  </FormGroup>
                  </Col>
                </Row>
              
       
        
               
              </CardBody>
              <CardFooter>
                <Button size="sm" color="primary"> <strong>Submit</strong></Button>
                <Button size="sm" color="transparant"> <strong></strong></Button>
              </CardFooter>
            </Card>
          </Col>

      
      
        </Row>
      </div>
    );
  }
}

export default Forms;
