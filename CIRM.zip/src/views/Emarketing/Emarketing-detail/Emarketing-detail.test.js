import React from 'react';
import ReactDOM from 'react-dom';
import Emarketingdetail from './Emarketing-detail';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Emarketingdetail />, div);
  ReactDOM.unmountComponentAtNode(div);
});
