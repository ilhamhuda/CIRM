import React, { Component,  lazy, Suspense } from 'react';
import { Bar, Line } from 'react-chartjs-2';
import { Link } from 'react-router-dom';
import {
  Badge,
  Button,
  Label,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  CardTitle,
  Col,
  Dropdown,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Progress,
  Row,
  Table,
} from 'reactstrap';
import { CustomTooltips } from '@coreui/coreui-plugin-chartjs-custom-tooltips';
import { getStyle, hexToRgba } from '@coreui/coreui/dist/js/coreui-utilities'
import NumberFormat from 'react-number-format';
import axios from 'axios';
class Dashboard extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.onRadioBtnClick = this.onRadioBtnClick.bind(this);

    this.state = {
      dropdownOpen: false,
      radioSelected: 2,
      userId: 1,
      user:'admin',
      contact:[],
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm/'
    };
  }

  toggle() {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen,
    });
  }
  submit(id) {
    console.log('data profile adalah :', id)
  localStorage.setItem("loanId", id);
  this.props.history.push({
    pathname: '/application-detail',
    id: id,
  })
  }
  componentWillMount() {
    global.userid = 1
    localStorage.setItem("userId", this.state.userId);

    const urlmy = `${this.state.API_URL}application/lists_by_la/`+global.userid+`?source=my`;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ contact: data })
      console.log('data API : ',this.state.contact)
     })


    }

  onRadioBtnClick(radioSelected) {
    this.setState({
      radioSelected: radioSelected,
    });
  }

  my(listing) {
    return (
     
       <Row key={listing.id}>
       
        <Col>
        <Card>
              <CardHeader>
                <Row style={{marginRight:5}}>
                
                <Col  >
                <strong>{listing.contact}</strong>
                <br></br>
                <small>Loan Step : {listing.loan_step}</small>
                <br></br>
                 <small>Property Price : </small>
                <NumberFormat value={listing.property_price} displayType={'text'} thousandSeparator={true} prefix={'Rp.'} />
                  <small>,-</small>
               
                 <br></br>
                 <small>Loan Amount : </small>
                 <NumberFormat value={listing.loan_amount} displayType={'text'} thousandSeparator={true} prefix={'Rp.'} />
                <small>,-</small>
                 <br></br>
                 <small>Tenor : {listing.tenor} Tahun</small>
                 </Col>
                <div className="card-header-actions">
             
                      <Button onClick={() => this.submit(listing.id)} color="primary" className="px-1">View Detail</Button>
                        
                          </div>
                </Row>
              
              </CardHeader>
            
            </Card>
       
        </Col>
      </Row>
   
    )
   }

  loading = () => <div className="animated fadeIn pt-1 text-center">Loading...</div>

  render() {

    return (
      <div style={{backgroundColor:'white'}} className="animated fadeIn">
        <br></br>
            <Row >
              <Col xs="12" md="6" className="mb-4">
                <Card className="text-white bg-info">
                  <CardBody className="pb-0">
              
                    <div>Welcome Back,</div>
                    <div className="text-value">Kiyoko Tri Safitri</div>
                    <div>Loan Market Alam Sutera</div>
                    <br></br>
               <Link to='/profile'>
                <Button active block style={{width:70}} color="primary" aria-pressed="true">Profile</Button>
                </Link>
               
                <br></br>
                  </CardBody>
                
                </Card>
              </Col>

            </Row>
            <Row>
            

            </Row>
            <br></br>
            <Col>
            <Row  >
              

           

            <Link to="/contact">
              <div
                style={{
                  display: "flex",
                  flexDirection:"column",
                  alignItems:'center',
                  justifyContent:'center',
                  margin:10,
                }}
              >
                <Button  style={{width:70,height:70}} color="primary" aria-pressed="true">
                  <i className="icon-notebook"></i> 
                </Button>
            
                <Label style={{fontWeight:'bold'}}>Contact</Label>
              </div>
            </Link> 

            <Link to="/application-lists">
                <div
                  style={{
                  display: "flex",
                  flexDirection:"column",
                  alignItems:'center',
                  justifyContent:'center',
                  margin:10,
                  }}
                >
                  <Button  style={{width:70,height:70}} color="primary" aria-pressed="true">
                  <i className="icon-doc"></i> 
                  </Button>
                  <Label style={{fontWeight:'bold'}}>Loan</Label>
              </div>
            </Link> 

            <Link to="/product-bank">
              <div
                style={{
                  display: "flex",
                  flexDirection:"column",
                  alignItems:'center',
                  justifyContent:'center',
                  margin:10,
                }}
              >
                <Button  style={{width:70,height:70}} color="primary" aria-pressed="true">
                  <i className="icon-briefcase"></i>
                </Button>
                <Label style={{fontWeight:'bold'}}>Product</Label>
          
              </div>
          </Link>    
                              
          <Link to="/daftar-bank">
            <div
              style={{
                display: "flex",
                flexDirection:"column",
                alignItems:'center',
                justifyContent:'center',
                margin:10,
              }}
            >
              <Button  style={{width:70,height:70}} color="primary" aria-pressed="true">
                <i className="icon-home"></i>
              </Button>
              <Label style={{fontWeight:'bold'}}>Daftar Bank</Label>
            </div>
          </Link>     

          <Link to="/emarketing-list">
            <div
              style={{
              display: "flex",
              flexDirection:"column",
              alignItems:'center',
              justifyContent:'center',
              margin:10,
              }}
          >
              <Button  style={{width:70,height:70}} color="primary" aria-pressed="true">
                <i className="icon-envelope"></i> 
              </Button>
              <Label style={{fontWeight:'bold'}}>E - Marketing</Label>
            </div>
          </Link>                  
        </Row>
        </Col>
      <Row>
       
         &nbsp;
         &nbsp;
        

         <Col xl="6">
         <br></br>
         <h4><strong>Daftar Pengajuan Loan</strong></h4>
     
         <br></br>
         {this.state.contact.map((item)=>this.my(item))}
         </Col>
       </Row>
     
      
     </div>
    );
  }
}

export default Dashboard;

