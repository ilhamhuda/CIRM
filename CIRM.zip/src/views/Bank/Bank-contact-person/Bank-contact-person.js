import React, { Component } from 'react';
import { Link } from 'react-router-dom';

import {
  Badge,
  Button,

  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Col,
  Collapse,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Fade,
  Form,
  FormGroup,
  FormText,
  FormFeedback,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupButtonDropdown,
  InputGroupText,
  Label,
  Row,
} from 'reactstrap';
import axios from 'axios';
class App extends Component {

  constructor(props) {
    super(props);

    this.state = {
      contact:[],
      id_user:1,
      id:[],
      idcabang: null,
      listing : [],
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm/'
    };
  }

 componentWillMount() {
    const { id } = this.props.location
  

     const urlmy = `${this.state.API_URL}bank/cp_by_branch/` + id;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listing: data, idcabang : id})
     })
  }

  render() {
    return (
      <div className="animated fadeIn">
         <Button size="sm" color="transparant"> <strong></strong></Button>
               
        <Col xs="12" sm="6"></Col>
        <Row>
  
             

          <Col xs="12" md="6" className="mb-4">
            <Card>
              <CardHeader>
                <strong>Contact Person</strong>
                <br></br>
            
                <small> </small>
         

              </CardHeader>
              <CardBody>
         
           
                <Row>
                  <Col xs="12">
                  <FormGroup row>
                
                    <Col md="9">
                      <FormGroup >
             
                 <Label check className="form-check-label" htmlFor="radio1"><strong>Nama Officer</strong></Label>
                   <br></br>
                   <small>{this.state.listing.name}</small>
                  
                      </FormGroup>
                       <FormGroup >
             
                   <Label check className="form-check-label" htmlFor="radio2"><strong>Position</strong></Label>
                 <br></br>
                 <small>{this.state.listing.Position}</small>
                     
                      </FormGroup>

                      <FormGroup >
                 
                   <Label check className="form-check-label" htmlFor="radio2"><strong>Branch</strong></Label>
                 <br></br>
                 <small>{this.state.listing.branch}</small>
                     
                      </FormGroup>
                    
                    
                     <FormGroup >
                   
                    <Label check className="form-check-label" htmlFor="radio3"><strong>Jenis Kelamin</strong></Label>
                   <br></br>
                   <small> {this.state.listing.gender}</small>
                      </FormGroup>


                      <FormGroup >
               <Label check className="form-check-label" htmlFor="radio3"><strong>Email</strong></Label>
                 <br></br>
                 <small>{this.state.listing.email}</small>
                   
                      </FormGroup>


                      <FormGroup >
                    
                     <Label check className="form-check-label" htmlFor="radio3"><strong>Phone</strong></Label>
                 <br></br>
                 <small>{this.state.listing.phone}</small>
                   
                      </FormGroup>


                     
                     
                     

                    </Col>
                  </FormGroup>
                  </Col>
                </Row>
       
              </CardBody>
            
            </Card>
          </Col>



         
        </Row>
      </div>
    );
  }
}

export default App;
