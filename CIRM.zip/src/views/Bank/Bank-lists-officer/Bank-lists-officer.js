import React, { Component } from 'react';
import { Badge, Button, Card, CardBody, CardFooter, CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
class App extends Component {

  constructor(props) {
    super(props);

    this.state = {
      contact:[],
      id_user:1,
      id:[],
      idcabang: null,
      listing : [],
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm/'
    };
  }


   listing(listing) {
      return(
       
          <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>
          
      
                <Col  >
               <strong>{listing.name}</strong>
                <br></br>
                 <small>{listing.branch}</small>

                 </Col>
                <div className="card-header-actions">
          
                      <Button onClick={() => this.detail(listing.id)}  color="primary" className="px-1">View Detail</Button>
                          </div>
                </Row>
              
              </CardHeader>
            
            </Card>
  
           )
    }

 componentWillMount() {
    const { id } = this.props.location
  

     const urlmy = `${this.state.API_URL}/bank/officer_by_branch/`+ id;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listing: data, idcabang : id})
     })
  }

  detail(id) {
    console.log('data profile adalah :', id)
  
  this.props.history.push({
    pathname: '/bank-officer-detail',
    id: id,
  })
  }



  render() {
    return (
      <div className="animated fadeIn">
         <br></br>
         <Row>
          <Col xs="12" sm="6">
            <Card>
              <CardHeader>
                <strong>Bank Officer Cabang </strong>
                <small> </small>
                {/* <div className="card-header-actions">
                  <Badge style={{color:'white', backgroundColor:'#03a840',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge>
                </div> */}
              </CardHeader>
             </Card>
         </Col>
         </Row>

        <Row>
         
          <Col xl="6">
           
          {this.state.listing.map((item)=>this.listing(item))}
        
          </Col>
        </Row>
      </div>
    );
  }
}

export default App;
