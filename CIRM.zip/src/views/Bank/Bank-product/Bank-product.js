import React, { Component } from 'react';
import { Badge, Button, Card, CardBody, CardFooter, InputGroup,Input,FormGroup, InputGroupAddon,CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
class App extends Component {

  constructor(props) {
    super(props);
    
    this.state = {
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      title: '',
      listing: [],
      Detail: '',
    };
  }

   componentWillMount() {
    const { id } = this.props.location
  

     const urlmy = `${this.state.API_URL}/bank/product_by_bank/`+ id;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listing: data })
     })
  }

  detail(id) {
    console.log('data profile adalah :', id)
  
  this.props.history.push({
    pathname: '/bank-product-detail',
    id: id,
  })
  }



   listing(listing) {
      return(
       
             <Card>
             <CardHeader>
               <Row style={{marginRight:10}}>
               
               <Col  >
              <strong>{listing.title}</strong>
               <br></br>
              <small></small>

                </Col>
               <div className="card-header-actions">
             
                     <Button onClick={() => this.detail ()} color="primary" className="px-1">View Detail</Button>
                   </div>
               </Row>
             
             </CardHeader>
             <CardBody>
            
<div>{ ReactHtmlParser(listing.description) }</div>
             </CardBody>
            
           
           </Card>
  
           )
    }


  render() {
    return (
      <div className="animated fadeIn">
         <br></br>
         <Row>
     
          <Col xs="12" sm="6">
        
            <Card>
              <CardHeader>
                <strong>Bank Product</strong>
                <small> </small>
              
              </CardHeader>
             </Card>
         </Col>
         </Row>

        <Row>
         
          <Col xl="6">
      
             
          {this.state.listing.map((item)=>this.listing(item))}
    
           
          </Col>
        </Row>
      </div>
    );
  }
}

export default App;
