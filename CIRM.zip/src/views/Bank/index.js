import Bankofficerdetail from './Bank-officer-detail';
import Emarketinglist from './Emarketing-list';

export {
  Bankofficerdetail, Emarketinglist,
};