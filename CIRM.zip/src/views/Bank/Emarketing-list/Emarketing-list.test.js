import React from 'react';
import ReactDOM from 'react-dom';
import Emarketinglist from './Emarketing-list';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(<Emarketinglist />, div);
  ReactDOM.unmountComponentAtNode(div);
});
