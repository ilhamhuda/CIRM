import React, { Component } from 'react';
import { Badge, FormGroup,Label,Input, Button, Card, CardBody, CardFooter, CardHeader, Col, Collapse, Fade, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
import axios from 'axios';
class Collapses extends Component {

   constructor(props) {
    super(props);
    
    this.state = {
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      title: '',
      listing: [],
      Detail: '',
    };
  }

   componentWillMount() {
    const { id } = this.props.location
  

     const urlmy = `${this.state.API_URL}/bank/lists/`;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listing: data })
     })
  }
   submit(id) {
    console.log('data profile adalah :', id)
   localStorage.setItem("bankId", id);
  this.props.history.push({
    pathname: '/bank-detail',
    id: id,
  })
  }
   listing(listing) {
      return(
       
           <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>            
                  <img 
                      src={'https://' + listing.image}
                      alt="Avatar"
                      style={{borderRadius: '50%',backgroundColor:'white', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                    marginLeft:10}}
                      />
      
                <Col  >
                  <div style={{marginLeft:5,marginTop:15}}>
                    <strong>{listing.name}</strong>
                  </div>
                </Col>
                  <div className="card-header-actions">
                 
                      <Button  onClick={() => this.submit(listing.id)}  color="primary" className="px-1">View Detail</Button>
           
                  </div>
               </Row>
              </CardHeader>
            </Card>
           
  
           )
    }

  render() {
    return (
      <div className="animated fadeIn">
         <br></br>
         <Row>
          <Col xs="12" >
            <Card>
              <CardHeader>
                <strong> Daftar Bank</strong>
                <small> </small>
                {/* <div className="card-header-actions">
                  <Badge style={{color:'white', backgroundColor:'#03a840',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge>
                </div> */}
              </CardHeader>
             </Card>
         </Col>
         </Row>

        <Row>
         
          <Col xl="6">
           
           {this.state.listing.map((item)=>this.listing(item))}

         
           
          </Col>
        </Row>
      </div>
    );
  }
}

export default Collapses;
