import React, { Component, PropTypes } from 'react'
import {Badge,Card, ButtonDropdown,
  ButtonGroup,
  ButtonToolbar,Dropdown,
  DropdownItem,
  DropdownMenu,CardHeader,
  DropdownToggle,Modal, ModalBody, ModalFooter, ModalHeader,CardBody,FormGroup, Col, Button,Nav,InputGroup,InputGroupAddon,Input, NavItem, NavLink, Row, TabContent, TabPane} from 'reactstrap';
import classnames from 'classnames';
import { Link } from 'react-router-dom';
import axios from 'axios';
import Search from 'react-search'
import ReactDOM from 'react-dom'
class Tabs extends Component {


   HiItems(items) {

    this.setState({ listingBranch: [], })
   console.log('inisiasi data BO', items)

const urlmy = `${this.state.API_URL}/bank/branch_by_location/`+ this.state.idBank + `?location` + items;
     // https://loanmarket.co.id/api/crm/bank/branch_by_location/10?location=KOTA
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      if(data != undefined){
      this.setState({ listingBranch: data, })
     
      }
     })
          
  }

  getItemsAsync(searchValue, cb) {
   
    const urlmy = `${this.state.API_URL}/lookup/loc_sugg/` + searchValue;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {

      let items = data.map( (res, i) => { return { id: i, value: res.label } })
      this.setState({ listing: items })

      cb(searchValue)

     });
  }


   constructor(props) {
    super(props);
    
    this.state = {
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      title: '',
      listing: [],
      listingBranch: [],
      idwil: null,
      detail: [],
      idBank: null,
      modalBO:false,
      listingBO : [],
      idBO  : null,
       modalCP:false,
      listingCP : [],
      idCP  : null,
    };
  this.toggleBO  = this.toggleBO.bind(this);
  }
  toggleBO(id) {
      const urlmy = `${this.state.API_URL}/bank/officer_by_branch/`+ id;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listingBO: data, idBO : id, modalBO: !this.state.modalBO  })
     })
  }



  toggleClose() {
       this.setState({
      modalBO: false
    });
  }

  toggleCP(id) {
      const urlmy = `${this.state.API_URL}/bank/cp_by_branch/`+ id;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ listingCP: data[0], idCP : id, modalCP: !this.state.modalBO  })
     })
  }


  toggleCloseCP() {
       this.setState({
      modalCP: false
    });
  }
   componentWillMount() {
   this.state.idBank   = localStorage.getItem("bankId");
   
     const urlmy = `${this.state.API_URL}/bank/detail/` + this.state.idBank ;
    axios.get(urlmy, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ detail: data })
     })
  }


  
   listingBO(listing) {
      return(
       
          <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>
        
                <Col  >
               <strong>{listing.name}</strong>
            
                     <br></br>
                 <small>{listing.position}</small>
    <br></br>
                 <small>{listing.email}</small>
                   <br></br>
                 <small>{listing.phone}</small>

                 </Col>
               
                </Row>
              
              </CardHeader>
            
            </Card>
  
           )
    }


  

listingBranch(listing) {
return (
  <Card>
              <CardHeader>
                <Row style={{marginRight:5}}>
                
                <Col  >
               <strong>{listing.name}</strong>
                <br></br>
                 <small>{listing.address}</small>
                 <br></br>
                 <small>{listing.phone}</small>
                 <br></br>
                 <div className="card-header-actions">
        
                      <Button  onClick={() => this.toggleCP(listing.id)} color="primary" style ={{marginRight:10}} className="px-1">Contact Person</Button>
                      


                      <Button onClick={() => this.toggleBO(listing.id)} color="primary" className="px-1">Bank Officer Lists</Button>
                
                         </div>
                 </Col>
            
                </Row>
              
              </CardHeader>
            
            </Card>
  )
}
    




   submit(id) {
 
  
  this.props.history.push({
    pathname: '/bank-detail',
    id: id,
  })
  }

  bankProduct(id) {

  
  this.props.history.push({
    pathname: '/bank-product',
    id: this.state.idBank,
  })
  }

  
   contactPerson(id) {
 
  
  this.props.history.push({
    pathname: '/bank-contact-person',
    id: this.state.idBank,
  })
  }

   bankOfficer(id) {

  
  this.props.history.push({
    pathname: '/member-bank',
    id: this.state.idBank,
  })
  }

  
  render() {
    let items = [
      { id: 0, value: 'ruby' },
      { id: 1, value: 'javascript' },
      { id: 2, value: 'lua' },
      { id: 3, value: 'go' },
      { id: 4, value: 'julia' }
    ]
    return (
      <div className="animated fadeIn">

       <Modal isOpen={this.state.modalCP} toggle={this.toggleCP}
                     >
                  <ModalHeader toggle={this.toggleBO}>Detail Contact Person</ModalHeader>
                  <ModalBody>
                     <Card>
              <CardHeader>
                <Row style={{marginRight:10}}>
          
      
                <Col  >
               <strong>{this.state.listingCP.name}</strong>
            
                     <br></br>
                 <small>{this.state.listingCP.position}</small>
    <br></br>
                 <small>{this.state.listingCP.email}</small>
                   <br></br>
                 <small>{this.state.listingCP.phone}</small>

                 </Col>
               
                </Row>
              
              </CardHeader>
            
            </Card>
                  </ModalBody>
                  <ModalFooter>
                   
                    <Button color="secondary"  onClick={() => this.toggleCloseCP()}>Close</Button>
                  </ModalFooter>
                </Modal>  



 <Modal isOpen={this.state.modalBO} toggle={this.toggleBO}
                     >
                  <ModalHeader toggle={this.toggleBO}>Lists Bank Officer</ModalHeader>
                  <ModalBody>
                    {this.state.listingBO.map((item)=>this.listingBO(item))}
                  </ModalBody>
                  <ModalFooter>
                   
                    <Button color="secondary"  onClick={() => this.toggleClose()}>Close</Button>
                  </ModalFooter>
                </Modal>  
        <br></br>
        <Row>
          <Col xs="12" >
                


            <Card>
              <CardHeader>
                <strong>Detail Bank</strong>
                <small> </small>
                <div className="card-header-actions">
        
                 {/* <Badge style={{color:'white', backgroundColor:'#35d44f',height:25,padding:5}}>  <i className="fa fa-plus-square"></i> Tambah</Badge> */}
                 <Button  onClick={() => this.bankProduct()}  color="primary" style={{color:'white',}} className="px-2"><i className="fa fa-bank"></i> Product</Button>
                   
             
                </div>
              </CardHeader>
             </Card>
         </Col>
         </Row>
        <Row>
        <Col xs="12"  className="mb-4">
            <Card className="text-white bg-info">
              <CardBody className="pb-0">
                <ButtonGroup className="float-right">
                <Button active block style={{width:10}} color="transparant" aria-pressed="true"></Button>
               <Link to="/product-bank">
                    </Link>   
           
                </ButtonGroup>
                <Row>
                <img 
                      src={'https://' + this.state.detail.image}
                      alt="Avatar"
                      style={{borderRadius: '50%',backgroundColor:'white', 
                      borderWidth:2, 
                      borderColor:'grey',
                      width:50, 
                      height:50,
                      margin:5,
                  }}
                      />
                <strong style={{marginTop:10,marginLeft:10,}} className="text-value">{this.state.detail.name}</strong>
       

                </Row>
                          {/* <i className="fa fa-phone"></i> &nbsp;<small> +62212511946</small>
                <br></br>
                 <i className="fa fa-tv"></i> &nbsp;<small>http://www.mandiri.co.id</small>
                 <br></br>
                 <i className="fa fa-university"></i>&nbsp; <small > Jl. Jendral Sudirman no.kav1 RT1/RW3,Jakarta Pusat</small>
               
          
          */}
         
         
           

           <Row>
    
           &emsp;
          
           
           </Row>
         
       
              </CardBody>
            
            </Card>
          </Col>
        
        
          </Row>
         
      <Card>
      <CardHeader>
        <Col xs="12">
          <FormGroup row>
                    <Col md="12" >
                  
                  <Search items={this.state.listing}

                    multiple={false}
                    placeholder='Cari Cabang'
                    getItemsAsync={this.getItemsAsync.bind(this)}
                    onItemsChanged={this.HiItems.bind(this)}
                    

                     />

                    </Col>
                  </FormGroup>
         
          </Col>
           </CardHeader>
            <CardBody>
        <Col xs="12">

     
     {this.state.listingBranch.map((item)=>this.listingBranch(item))}


          </Col>
           </CardBody>
          </Card>
      </div>
    );
  }
}

export default Tabs;
