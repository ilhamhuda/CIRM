import React, { Component } from 'react';
import { Badge,FormGroup,Input,Label, Button, Card, CardBody, CardFooter, CardHeader, Col, Row } from 'reactstrap';
import { Link } from 'react-router-dom';
import ReactHtmlParser, { processNodes, convertNodeToElement, htmlparser2 } from 'react-html-parser';
import axios from 'axios';

class App extends Component {
   constructor(props) {
    super(props);


    this.state = {
      collapse: true,
      fadeIn: true,
      timeout: 300,
      user:'admin',
      pass: 'lo4nM4rk3t',
      API_URL: 'https://loanmarket.co.id/api/crm',
      title: '',
      listing: [],
      Detail: '',
    };
  }

  componentWillMount() {
    const { id } = this.props.location
    console.log('ini data kiriman : ', id)
    const url = `${this.state.API_URL}/bank/bank_product_detail/1` + id;
    axios.get(url, {auth: {
      username: this.state.user,
      password: this.state.pass
    }}).then(response => response.data.data)
    .then((data) => {
      this.setState({ Detail: data })
      console.log('data API : ',this.state.Detail)
     })

 
  }

   submit(id) {
    console.log('data profile adalah :', id)
  
  this.props.history.push({
    pathname: '/product-bank',
    id: id,
    id_user: id 
  })
  }

    listing(listing) {
      return(
       
            <Card  key={listing.id}>
             <CardHeader>
               <Row style={{marginRight:10}}>
               
               <Col  >
              <strong>{listing.name}</strong>
               <br></br>
              <small></small>

                </Col>
               <div className="card-header-actions">
             
                     <Button  onClick={() => this.submit(listing.id)}  color="primary" className="px-1">View Detail</Button>
                     </div>
               </Row>
             
             </CardHeader>
           
           </Card>
  
           )
    }

  render() {
    return (
      <div className="animated fadeIn">
        <br></br>
        <Row>
          <Col xs="12" md="6">

       
        

<Card  >
             <CardHeader>
               <Row style={{marginRight:10}}>
               
               <Col  >
              <h3>{this.state.Detail.product}</h3>
           

                </Col>
            
               </Row>
             
             </CardHeader>
             <CardBody>

             <h6>1. Jaminan</h6>
        <p>&nbsp;&nbsp;&nbsp;{this.state.Detail.guarantee}</p>

            <h6>2. Target Market </h6>
          <p>&nbsp;&nbsp;&nbsp;{this.state.Detail.target_market} </p>

                 <h6>3. Komisi</h6>
          <p>&nbsp;&nbsp;&nbsp; {this.state.Detail.komisi}</p>

               <h6>4.  Appraisal </h6>
          <p>&nbsp;&nbsp;&nbsp;{this.state.Detail.appraisal}</p>

                 <h6>5. Floating</h6>
          <p>&nbsp;&nbsp;&nbsp; {this.state.Detail.floating} </p>

                 <h6>6. Loan To Value</h6>
          <p>&nbsp;&nbsp;&nbsp; {this.state.Detail.loan_to_value} </p>


                 <h6>7. Penalty Fee </h6>
          <p>&nbsp;&nbsp;&nbsp; {this.state.Detail.penalty_fee}</p>

                     <h6>8. Keterangan</h6>
          <p>&nbsp;&nbsp;&nbsp; {this.state.Detail.jaminan} </p>




               <h6> </h6>
          <span> </span>
             </CardBody>
           </Card>
<div></div>
          </Col>
         
        </Row>

        <Row>
         
         
       </Row>
      </div>
    );
  }
}

export default App;