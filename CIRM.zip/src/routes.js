import React from 'react';
const Emarketingdetail = React.lazy(() => import('./views/Emarketing/Emarketing-detail'));
const Emarketinglist = React.lazy(() => import('./views/Emarketing/Emarketing-list'));
const Bankofficerdetail = React.lazy(() => import('./views/Bank/Bank-officer-detail/Bank-officer-detail'));
const Bankofficerlists = React.lazy(() => import('./views/Bank/Bank-lists-officer/Bank-lists-officer'));
const Bankcontactperson  = React.lazy(() => import('./views/Bank/Bank-contact-person/Bank-contact-person'));
const Contactdetail = React.lazy(() => import('./views/Contact/Contact-detail/Contact-detail'));
const Contactlist = React.lazy(() => import('./views/Contact/Contact-list/Contact-list'));
const Contactadd = React.lazy(() => import('./views/Contact/Contact-add/Contact-add'));
const Contactedit= React.lazy(() => import('./views/Contact/Contact-edit/Contact-edit'));
const NoteDetail= React.lazy(() => import('./views/Contact/Note-detail/Note-detail'));
const NoteAdd= React.lazy(() => import('./views/Contact/Note-add/Note-add'))
const Accessadd= React.lazy(() => import('./views/Contact/Access-add/Access-add'))
const Accessdelete= React.lazy(() => import('./views/Contact/Access-delete/Access-delete'))
const Requirementadd= React.lazy(() => import('./views/Contact/Requirement-add/Requirement-add'))
const Requirementdetail= React.lazy(() => import('./views/Contact/Requirement-detail/Requirement-detail'));
const Productbank = React.lazy(() => import('./views/Product/Product-bank/Product-bank'))
const Productdetail = React.lazy(() => import('./views/Product/Product-detail/Product-detail'))
const Productlists = React.lazy(() => import('./views/Product/Product-lists/Product-lists'))
const Banklists = React.lazy(() => import('./views/Bank/Bank-lists/Bank-lists'))
const Bankdetail = React.lazy(() => import('./views/Bank/Bank-detail/Bank-detail'))
const Bankproduct = React.lazy(() => import('./views/Bank/Bank-product/Bank-product'))
const Bankproductdetail = React.lazy(() => import('./views/Bank/Bank-product-detail/Bank-product-detail'))
const Applicationadd = React.lazy(() => import('./views/Application/Application-add/Application-add'))
const Applicationdetail = React.lazy(() => import('./views/Application/Application-detail/Application-detail'))
const Applicationlists = React.lazy(() => import('./views/Application/Application-lists/Application-lists'))
const Applicationedit = React.lazy(() => import('./views/Application/Application-edit/Application-edit'))


const Loan = React.lazy(() => import('./views/Base/Loan'));
const Cards = React.lazy(() => import('./views/Base/Cards'));
const Carousels = React.lazy(() => import('./views/Base/Carousels'));
const Collapses = React.lazy(() => import('./views/Base/Collapses'));
const Dropdowns = React.lazy(() => import('./views/Base/Dropdowns'));
const Forms = React.lazy(() => import('./views/Base/Forms'));
const Jumbotrons = React.lazy(() => import('./views/Base/Jumbotrons'));
const ListGroups = React.lazy(() => import('./views/Base/ListGroups'));
const Navbars = React.lazy(() => import('./views/Base/Navbars'));
// const Navs = React.lazy(() => import('./views/Base/Navs'));
const Paginations = React.lazy(() => import('./views/Base/Paginations'));
const Popovers = React.lazy(() => import('./views/Base/Popovers'));
const ProgressBar = React.lazy(() => import('./views/Base/ProgressBar'));
const Switches = React.lazy(() => import('./views/Base/Switches'));
const Tables = React.lazy(() => import('./views/Base/Tables'));
const Tabs = React.lazy(() => import('./views/Base/Tabs'));
const Tooltips = React.lazy(() => import('./views/Base/Tooltips'));
const BrandButtons = React.lazy(() => import('./views/Buttons/BrandButtons'));
const ButtonDropdowns = React.lazy(() => import('./views/Buttons/ButtonDropdowns'));
const ButtonGroups = React.lazy(() => import('./views/Buttons/ButtonGroups'));
const Buttons = React.lazy(() => import('./views/Buttons/Buttons'));
const Charts = React.lazy(() => import('./views/Charts'));
const Marketing = React.lazy(() => import('./views/Marketing'));
const Dashboard = React.lazy(() => import('./views/Dashboard'));
const CoreUIIcons = React.lazy(() => import('./views/Icons/CoreUIIcons'));
const Flags = React.lazy(() => import('./views/Icons/Flags'));
const FontAwesome = React.lazy(() => import('./views/Icons/FontAwesome'));
const SimpleLineIcons = React.lazy(() => import('./views/Icons/SimpleLineIcons'));
const Alerts = React.lazy(() => import('./views/Notifications/Alerts'));
const Badges = React.lazy(() => import('./views/Notifications/Badges'));
const Modals = React.lazy(() => import('./views/Notifications/Modals'));
const Colors = React.lazy(() => import('./views/Theme/Colors'));
const Typography = React.lazy(() => import('./views/Theme/Typography'));
const Widgets = React.lazy(() => import('./views/Widgets/Widgets'));
const Users = React.lazy(() => import('./views/Users/Users'));
const User = React.lazy(() => import('./views/Users/User'));
const Detail_pinjaman = React.lazy(() => import('./views/Pages/Detail_pinjaman'));

// https://github.com/ReactTraining/react-router/tree/master/packages/react-router-config
const routes = [
  {path: '/emarketing-detail', name: 'Emarketing-detail', component: Emarketingdetail },
  {path: '/emarketing-list', name: 'Emarketing-list', component: Emarketinglist },
  {path: '/bank-officer-detail', name: 'Bank-officer-detail', component: Bankofficerdetail},
   {path: '/bank-contact-person', name: 'bank-contact-person', component: Bankcontactperson},
{path: '/application-add', name: 'application-add', component: Applicationadd},
{path: '/application-lists', name: 'application-lists', component: Applicationlists},
{path: '/application-detail', name: 'application-detail', component: Applicationdetail},
{path: '/application-edit', name: 'application-edit', component: Applicationedit},
  { path: '/contact-detail', name: 'Contactdetail', component: Contactdetail },
  { path: '/edit-contact', name: 'Contactedit', component: Contactedit },
  { path: '/add-contact', name: 'Contactadd', component: Contactadd },
  { path: '/contact', name: 'Contactlist', component: Contactlist },
  { path: '/', exact: true, name: 'Home' },
  { path: '/dashboard', name: 'Dashboard', component: Dashboard },
  { path: '/theme', exact: true, name: 'Theme', component: Colors },
  { path: '/add-akses', name: 'Accessadd', component: Accessadd },
  { path: '/product', name: 'product-lists', component: Productlists },
  { path: '/base', exact: true, name: 'Base', component: Cards },
  // { path: '/note', name: 'Cards', component: Cards },
  { path: '/note', name: 'Notedetail', component: NoteDetail },
  { path: '/requirement-detail', name: 'Requirementdetail', component: Requirementdetail },
  { path: '/requirement-add', name: 'Requirementadd', component: Requirementadd },
  { path: '/note-add', name: 'Noteadd', component: NoteAdd },
  { path: '/cpa-bank', name: 'Forms', component: Forms },
  { path: '/detail-pinjaman', name: 'Switches', component: Switches },
  // { path: '/add-contact', name: 'Tables', component: Tables },
  { path: '/upload-document', name: 'Tabs', component: Tabs },
  { path: '/Loan', name: 'Loan', component: Loan },
  { path: '/product-bank', name: 'product-bank', component: Productbank },
  { path: '/bank-product', name: 'bank-product', component: Bankproduct },
   { path: '/bank-product-detail', name: 'bank-product-detail ', component: Bankproductdetail },
  { path: '/daftar-pinjaman', name: 'Collapse', component: Collapses },
  { path: '/akses', name: 'Accessdelete', component: Accessdelete },
  // { path: '/contact', name: 'Jumbotrons', component: Jumbotrons },
  { path: '/daftar-bank', name: 'banklists', component: Banklists },
  { path: '/cpa-bank-result', name: 'Navbars', component: Navbars },
  // { path: '/contact-detail', name: 'Navs', component: Navs },
  { path: '/member-bank', name: 'bank-officer-lists', component: Bankofficerlists },
  { path: '/detail-pekerjaan', name: 'Popovers', component: Popovers },
  // { path: '/edit-contact', name: 'Progress Bar', component: ProgressBar },
  { path: '/informasi-tambahan', name: 'Tooltips', component: Tooltips },
  { path: '/buttons', exact: true, name: 'Buttons', component: Buttons },
  { path: '/buttons/buttons', name: 'Buttons', component: Buttons },
  { path: '/edit-profile', name: 'Button Dropdowns', component: ButtonDropdowns },
  { path: '/profile', name: 'Button Groups', component: ButtonGroups },
  { path: '/buttons/brand-buttons', name: 'Brand Buttons', component: BrandButtons },
  { path: '/icons', exact: true, name: 'Icons', component: CoreUIIcons },
  { path: '/icons/coreui-icons', name: 'CoreUI Icons', component: CoreUIIcons },
  { path: '/icons/flags', name: 'Flags', component: Flags },
  { path: '/icons/font-awesome', name: 'Font Awesome', component: FontAwesome },
  { path: '/icons/simple-line-icons', name: 'Simple Line Icons', component: SimpleLineIcons },
  { path: '/notifications', exact: true, name: 'Notifications', component: Alerts },
  { path: '/bank-detail', name: 'Bankdetail', component: Bankdetail },
  { path: '/product-detail', name: 'product-detail', component: Productdetail },
  { path: '/detail_pinjaman', name: 'Detail Pinjaman', component: Detail_pinjaman },
  { path: '/notifications/modals', name: 'Modals', component: Modals },
  
  { path: '/bank-officer-detail', name: 'Widgets', component: Widgets },
  { path: '/daftar-cabang', name: 'Charts', component: Charts },
  { path: '/marketing', name: 'marketing', component: Marketing },
  { path: '/users', exact: true,  name: 'Users', component: Users },
  { path: '/users/:id', exact: true, name: 'User Details', component: User },
];

export default routes;
