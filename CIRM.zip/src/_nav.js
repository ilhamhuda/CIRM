export default {
  items: [
    {
      name: 'Home',
      url: '/dashboard',
      icon: 'icon-home',
      // badge: {
      //   variant: 'info',
      //   text: 'NEW',
      // },
    },
   
    {
      name: 'Contact',
      url: '/contact',
      icon: 'icon-notebook',
    },
    {
      name: 'Loan',
      url: '/application-lists',
      icon: 'icon-doc',
    },
    {
      name: 'Product',
      url: '/product-bank',
      icon: 'icon-briefcase',
    },
   
    {
      name: 'Bank',
      url: '/daftar-bank',
      icon: 'icon-chart',
    },

    {
      name: 'Marketing',
      url: '/emarketing-list',
      icon: 'icon-envelope',
    },
   

   
  

    // {
    //   name: 'Halaman Selesai',
    //   url: '/base',
    //   icon: 'icon-puzzle',
    //   children: [
    //     {
    //       name: 'Contact',
    //       url: '/contact',
      
    //     },
    //     {
    //       name: 'Add Contact',
    //       url: '/add-contact',

    //     },
    //     {
    //       name: 'Contact Detail',
    //       url: '/contact-detail',
  
    //     },
    //     {
    //       name: 'Edit Contact',
    //       url: '/edit-contact',
       
    //     },
    //     {
    //       name: 'Loan Requirement',
    //       url: '/loan',

    //     },
    //     {
    //       name: 'Add Loan Requirement',
    //       url: '/add-loan',
      
    //     },
    //     {
    //       name: 'Note',
    //       url: '/note',

    //     },
    //     {
    //       name: 'Add Note',
    //       url: '/add-note',
       
    //     },
    //     {
    //       name: 'Akses',
    //       url: '/akses',
      
    //     },
    //     {
    //       name: 'Add Akses',
    //       url: '/add-akses',
   
    //     },
    //     {
    //       name: 'Daftar Pinjaman',
    //       url: '/daftar-pinjaman',
       
    //     },
       
    //     // {
    //     //   name: 'Forms',
    //     //   url: '/base/forms',
    //     //   icon: 'icon-puzzle',
    //     // },
       
    //     {
    //       name: 'Daftar Bank',
    //       url: '/daftar-bank',
    
    //     },
       
    //     {
    //       name: 'Member Bank',
    //       url: '/member-bank',
        
    //     },
       
      
    //     {
    //       name: 'Detail Pinjaman',
    //       url: '/detail-pinjaman',
    
    //     },
      
    //     {
    //       name: 'Upload Document',
    //       url: '/upload-document',
   
    //     },
    //     {
    //       name: 'Detail Pekerjaan',
    //       url: '/detail-pekerjaan',
   
    //     },       
    //     {
    //       name: 'Informasi Tambahan',
    //       url: '/informasi-tambahan',
       
    //     },
    //     {
    //       name: 'Product',
    //       url: '/product',
   
    //     },
    //   ],
    // },
    // {
    //   name: 'Buttons',
    //   url: '/buttons',
    //   icon: 'icon-cursor',
    //   children: [
    //     {
    //       name: 'Buttons',
    //       url: '/buttons/buttons',
    //       icon: 'icon-cursor',
    //     },
    //     {
    //       name: 'Button dropdowns',
    //       url: '/buttons/button-dropdowns',
    //       icon: 'icon-cursor',
    //     },
    //     {
    //       name: 'Button groups',
    //       url: '/buttons/button-groups',
    //       icon: 'icon-cursor',
    //     },
    //     {
    //       name: 'Brand Buttons',
    //       url: '/buttons/brand-buttons',
    //       icon: 'icon-cursor',
    //     },
    //   ],
    // },
    // {
    //   name: 'Charts',
    //   url: '/charts',
    //   icon: 'icon-pie-chart',
    // },
    // {
    //   name: 'Icons',
    //   url: '/icons',
    //   icon: 'icon-star',
    //   children: [
    //     {
    //       name: 'CoreUI Icons',
    //       url: '/icons/coreui-icons',
    //       icon: 'icon-star',
    //       badge: {
    //         variant: 'info',
    //         text: 'NEW',
    //       },
    //     },
    //     {
    //       name: 'Flags',
    //       url: '/icons/flags',
    //       icon: 'icon-star',
    //     },
    //     {
    //       name: 'Font Awesome',
    //       url: '/icons/font-awesome',
    //       icon: 'icon-star',
    //       badge: {
    //         variant: 'secondary',
    //         text: '4.7',
    //       },
    //     },
    //     {
    //       name: 'Simple Line Icons',
    //       url: '/icons/simple-line-icons',
    //       icon: 'icon-star',
    //     },
    //   ],
    // },
    // {
    //   name: 'Notifications',
    //   url: '/notifications',
    //   icon: 'icon-bell',
    //   children: [
    //     {
    //       name: 'Alerts',
    //       url: '/notifications/alerts',
    //       icon: 'icon-bell',
    //     },
    //     {
    //       name: 'Badges',
    //       url: '/notifications/badges',
    //       icon: 'icon-bell',
    //     },
    //     {
    //       name: 'Modals',
    //       url: '/notifications/modals',
    //       icon: 'icon-bell',
    //     },
    //   ],
    // },
    // {
    //   name: 'Widgets',
    //   url: '/widgets',
    //   icon: 'icon-calculator',
    //   badge: {
    //     variant: 'info',
    //     text: 'NEW',
    //   },
    // },
    // {
    //   divider: true,
    // },
    // {
    //   title: true,
    //   name: 'Extras',
    // },
    // {
    //   name: 'Pages',
    //   url: '/pages',
    //   icon: 'icon-star',
    //   children: [
    //     {
    //       name: 'Detail_pinjaman ',
    //       url: '/pages/detail_pinjaman',
    //       icon: 'icon-star',
    //     },
    //     {
    //       name: 'Informasi_tambahan ',
    //       url: '/pages/informasi_tambahan',
    //       icon: 'icon-star',
    //     },
    //     {
    //       name: 'Upload Tambahan ',
    //       url: '/Upload_tambahan',
    //       icon: 'icon-star',
    //     },
    //     {
    //       name: 'Login',
    //       url: '/login',
    //       icon: 'icon-star',
    //     },
    //     {
    //       name: 'Register',
    //       url: '/register',
    //       icon: 'icon-star',
    //     },
    //     {
    //       name: 'Error 404',
    //       url: '/404',
    //       icon: 'icon-star',
    //     },
    //     {
    //       name: 'Error 500',
    //       url: '/500',
    //       icon: 'icon-star',
    //     },
    //   ],
    // },
    // {
    //   name: 'Disabled',
    //   url: '/dashboard',
    //   icon: 'icon-ban',
    //   attributes: { disabled: true },
    // },
    // {
    //   name: 'Download CoreUI',
    //   url: 'https://coreui.io/react/',
    //   icon: 'icon-cloud-download',
    //   class: 'mt-auto',
    //   variant: 'success',
    //   attributes: { target: '_blank', rel: "noopener" },
    // },
    // {
    //   name: 'Try CoreUI PRO',
    //   url: 'https://coreui.io/pro/react/',
    //   icon: 'icon-layers',
    //   variant: 'danger',
    //   attributes: { target: '_blank', rel: "noopener" },
    // },
  ],
};
